package dev.lupasud.musicisland.render;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Base64;

public final class MediaTextureManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("MusicIsland");

    public static final Identifier ARTWORK_CURRENT_ID = Identifier.fromNamespaceAndPath("musicisland", "textures/gui/artwork_current");
    public static final Identifier ARTWORK_PREV_ID = Identifier.fromNamespaceAndPath("musicisland", "textures/gui/artwork_prev");
    private static final MediaTextureManager INSTANCE = new MediaTextureManager();

    private DynamicTexture currentTexture;
    private DynamicTexture previousTexture;
    private Identifier currentTextureId = ARTWORK_CURRENT_ID;
    private Identifier previousTextureId = ARTWORK_PREV_ID;
    private String currentThumbHash = "";
    private volatile boolean hasCustomArtwork = false;
    private float transition = 1.0f;

    private MediaTextureManager() {}

    public static MediaTextureManager getInstance() {
        return INSTANCE;
    }

    public boolean hasCustomArtwork() {
        return hasCustomArtwork && currentTexture != null;
    }

    public Identifier getCurrentTextureId() {
        return currentTextureId;
    }

    public Identifier getPreviousTextureId() {
        return previousTextureId;
    }

    public boolean hasPreviousArtwork() {
        return previousTexture != null && transition < 1.0f;
    }

    public float getTransition() {
        return transition;
    }

    public void advanceTransition(float delta) {
        if (transition < 1.0f) {
            transition = Math.min(1.0f, transition + delta * 0.1f);
            if (transition >= 1.0f && previousTexture != null) {
                Minecraft client = Minecraft.getInstance();
                if (client != null) {
                    client.execute(() -> {
                        if (previousTexture != null) {
                            client.getTextureManager().release(previousTextureId);
                            previousTexture = null;
                        }
                    });
                }
            }
        }
    }

    public void updateArtwork(String base64, String hash) {
        if (hash != null && hash.equals(currentThumbHash) && hasCustomArtwork) {
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (client == null) return;

        client.execute(() -> {
            try {
                byte[] decoded = Base64.getDecoder().decode(base64);
                NativeImage nativeImage = NativeImage.read(decoded);

                DynamicTexture nextTexture = new DynamicTexture(() -> "musicisland_artwork", nativeImage);
                if (currentTexture != null) {
                    if (previousTexture != null) {
                        client.getTextureManager().release(previousTextureId);
                    }
                    previousTexture = currentTexture;
                    // Keep the old texture at its registered ID: replacing that ID closes it.
                    Identifier availableId = previousTextureId;
                    previousTextureId = currentTextureId;
                    currentTextureId = availableId;
                    transition = 0.0f;
                } else {
                    transition = 1.0f;
                }

                currentTexture = nextTexture;
                client.getTextureManager().register(currentTextureId, currentTexture);

                currentThumbHash = hash != null ? hash : "";
                hasCustomArtwork = true;
            } catch (Exception e) {
                LOGGER.debug("Failed to create artwork texture: {}", e.getMessage());
                clearArtwork();
            }
        });
    }

    public void clearArtwork() {
        Minecraft client = Minecraft.getInstance();
        if (client == null) return;

        client.execute(() -> {
            if (currentTexture != null) {
                client.getTextureManager().release(currentTextureId);
                currentTexture = null;
            }
            if (previousTexture != null) {
                client.getTextureManager().release(previousTextureId);
                previousTexture = null;
            }
            currentThumbHash = "";
            hasCustomArtwork = false;
            transition = 1.0f;
        });
    }
}
