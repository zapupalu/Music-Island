using System;
using System.IO;
using System.Text;
using System.Threading;
using Windows.Foundation;
using Windows.Media.Control;
using Windows.Storage.Streams;

namespace MusicIsland.Helper
{
    internal static class Program
    {
        private static volatile bool _running = true;
        private static GlobalSystemMediaTransportControlsSessionManager _manager;
        private static string _lastEmittedState = "";
        private static string _lastThumbHash = "";

        private static T AwaitOp<T>(IAsyncOperation<T> op, int timeoutMs = 2500)
        {
            int elapsed = 0;
            while (op.Status == AsyncStatus.Started && elapsed < timeoutMs)
            {
                Thread.Sleep(10);
                elapsed += 10;
            }

            if (op.Status == AsyncStatus.Completed)
            {
                return op.GetResults();
            }

            return default(T);
        }

        private static void AwaitAction(IAsyncAction op, int timeoutMs = 2500)
        {
            int elapsed = 0;
            while (op.Status == AsyncStatus.Started && elapsed < timeoutMs)
            {
                Thread.Sleep(10);
                elapsed += 10;
            }
        }

        public static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            // Start command reader thread
            var commandThread = new Thread(ReadCommands)
            {
                IsBackground = true,
                Name = "MusicIslandCommandReader"
            };
            commandThread.Start();

            // Initialize GSMTC Manager
            try
            {
                var mgrOp = GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
                _manager = AwaitOp(mgrOp, 5000);
            }
            catch (Exception ex)
            {
                Console.WriteLine("{\"hasSession\":false,\"error\":\"" + EscapeJson(ex.Message) + "\"}");
                return;
            }

            if (_manager == null)
            {
                Console.WriteLine("{\"hasSession\":false,\"error\":\"Manager could not be initialized\"}");
                return;
            }

            // Polling and event loop
            while (_running)
            {
                try
                {
                    UpdateAndEmitState();
                }
                catch (Exception)
                {
                    // Ignore transient WinRT COM exceptions
                }

                Thread.Sleep(350);
            }
        }

        private static void ReadCommands()
        {
            try
            {
                string line;
                while (_running && (line = Console.ReadLine()) != null)
                {
                    line = line.Trim();
                    if (string.IsNullOrEmpty(line)) continue;

                    if (line.Equals("CMD QUIT", StringComparison.OrdinalIgnoreCase))
                    {
                        _running = false;
                        Environment.Exit(0);
                        break;
                    }

                    HandleCommand(line);
                }
            }
            catch
            {
                _running = false;
            }
        }

        private static void HandleCommand(string cmd)
        {
            if (_manager == null) return;
            var session = GetBestSession();
            if (session == null) return;

            try
            {
                if (cmd.Equals("CMD PLAY_PAUSE", StringComparison.OrdinalIgnoreCase))
                {
                    AwaitOp(session.TryTogglePlayPauseAsync(), 1000);
                }
                else if (cmd.Equals("CMD PREV", StringComparison.OrdinalIgnoreCase))
                {
                    AwaitOp(session.TrySkipPreviousAsync(), 1000);
                }
                else if (cmd.Equals("CMD NEXT", StringComparison.OrdinalIgnoreCase))
                {
                    AwaitOp(session.TrySkipNextAsync(), 1000);
                }
            }
            catch
            {
                // Ignore failure on specific player
            }
        }

        private static GlobalSystemMediaTransportControlsSession GetBestSession()
        {
            if (_manager == null) return null;

            try
            {
                var current = _manager.GetCurrentSession();
                var sessions = _manager.GetSessions();
                if (sessions == null || sessions.Count == 0)
                {
                    return current;
                }

                // 1. Look for a currently playing session
                foreach (var s in sessions)
                {
                    try
                    {
                        var info = s.GetPlaybackInfo();
                        if (info != null && info.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing)
                        {
                            return s;
                        }
                    }
                    catch { }
                }

                // 2. Return current session if present
                if (current != null) return current;

                // 3. Return paused session if any
                foreach (var s in sessions)
                {
                    try
                    {
                        var info = s.GetPlaybackInfo();
                        if (info != null && info.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Paused)
                        {
                            return s;
                        }
                    }
                    catch { }
                }

                // 4. Return first session
                return sessions[0];
            }
            catch
            {
                return null;
            }
        }

        private static void UpdateAndEmitState()
        {
            var session = GetBestSession();
            if (session == null)
            {
                string emptyJson = "{\"hasSession\":false,\"status\":\"NONE\"}";
                if (emptyJson != _lastEmittedState)
                {
                    _lastEmittedState = emptyJson;
                    _lastThumbHash = "";
                    Console.WriteLine(emptyJson);
                }
                return;
            }

            string title = "";
            string artist = "";
            string album = "";
            string thumbBase64 = null;
            string currentThumbHash = "";

            try
            {
                var propsOp = session.TryGetMediaPropertiesAsync();
                var props = AwaitOp(propsOp, 1500);
                if (props != null)
                {
                    title = props.Title ?? "";
                    artist = props.Artist ?? "";
                    album = props.AlbumTitle ?? "";

                    if (props.Thumbnail != null)
                    {
                        try
                        {
                            var streamOp = props.Thumbnail.OpenReadAsync();
                            var stream = AwaitOp(streamOp, 2000);
                            if (stream != null && stream.Size > 0 && stream.Size < 15000000)
                            {
                                uint size = (uint)stream.Size;
                                var reader = new DataReader(stream.GetInputStreamAt(0));
                                var loadOp = reader.LoadAsync(size);
                                AwaitOp(loadOp, 2000);

                                byte[] buffer = new byte[size];
                                reader.ReadBytes(buffer);

                                currentThumbHash = ComputeHash(buffer);
                                if (currentThumbHash != _lastThumbHash)
                                {
                                    thumbBase64 = Convert.ToBase64String(buffer);
                                    _lastThumbHash = currentThumbHash;
                                }
                            }
                        }
                        catch
                        {
                            // Thumbnail could not be read
                        }
                    }
                }
            }
            catch
            {
                // Properties failed
            }

            string status = "STOPPED";
            bool canPlay = false;
            bool canPause = false;
            bool canPrev = false;
            bool canNext = false;

            try
            {
                var playback = session.GetPlaybackInfo();
                if (playback != null)
                {
                    switch (playback.PlaybackStatus)
                    {
                        case GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing:
                            status = "PLAYING";
                            break;
                        case GlobalSystemMediaTransportControlsSessionPlaybackStatus.Paused:
                            status = "PAUSED";
                            break;
                        case GlobalSystemMediaTransportControlsSessionPlaybackStatus.Stopped:
                            status = "STOPPED";
                            break;
                        default:
                            status = "STOPPED";
                            break;
                    }

                    if (playback.Controls != null)
                    {
                        canPlay = playback.Controls.IsPlayEnabled;
                        canPause = playback.Controls.IsPauseEnabled;
                        canPrev = playback.Controls.IsPreviousEnabled;
                        canNext = playback.Controls.IsNextEnabled;
                    }
                }
            }
            catch
            {
                // Playback info failed
            }

            var sb = new StringBuilder();
            sb.Append("{");
            sb.Append("\"hasSession\":true,");
            sb.Append("\"title\":\"").Append(EscapeJson(title)).Append("\",");
            sb.Append("\"artist\":\"").Append(EscapeJson(artist)).Append("\",");
            sb.Append("\"album\":\"").Append(EscapeJson(album)).Append("\",");
            sb.Append("\"status\":\"").Append(status).Append("\",");
            sb.Append("\"canPlay\":").Append(canPlay ? "true" : "false").Append(",");
            sb.Append("\"canPause\":").Append(canPause ? "true" : "false").Append(",");
            sb.Append("\"canPrev\":").Append(canPrev ? "true" : "false").Append(",");
            sb.Append("\"canNext\":").Append(canNext ? "true" : "false").Append(",");
            sb.Append("\"thumbHash\":\"").Append(currentThumbHash).Append("\"");

            if (thumbBase64 != null)
            {
                sb.Append(",\"thumbBase64\":\"").Append(thumbBase64).Append("\"");
            }

            sb.Append("}");

            string json = sb.ToString();

            // Only emit state when something changed (ignoring timestamp)
            string comparisonKey = title + "|" + artist + "|" + album + "|" + status + "|" + canPlay + "|" + canPause + "|" + canPrev + "|" + canNext + "|" + currentThumbHash;
            if (comparisonKey != _lastEmittedState || thumbBase64 != null)
            {
                _lastEmittedState = comparisonKey;
                Console.WriteLine(json);
            }
        }

        private static string ComputeHash(byte[] data)
        {
            if (data == null || data.Length == 0) return "";
            unchecked
            {
                const int p = 16777619;
                int hash = (int)2166136261;
                for (int i = 0; i < data.Length; i += Math.Max(1, data.Length / 128))
                {
                    hash = (hash ^ data[i]) * p;
                }
                hash += data.Length;
                return hash.ToString("X8") + "_" + data.Length;
            }
        }

        private static string EscapeJson(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var sb = new StringBuilder(s.Length + 4);
            foreach (char c in s)
            {
                switch (c)
                {
                    case '\\': sb.Append("\\\\"); break;
                    case '\"': sb.Append("\\\""); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (c < 32)
                        {
                            sb.AppendFormat("\\u{0:X04}", (int)c);
                        }
                        else
                        {
                            sb.Append(c);
                        }
                        break;
                }
            }
            return sb.ToString();
        }
    }
}
