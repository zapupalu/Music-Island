package dev.lupasud.musicisland.lyrics;

/** Original approximate character timings derived from a line's word weights. */
public final class LyricsAnimator {
    private LyricsAnimator() {}

    public static double[] characterStarts(String text, long durationMs) {
        int[] points = text.codePoints().toArray();
        double[] weights = new double[points.length];
        double total = 0;
        for (int i = 0; i < points.length;) {
            if (Character.isWhitespace(points[i])) { i++; continue; }
            int end = i;
            int vowels = 0;
            while (end < points.length && !Character.isWhitespace(points[end])) {
                if ("aeiouyаеёиоуыэюя".indexOf(Character.toLowerCase(points[end])) >= 0) vowels++;
                end++;
            }
            double weight = Math.max(1, vowels);
            for (int j = i; j < end; j++) weights[j] = weight / (end - i);
            total += weight;
            i = end;
        }
        double[] starts = new double[points.length];
        double elapsed = 0;
        double span = Math.max(0, durationMs - Math.min(180, durationMs / 8));
        for (int i = 0; i < points.length; i++) {
            starts[i] = total == 0 ? 0 : elapsed / total * span;
            elapsed += weights[i];
        }
        return starts;
    }

    public static float reveal(double elapsedMs, double startMs) {
        float t = (float) Math.max(0, Math.min(1, (elapsedMs - startMs) / 120));
        return t * t * (3 - 2 * t);
    }

    public static float smoothing(double seconds, double timeConstant) {
        return (float) (1 - Math.exp(-Math.max(0, seconds) / timeConstant));
    }
}
