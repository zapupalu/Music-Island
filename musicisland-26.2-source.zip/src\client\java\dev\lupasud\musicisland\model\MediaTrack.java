package dev.lupasud.musicisland.model;

public record MediaTrack(
    boolean hasSession,
    String title,
    String artist,
    String album,
    PlaybackStatus status,
    boolean canPlay,
    boolean canPause,
    boolean canPrev,
    boolean canNext,
    String thumbHash,
    String thumbBase64,
    boolean timelineKnown,
    long positionMs,
    long durationMs,
    long sampledAtNanos
) {
    public MediaTrack {
        title = title == null ? "" : title;
        artist = artist == null ? "" : artist;
        album = album == null ? "" : album;
        status = status == null ? PlaybackStatus.NONE : status;
        thumbHash = thumbHash == null ? "" : thumbHash;
        durationMs = Math.max(0, durationMs);
        positionMs = Math.max(0, positionMs);
        timelineKnown = hasSession && timelineKnown && durationMs > 0;
        if (timelineKnown) positionMs = Math.min(positionMs, durationMs);
    }

    public MediaTrack(
        boolean hasSession,
        String title,
        String artist,
        String album,
        PlaybackStatus status,
        boolean canPlay,
        boolean canPause,
        boolean canPrev,
        boolean canNext,
        String thumbHash,
        String thumbBase64
    ) {
        this(hasSession, title, artist, album, status, canPlay, canPause, canPrev, canNext, thumbHash, thumbBase64, false, 0, 0, System.nanoTime());
    }

    /** Monotonic interpolation between Windows snapshots; fallback to elapsed time when timeline unknown. */
    public long positionAt(long nowNanos) {
        if (timelineKnown && durationMs > 0) {
            long elapsed = isPlaying() ? Math.max(0, (nowNanos - sampledAtNanos) / 1_000_000L) : 0;
            return positionMs + Math.min(elapsed, Math.max(0, durationMs - positionMs));
        }
        if (isPlaying() && sampledAtNanos > 0) {
            return Math.max(0, (nowNanos - sampledAtNanos) / 1_000_000L);
        }
        return 0;
    }

    public static final MediaTrack EMPTY = new MediaTrack(
        false, "", "", "", PlaybackStatus.NONE, false, false, false, false, "", null
    );

    public static final MediaTrack PREVIEW = new MediaTrack(
        true, "Under Your Spell", "Snow Strippers", "April Mixtape", PlaybackStatus.PLAYING, false, true, true, true, "preview", null,
        true, 4_500, 150_000, System.nanoTime()
    );

    public boolean isPlaying() {
        return status == PlaybackStatus.PLAYING;
    }

    public String getDisplayTitle() {
        if (title != null && !title.isBlank()) {
            return title.trim();
        }
        return "Unknown Title";
    }

    public String getDisplayArtist() {
        if (artist != null && !artist.isBlank()) {
            return artist.trim();
        }
        return "Unknown Artist";
    }

    public String getDisplayAlbum() {
        if (album != null && !album.isBlank()) {
            return album.trim();
        }
        return "";
    }
}
