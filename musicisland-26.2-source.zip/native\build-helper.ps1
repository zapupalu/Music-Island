$ErrorActionPreference = 'Stop'
$framework = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319'
$metadata = Join-Path $env:WINDIR 'System32/WinMetadata'
$output = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../src/main/resources/assets/musicisland/bin/musicisland-timeline.exe'))
$source = Join-Path $PSScriptRoot 'MediaBridge.cs'
$facades = Join-Path ${env:ProgramFiles(x86)} 'Reference Assemblies/Microsoft/Framework/.NETFramework/v4.8/Facades'
$refs = Get-ChildItem $facades -Filter '*.dll' | ForEach-Object { '/reference:' + $_.FullName }
& "$framework/csc.exe" /nologo /target:winexe /optimize+ "/out:$output" /reference:System.Web.Extensions.dll "/reference:$framework/System.Runtime.WindowsRuntime.dll" "/reference:$metadata/Windows.Foundation.winmd" "/reference:$metadata/Windows.Media.winmd" "/reference:$metadata/Windows.Storage.winmd" @refs $source
if ($LASTEXITCODE -ne 0) { throw 'Native bridge compilation failed' }
