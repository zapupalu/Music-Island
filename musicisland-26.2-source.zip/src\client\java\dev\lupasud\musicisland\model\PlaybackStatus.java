package dev.lupasud.musicisland.model;

public enum PlaybackStatus {
    PLAYING,
    PAUSED,
    STOPPED,
    NONE;

    public static PlaybackStatus fromString(String s) {
        if (s == null) return NONE;
        try {
            return valueOf(s.toUpperCase().trim());
        } catch (IllegalArgumentException e) {
            return NONE;
        }
    }

    public boolean isPlaying() {
        return this == PLAYING;
    }
}
