package dev.lupasud.musicisland;

import dev.lupasud.musicisland.lyrics.LyricsDocument;

public final class LyricsTests {
    private static int checks;
    private static void check(boolean ok, String message) { checks++; if (!ok) throw new AssertionError(message); }

    public static void main(String[] args) {
        var d = LyricsDocument.parse("[ar:Someone]\n[00:01.2][00:04.020]Привет 🌍\n[00:02.50]\n[bad]ignored\n[00:03.001]мир\n[00:04.020]duplicate", 6000);
        check(d.lines().size() == 4, "metadata ignored, multiple timestamps, duplicate removed");
        check(d.lines().get(0).startMs() == 1200, "tenths");
        check(d.lines().get(1).startMs() == 2500, "hundredths");
        check(d.lines().get(2).startMs() == 3001, "milliseconds");
        check(d.lineAt(1199) == null, "before beginning");
        check(d.lineAt(1200).text().equals("Привет 🌍"), "unicode intact at boundary");
        check(d.lineAt(2500) == null && d.lineAt(3000) == null, "timed blank is an instrumental gap");
        check(d.lineAt(3001).text().equals("мир"), "next boundary");
        check(d.lineAt(4020).text().equals("Привет 🌍"), "duplicate deterministic");
        check(d.lineAt(6000) == null, "duration exclusive");
        var offset = LyricsDocument.parse("[00:01]first\n[offset:-1500]\n[00:03]second", 5000);
        check(offset.lines().get(0).startMs() == 0 && offset.lines().get(1).startMs() == 1500, "global negative offset clamps");
        check(LyricsDocument.parse("[offset:+200]\n[00:01]x", 5000).lines().get(0).startMs() == 1200, "positive offset");
        check(LyricsDocument.parse("[00:99]bad\n[xx]bad\n[ar:abc]", 3000).lines().isEmpty(), "malformed input");
        check(LyricsDocument.parse(null, 0).lines().isEmpty(), "null input");
        check(LyricsDocument.parse("[00:02]x", 1000).lines().isEmpty(), "out of duration ignored");
        check(LyricsDocument.parse("[00:02]x", 0).lineAt(10000) == null, "unknown duration capped final line");
        boolean immutable = false;
        try {
            d.lines().clear();
        } catch (UnsupportedOperationException e) {
            immutable = true;
        }
        check(immutable, "immutable publication");
        System.out.println("LYRICS_TESTS " + checks + " passed");
    }
}
