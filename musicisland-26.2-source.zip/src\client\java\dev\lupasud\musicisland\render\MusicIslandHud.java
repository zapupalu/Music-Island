package dev.lupasud.musicisland.render;

import dev.lupasud.musicisland.MusicIslandClient;
import dev.lupasud.musicisland.config.MusicIslandConfig;
import dev.lupasud.musicisland.config.PositionManager;
import dev.lupasud.musicisland.interop.MediaController;
import dev.lupasud.musicisland.lyrics.LyricsAnimator;
import dev.lupasud.musicisland.lyrics.LyricsDocument;
import dev.lupasud.musicisland.lyrics.LyricsService;
import dev.lupasud.musicisland.model.MediaTrack;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public final class MusicIslandHud implements HudElement {
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");

    private float currentWidth = 205.0f;
    private float currentHeight = 26.0f;
    private float currentAlpha = 0.0f;
    private float visualizerTimer = 0.0f;
    private float marqueeTimer = 0.0f;
    private String lastTrackKey = "";
    private final LyricsRenderer lyrics = new LyricsRenderer();
    private long lastFrameNanos;
    private static MusicIslandHud current;

    public MusicIslandHud() {
        current = this;
    }

    public static MusicIslandHud current() {
        return current;
    }

    public boolean activeLyrics() {
        return lyrics.active();
    }

    public String displayedLyricText() {
        return lyrics.text();
    }

    public int visibleGlyphCount() {
        return lyrics.visibleGlyphCount();
    }

    public float lyricScrollOffset() {
        return lyrics.scrollOffset();
    }

    private float dynamicIslandAlpha = 1.0f;
    private float ovrSpotAlpha = 0.0f;

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker) {
        MusicIslandConfig config = MusicIslandClient.config();
        long now = System.nanoTime();
        double frameSeconds = lastFrameNanos == 0 ? 1.0 / 60 : Math.min(0.25, (now - lastFrameNanos) / 1_000_000_000.0);
        lastFrameNanos = now;

        if (!config.enabled) {
            currentAlpha = 0.0f;
            lyrics.clear();
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (client == null) return;

        MediaController controller = MediaController.getInstance();
        MediaTrack track = controller.getCurrentTrack();
        boolean hasTrack = track.hasSession() && (!track.title().isEmpty() || !track.artist().isEmpty());

        if (config.autoHide && !hasTrack) {
            lyrics.clear();
            currentAlpha = Math.max(0.0f, currentAlpha - (float) frameSeconds * 4.0f);
            if (currentAlpha <= 0.01f) return;
        } else {
            currentAlpha = Math.min(1.0f, currentAlpha + (float) frameSeconds * 4.0f);
        }

        float deltaTicks = deltaTracker.getGameTimeDeltaTicks();
        if (hasTrack && track.isPlaying()) {
            visualizerTimer += deltaTicks * 0.22f;
        }

        // Marquee and Track tracking
        String currentKey = track.title() + "|" + track.artist() + "|" + track.album();
        if (!currentKey.equals(lastTrackKey)) {
            lastTrackKey = currentKey;
            marqueeTimer = 0.0f;
        }
        marqueeTimer += (float) frameSeconds;

        Font font = client.font;
        int screenWidth = extractor.guiWidth();
        int screenHeight = extractor.guiHeight();

        // Lyrics update using LyricsDocument & track position
        long offset = (config.mode == MusicIslandConfig.HudMode.OVR_SPOT) ? config.ovrLyricsOffsetMs : config.lyricsOffsetMs;
        boolean lyricsShouldRun = (config.mode == MusicIslandConfig.HudMode.OVR_SPOT)
            ? (config.ovrShowLyrics && hasTrack)
            : (config.lyricsEnabled && config.showLyrics && hasTrack);
        LyricsDocument document = lyricsShouldRun ? LyricsService.getInstance().documentFor(track) : null;
        long lyricPosition = track.positionAt(now) + offset;
        lyrics.update(currentKey + "|" + track.durationMs(), document == null ? null : document.lineAt(lyricPosition), lyricPosition, now, font);

        // Smooth Mode Cross-Fade Transition
        boolean isIsland = config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND;
        float modeDelta = (float) frameSeconds * 4.0f;
        if (isIsland) {
            dynamicIslandAlpha = Math.min(1.0f, dynamicIslandAlpha + modeDelta);
            ovrSpotAlpha = Math.max(0.0f, ovrSpotAlpha - modeDelta);
        } else {
            ovrSpotAlpha = Math.min(1.0f, ovrSpotAlpha + modeDelta);
            dynamicIslandAlpha = Math.max(0.0f, dynamicIslandAlpha - modeDelta);
        }

        // ============================================================
        // 1. RENDER DYNAMIC ISLAND HUD
        // ============================================================
        if (dynamicIslandAlpha > 0.01f) {
            float targetWidth = config.customWidth >= 150 ? (float) config.customWidth : 205.0f;
            float scale = config.scale > 0.1f ? config.scale : 1.0f;
            targetWidth = Math.min(targetWidth, Math.max(1, (screenWidth - 20) / scale));

            int lineCount = computeActiveLineCount(config, hasTrack, lyrics.active());
            float targetHeight = config.customHeight >= 20 ? (float) config.customHeight : 26.0f;
            if (lineCount == 2) {
                targetHeight = Math.max(targetHeight, 34.0f);
            } else if (lineCount >= 3) {
                targetHeight = Math.max(targetHeight, 44.0f);
            }

            currentWidth = Mth.lerp(LyricsAnimator.smoothing(frameSeconds, 0.2), currentWidth, targetWidth);
            currentHeight = Mth.lerp(LyricsAnimator.smoothing(frameSeconds, 0.1), currentHeight, targetHeight);

            int islandWidth = Math.round(currentWidth);
            int islandHeight = Math.round(currentHeight);

            int posX = PositionManager.getX(screenWidth, islandWidth, config);
            int posY = PositionManager.getY(screenHeight, islandHeight, config);

            float preciseX = PositionManager.animatedX(screenWidth, currentWidth, config);
            boolean customScale = Math.abs(scale - 1.0f) > 0.01f;

            extractor.pose().pushMatrix();
            extractor.pose().translate(preciseX - posX, 0);
            if (customScale) {
                extractor.pose().scaleAround(scale, scale, (float) posX, (float) posY);
            }

            renderIsland(
                extractor, font, posX, posY, islandWidth, islandHeight,
                track, hasTrack, config, currentAlpha * dynamicIslandAlpha,
                visualizerTimer, marqueeTimer, deltaTicks, lyrics
            );

            extractor.pose().popMatrix();
        }

        // ============================================================
        // 2. RENDER OVRSPOT HUD
        // ============================================================
        if (ovrSpotAlpha > 0.01f) {
            int ovrCardW = OvrSpotRenderer.calculateCardWidth(config);
            int ovrCardH = OvrSpotRenderer.calculateCardHeight(config, font, config.ovrShowLyrics && lyrics.active());

            int ovrX = PositionManager.getOvrX(screenWidth, ovrCardW, config);
            int ovrY = PositionManager.getOvrY(screenHeight, ovrCardH, config);
            float ovrScale = config.ovrScale > 0.1f ? config.ovrScale : 1.0f;
            boolean customOvrScale = Math.abs(ovrScale - 1.0f) > 0.01f;

            extractor.pose().pushMatrix();
            if (customOvrScale) {
                extractor.pose().scaleAround(ovrScale, ovrScale, (float) ovrX, (float) ovrY);
            }

            OvrSpotRenderer.render(
                extractor, font, ovrX, ovrY,
                track, hasTrack, config,
                currentAlpha * ovrSpotAlpha,
                marqueeTimer, deltaTicks, lyrics
            );

            extractor.pose().popMatrix();
        }
    }

    public static int computeActiveLineCount(MusicIslandConfig config, boolean hasTrack, boolean hasLyrics) {
        if (!hasTrack) return 1;
        int maxLines = config.lyricsMaxLines;
        if (maxLines == 1) return 1;

        if (hasLyrics && config.lyricsPosition == MusicIslandConfig.LyricsPosition.BELOW_ARTIST) {
            return maxLines >= 3 && config.showArtist ? 3 : 2;
        }
        if (hasLyrics && config.lyricsPosition == MusicIslandConfig.LyricsPosition.SEPARATE_LINE) {
            return 2;
        }

        // If no lyrics, check if Title + Artist + Album
        if (config.customHeight >= 32 && config.showTitle && (config.showArtist || config.showAlbum)) {
            return (config.showAlbum && config.showArtist && maxLines >= 3) ? 3 : 2;
        }

        return 1;
    }

    public static void renderIsland(
        GuiGraphicsExtractor extractor,
        Font font,
        int x,
        int y,
        int width,
        int height,
        MediaTrack track,
        boolean hasTrack,
        MusicIslandConfig config,
        float alphaMult
    ) {
        renderIsland(extractor, font, x, y, width, height, track, hasTrack, config, alphaMult, 0f, 0f, 0f, null);
    }

    public static void renderIsland(
        GuiGraphicsExtractor extractor,
        Font font,
        int x,
        int y,
        int width,
        int height,
        MediaTrack track,
        boolean hasTrack,
        MusicIslandConfig config,
        float alphaMult,
        float vizTimer,
        float marqTimer,
        float deltaTicks
    ) {
        renderIsland(extractor, font, x, y, width, height, track, hasTrack, config, alphaMult, vizTimer, marqTimer, deltaTicks, null);
    }

    public static void renderIsland(
        GuiGraphicsExtractor extractor,
        Font font,
        int x,
        int y,
        int width,
        int height,
        MediaTrack track,
        boolean hasTrack,
        MusicIslandConfig config,
        float alphaMult,
        float vizTimer,
        float marqTimer,
        float deltaTicks,
        LyricsRenderer lyrics
    ) {
        float effectiveOpacity = Math.max(0.0f, Math.min(1.0f, config.opacity * alphaMult));
        if (effectiveOpacity <= 0.02f) return;

        int alphaByte = (int) (effectiveOpacity * 255.0f);
        int baseColor = (alphaByte << 24) | (config.colorBackground & 0xFFFFFF);
        int borderColor = ((int) (effectiveOpacity * 90.0f) << 24) | (config.colorBorder & 0xFFFFFF);

        // Draw pill capsule
        drawTrulyRoundedPill(extractor, x, y, width, height, baseColor, borderColor);

        int centerY = y + height / 2;
        boolean isPlaying = hasTrack && track.isPlaying();

        // ============================================================
        // 1. DYNAMIC LEFT ELEMENTS (NO GAPS, MODULAR LAYOUT)
        // ============================================================
        int leftCursor = x + 8;
        boolean hasLeftPre = false;

        // Status Dot
        if (config.showDot) {
            int dotRgb = isPlaying ? (config.colorDot & 0xFFFFFF) : dimColor(config.colorDot);
            int dotColor = (alphaByte << 24) | dotRgb;
            extractor.fill(leftCursor + 1, centerY - 2, leftCursor + 4, centerY + 3, dotColor);
            extractor.fill(leftCursor, centerY - 1, leftCursor + 5, centerY + 2, dotColor);
            leftCursor += 9;
            hasLeftPre = true;
        }

        // Real-world Time
        if (config.showTime) {
            String timeStr = LocalTime.now().format(TIME_FORMATTER);
            int timeW = font.width(timeStr);
            extractor.text(font, timeStr, leftCursor, centerY - 4, (alphaByte << 24) | (config.colorTime & 0xFFFFFF));
            leftCursor += timeW + 5;
            hasLeftPre = true;
        }

        // Divider 1 (only if left items exist AND artwork is shown)
        boolean hasArt = config.showArtwork && (hasTrack || !config.autoHide);
        int dividerColor = ((int) (alphaByte * 0.35f) << 24) | 0xFFFFFF;

        if (hasLeftPre && hasArt) {
            extractor.fill(leftCursor, centerY - 6, leftCursor + 1, centerY + 7, dividerColor);
            leftCursor += 7;
        }

        // Artwork Thumbnail
        if (hasArt) {
            int artSize = Math.max(14, Math.min(height - 8, 30));
            int artX = leftCursor;
            int artY = centerY - artSize / 2;

            if (hasTrack) {
                MediaTextureManager texManager = MediaTextureManager.getInstance();
                if (texManager.hasCustomArtwork()) {
                    if (texManager.hasPreviousArtwork() && deltaTicks > 0.0f) {
                        texManager.advanceTransition(deltaTicks);
                        if (texManager.hasPreviousArtwork()) {
                            extractor.blit(texManager.getPreviousTextureId(), artX, artY, artX + artSize, artY + artSize, 0.0f, 1.0f, 0.0f, 1.0f);
                        }
                    }
                    extractor.blit(texManager.getCurrentTextureId(), artX, artY, artX + artSize, artY + artSize, 0.0f, 1.0f, 0.0f, 1.0f);
                    drawArtworkRoundedCorners(extractor, artX, artY, artSize, baseColor);
                    drawSubtleFrame(extractor, artX, artY, artSize, ((int) (alphaByte * 0.25f) << 24) | 0xFFFFFF);
                } else {
                    drawTrulyRoundedPill(extractor, artX, artY, artSize, artSize, (alphaByte << 24) | 0x222328, (alphaByte << 24) | 0x383940);
                    extractor.centeredText(font, "♪", artX + artSize / 2, artY + artSize / 2 - 4, (alphaByte << 24) | 0x00E5FF);
                }
            } else {
                extractor.text(font, "♪", artX + 2, centerY - 4, (alphaByte << 24) | 0x8E8E93);
            }
            leftCursor += artSize + 6;
        }

        int textContainerX = leftCursor;

        // ============================================================
        // 2. DYNAMIC RIGHT ELEMENTS (NO GAPS, MODULAR LAYOUT)
        // ============================================================
        int rightCursor = x + width - 8;

        // Visualizer
        if (config.showVisualizer) {
            int vizW = 14;
            int vizX = rightCursor - vizW;
            drawAscendingVisualizer(extractor, vizX, centerY, alphaByte, isPlaying, vizTimer, config.colorVisualizer);
            rightCursor -= (vizW + 5);
        }

        // Divider 2 (only if visualizer AND play/pause are both shown)
        if (config.showVisualizer && config.showPlayPause) {
            extractor.fill(rightCursor - 2, centerY - 6, rightCursor - 1, centerY + 7, dividerColor);
            rightCursor -= 7;
        }

        // Play / Pause Button
        if (config.showPlayPause) {
            int btnW = 6;
            int btnX = rightCursor - btnW;
            int iconY = centerY - 4;
            int iconColor = (alphaByte << 24) | (config.colorPlayPause & 0xFFFFFF);

            if (isPlaying) {
                extractor.fill(btnX, iconY, btnX + 2, iconY + 9, iconColor);
                extractor.fill(btnX + 4, iconY, btnX + 6, iconY + 9, iconColor);
            } else {
                extractor.fill(btnX, iconY, btnX + 1, iconY + 9, iconColor);
                extractor.fill(btnX + 1, iconY + 1, btnX + 2, iconY + 8, iconColor);
                extractor.fill(btnX + 2, iconY + 2, btnX + 3, iconY + 7, iconColor);
                extractor.fill(btnX + 3, iconY + 3, btnX + 4, iconY + 6, iconColor);
                extractor.fill(btnX + 4, iconY + 4, btnX + 5, iconY + 5, iconColor);
            }
            rightCursor -= (btnW + 6);
        }

        int textContainerRight = rightCursor;
        int containerWidth = Math.max(20, textContainerRight - textContainerX);

        // ============================================================
        // 3. CLIPPED TEXT CONTAINER WITH MARQUEE & LYRICS
        // ============================================================
        if (hasTrack) {
            String title = config.showTitle ? track.getDisplayTitle() : "";
            String artist = config.showArtist ? track.getDisplayArtist() : "";
            String album = config.showAlbum ? track.getDisplayAlbum() : "";

            boolean lyricsActive = lyrics != null && lyrics.active();
            if (lyricsActive) {
                lyrics.setScrollViewport(containerWidth);
            }

            int lineMode = computeActiveLineCount(config, true, lyricsActive);

            if (lineMode >= 3) {
                // 3-Line Layout: Title / Artist (or Album) / Lyrics
                int titleY = centerY - 14;
                int midY = centerY - 4;
                int lyricY = centerY + 6;

                extractor.enableScissor(textContainerX, y, textContainerRight, y + height);

                renderSingleLineMarquee(extractor, font, title, textContainerX, titleY, containerWidth, marqTimer, (alphaByte << 24) | (config.colorTitle & 0xFFFFFF), config);

                String midLine = artist;
                if (!album.isEmpty()) {
                    midLine = midLine.isEmpty() ? album : (midLine + " • " + album);
                }
                renderSingleLineMarquee(extractor, font, midLine, textContainerX, midY, containerWidth, marqTimer, (alphaByte << 24) | (config.colorArtist & 0xFFFFFF), config);

                extractor.disableScissor();

                if (lyricsActive) {
                    lyrics.draw(extractor, font, textContainerX, lyricY, textContainerRight, lyricY - 2, y + height - 2, alphaByte, config.colorLyrics);
                }

            } else if (lineMode == 2) {
                // 2-Line Layout
                int line1Y = centerY - 9;
                int line2Y = centerY + 1;

                if (lyricsActive && config.lyricsPosition == MusicIslandConfig.LyricsPosition.BELOW_ARTIST) {
                    // Line 1: Title (or Title — Artist)
                    String line1 = title;
                    if (!artist.isEmpty() && !title.isEmpty()) {
                        line1 = title + " — " + artist;
                    } else if (title.isEmpty()) {
                        line1 = artist;
                    }

                    extractor.enableScissor(textContainerX, y, textContainerRight, y + height);
                    renderSingleLineMarquee(extractor, font, line1, textContainerX, line1Y, containerWidth, marqTimer, (alphaByte << 24) | (config.colorTitle & 0xFFFFFF), config);
                    extractor.disableScissor();

                    // Line 2: Lyrics with character-by-character animated reveal!
                    lyrics.draw(extractor, font, textContainerX, line2Y, textContainerRight, line2Y - 2, y + height - 2, alphaByte, config.colorLyrics);

                } else if (lyricsActive && config.lyricsPosition == MusicIslandConfig.LyricsPosition.SEPARATE_LINE) {
                    // Line 1: Title
                    extractor.enableScissor(textContainerX, y, textContainerRight, y + height);
                    renderSingleLineMarquee(extractor, font, title, textContainerX, line1Y, containerWidth, marqTimer, (alphaByte << 24) | (config.colorTitle & 0xFFFFFF), config);
                    extractor.disableScissor();

                    // Line 2: Lyrics
                    lyrics.draw(extractor, font, textContainerX, line2Y, textContainerRight, line2Y - 2, y + height - 2, alphaByte, config.colorLyrics);

                } else {
                    // Normal 2-line mode without lyrics: Title / Artist
                    extractor.enableScissor(textContainerX, y, textContainerRight, y + height);
                    renderSingleLineMarquee(extractor, font, title, textContainerX, line1Y, containerWidth, marqTimer, (alphaByte << 24) | (config.colorTitle & 0xFFFFFF), config);
                    String sub = artist;
                    if (!album.isEmpty()) {
                        sub = sub.isEmpty() ? album : (sub + " • " + album);
                    }
                    renderSingleLineMarquee(extractor, font, sub, textContainerX, line2Y, containerWidth, marqTimer, (alphaByte << 24) | (config.colorArtist & 0xFFFFFF), config);
                    extractor.disableScissor();
                }

            } else {
                // 1-Line Compact Layout
                int lineY = centerY - 4;

                if (lyricsActive) {
                    // Single line lyrics with exact character reveal
                    lyrics.draw(extractor, font, textContainerX, lineY, textContainerRight, y + 2, y + height - 2, alphaByte, config.colorLyrics);
                } else {
                    // Classic Single-line mode: Title — Artist
                    extractor.enableScissor(textContainerX, y, textContainerRight, y + height);
                    boolean showBoth = !title.isEmpty() && !artist.isEmpty();
                    String fullLine = showBoth ? (title + " — " + artist) : (!title.isEmpty() ? title : artist);
                    if (!album.isEmpty() && fullLine.isEmpty()) fullLine = album;

                    int totalW = font.width(fullLine);
                    float offset = calculateMarqueeOffset(totalW, containerWidth, marqTimer, config.lyricsTextSpeed, config.lyricsPauseStart, config.lyricsPauseEnd, config.lyricsResetDelay, config.lyricsScrollDirection);
                    int drawX = textContainerX - Math.round(offset);

                    if (showBoth) {
                        extractor.text(font, title, drawX, lineY, (alphaByte << 24) | (config.colorTitle & 0xFFFFFF));
                        int titleW = font.width(title);
                        extractor.text(font, " — ", drawX + titleW, lineY, ((int) (alphaByte * 0.5f) << 24) | 0xAAAAAA);
                        int sepW = font.width(" — ");
                        extractor.text(font, artist, drawX + titleW + sepW, lineY, (alphaByte << 24) | (config.colorArtist & 0xFFFFFF));
                    } else {
                        extractor.text(font, fullLine, drawX, lineY, (alphaByte << 24) | (config.colorTitle & 0xFFFFFF));
                    }
                    extractor.disableScissor();
                }
            }

        } else {
            // Idle message
            String idleMsg = Component.translatable("musicisland.hud.no_music").getString();
            int idleW = font.width(idleMsg);
            float offset = calculateMarqueeOffset(idleW, containerWidth, marqTimer, config.lyricsTextSpeed, config.lyricsPauseStart, config.lyricsPauseEnd, config.lyricsResetDelay, config.lyricsScrollDirection);
            extractor.enableScissor(textContainerX, y, textContainerRight, y + height);
            extractor.text(font, idleMsg, textContainerX - Math.round(offset), centerY - 4, (alphaByte << 24) | 0x8E8E93);
            extractor.disableScissor();
        }
    }

    private static void renderSingleLineMarquee(
        GuiGraphicsExtractor extractor,
        Font font,
        String text,
        int containerX,
        int y,
        int containerW,
        float timer,
        int color,
        MusicIslandConfig config
    ) {
        if (text == null || text.isEmpty()) return;
        int textW = font.width(text);
        float offset = calculateMarqueeOffset(textW, containerW, timer, config.lyricsTextSpeed, config.lyricsPauseStart, config.lyricsPauseEnd, config.lyricsResetDelay, config.lyricsScrollDirection);
        extractor.text(font, text, containerX - Math.round(offset), y, color);
    }

    public static float calculateMarqueeOffset(int textWidth, int containerWidth, float timer) {
        return calculateMarqueeOffset(textWidth, containerWidth, timer, 24.0f, 2.0f, 2.0f, 0.0f, MusicIslandConfig.LyricsScrollDirection.PING_PONG);
    }

    public static float calculateMarqueeOffset(
        int textWidth,
        int containerWidth,
        float timer,
        float speed,
        float pauseStart,
        float pauseEnd,
        float resetDelay,
        MusicIslandConfig.LyricsScrollDirection direction
    ) {
        if (textWidth <= containerWidth) {
            return 0.0f;
        }

        float maxScroll = (float) (textWidth - containerWidth + 6);
        float scrollDuration = Math.max(1.0f, maxScroll / Math.max(5.0f, speed));

        if (direction == MusicIslandConfig.LyricsScrollDirection.LEFT_TO_RIGHT) {
            float totalPeriod = pauseStart + scrollDuration + pauseEnd + resetDelay;
            float t = timer % totalPeriod;
            if (t < pauseStart) {
                return 0.0f;
            } else if (t < pauseStart + scrollDuration) {
                float progress = (t - pauseStart) / scrollDuration;
                float ease = 0.5f - 0.5f * (float) Math.cos(progress * Math.PI);
                return ease * maxScroll;
            } else {
                return maxScroll;
            }
        } else {
            // PING_PONG with smooth cosine ease and reset delay
            float totalPeriod = pauseStart + scrollDuration + pauseEnd + scrollDuration + resetDelay;
            float t = timer % totalPeriod;
            if (t < pauseStart) {
                return 0.0f;
            } else if (t < pauseStart + scrollDuration) {
                float progress = (t - pauseStart) / scrollDuration;
                float ease = 0.5f - 0.5f * (float) Math.cos(progress * Math.PI);
                return ease * maxScroll;
            } else if (t < pauseStart + scrollDuration + pauseEnd) {
                return maxScroll;
            } else if (t < pauseStart + 2 * scrollDuration + pauseEnd) {
                float progress = (t - (pauseStart + scrollDuration + pauseEnd)) / scrollDuration;
                float ease = 0.5f - 0.5f * (float) Math.cos(progress * Math.PI);
                return (1.0f - ease) * maxScroll;
            } else {
                return 0.0f;
            }
        }
    }

    private static int dimColor(int rgb) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        return ((r * 2 / 3) << 16) | ((g * 2 / 3) << 8) | (b * 2 / 3);
    }

    private static void drawTrulyRoundedPill(GuiGraphicsExtractor extractor, int x, int y, int w, int h, int fill, int border) {
        float r = h / 2.0f;
        float r2 = r * r;

        for (int i = 0; i < h; i++) {
            float dy = (i + 0.5f) - r;
            float distSq = r2 - dy * dy;
            int dx = (distSq > 0.0f) ? (int) Math.round(r - Math.sqrt(distSq)) : (int) r;

            int left = x + dx;
            int right = x + w - dx;

            if (left < right) {
                extractor.fill(left, y + i, right, y + i + 1, fill);
                if (i == 0 || i == h - 1) {
                    extractor.fill(left, y + i, right, y + i + 1, border);
                } else {
                    extractor.fill(left, y + i, left + 1, y + i + 1, border);
                    extractor.fill(right - 1, y + i, right, y + i + 1, border);
                }
            }
        }
    }

    private static void drawArtworkRoundedCorners(GuiGraphicsExtractor extractor, int x, int y, int size, int bgColor) {
        extractor.fill(x, y, x + 1, y + 1, bgColor);
        extractor.fill(x + size - 1, y, x + size, y + 1, bgColor);
        extractor.fill(x, y + size - 1, x + 1, y + size, bgColor);
        extractor.fill(x + size - 1, y + size - 1, x + size, y + size, bgColor);
    }

    private static void drawSubtleFrame(GuiGraphicsExtractor extractor, int x, int y, int size, int frameColor) {
        extractor.fill(x + 1, y, x + size - 1, y + 1, frameColor);
        extractor.fill(x + 1, y + size - 1, x + size - 1, y + size, frameColor);
        extractor.fill(x, y + 1, x + 1, y + size - 1, frameColor);
        extractor.fill(x + size - 1, y + 1, x + size, y + size - 1, frameColor);
    }

    private static void drawAscendingVisualizer(
        GuiGraphicsExtractor extractor,
        int x,
        int centerY,
        int alphaByte,
        boolean isPlaying,
        float timer,
        int colorRgb
    ) {
        int color = (alphaByte << 24) | (colorRgb & 0xFFFFFF);
        int dimCol = ((int) (alphaByte * 0.4f) << 24) | (colorRgb & 0xFFFFFF);

        if (!isPlaying) {
            extractor.fill(x, centerY + 2, x + 2, centerY + 5, dimCol);
            extractor.fill(x + 4, centerY, x + 6, centerY + 5, dimCol);
            extractor.fill(x + 8, centerY - 2, x + 10, centerY + 5, dimCol);
            extractor.fill(x + 12, centerY - 4, x + 14, centerY + 5, dimCol);
            return;
        }

        // Ascending dynamic bars
        int h1 = 2 + (int) (2.5f * (0.5f + 0.5f * Math.sin(timer * 2.8f)));
        int h2 = 3 + (int) (4.0f * (0.5f + 0.5f * Math.sin(timer * 3.4f + 1.2f)));
        int h3 = 4 + (int) (5.5f * (0.5f + 0.5f * Math.sin(timer * 2.2f + 2.4f)));
        int h4 = 5 + (int) (6.5f * (0.5f + 0.5f * Math.sin(timer * 3.9f + 0.6f)));

        int baseY = centerY + 5;
        extractor.fill(x, baseY - h1, x + 2, baseY, color);
        extractor.fill(x + 4, baseY - h2, x + 6, baseY, color);
        extractor.fill(x + 8, baseY - h3, x + 10, baseY, color);
        extractor.fill(x + 12, baseY - h4, x + 14, baseY, color);
    }
}
