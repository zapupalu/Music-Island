package dev.lupasud.musicisland.gui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;

public final class ColorPickerScreen extends Screen {
    private final Screen parent;
    private final Consumer<Integer> onSave;
    private int r, g, b;

    private static final int[] PRESETS = {
        0x37C37A, // Reference Emerald
        0x1DB954, // Spotify Green
        0x00E5FF, // Neon Cyan
        0xFFFFFF, // Pure White
        0xD1D5DB, // Slate Light
        0x9CA3AF, // Medium Grey
        0x4B5563, // Dark Slate
        0x111215, // Dark Acrylic
        0xE0E0E6, // Border Silver
        0x38BDF8, // Sky Blue
        0x818CF8, // Indigo
        0xA855F7, // Neon Purple
        0xEC4899, // Hot Pink
        0xF59E0B, // Amber Gold
        0xFB923C, // Orange
        0xEF4444  // Soft Red
    };

    public ColorPickerScreen(Screen parent, Component titleComponent, int currentColor, Consumer<Integer> onSave) {
        super(titleComponent);
        this.parent = parent;
        this.onSave = onSave;
        this.r = (currentColor >> 16) & 0xFF;
        this.g = (currentColor >> 8) & 0xFF;
        this.b = currentColor & 0xFF;
    }

    public ColorPickerScreen(Screen parent, String titleText, int currentColor, Consumer<Integer> onSave) {
        this(parent, Component.literal(titleText), currentColor, onSave);
    }

    @Override
    protected void init() {
        clearWidgets();
        int cx = this.width / 2;
        int topY = Math.max(30, this.height / 2 - 100);

        // Preset color chips
        int chipCols = 8;
        int chipSize = 18;
        int chipStartX = cx - (chipCols * (chipSize + 4)) / 2;
        int chipStartY = topY + 45;

        for (int i = 0; i < PRESETS.length; i++) {
            int col = i % chipCols;
            int row = i / chipCols;
            int presetColor = PRESETS[i];
            int px = chipStartX + col * (chipSize + 4);
            int py = chipStartY + row * (chipSize + 4);

            addRenderableWidget(Button.builder(Component.literal(""), btn -> {
                this.r = (presetColor >> 16) & 0xFF;
                this.g = (presetColor >> 8) & 0xFF;
                this.b = presetColor & 0xFF;
            }).bounds(px, py, chipSize, chipSize).build());
        }

        // RGB Controls
        int ctrlY = topY + 95;

        // Red
        addRenderableWidget(Button.builder(Component.literal("-10"), b -> adjustR(-10)).bounds(cx - 100, ctrlY, 30, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+10"), b -> adjustR(10)).bounds(cx + 70, ctrlY, 30, 20).build());

        // Green
        addRenderableWidget(Button.builder(Component.literal("-10"), b -> adjustG(-10)).bounds(cx - 100, ctrlY + 24, 30, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+10"), b -> adjustG(10)).bounds(cx + 70, ctrlY + 24, 30, 20).build());

        // Blue
        addRenderableWidget(Button.builder(Component.literal("-10"), b -> adjustB(-10)).bounds(cx - 100, ctrlY + 48, 30, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+10"), b -> adjustB(10)).bounds(cx + 70, ctrlY + 48, 30, 20).build());

        // Save / Cancel buttons
        int btnY = ctrlY + 80;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.gui.save"), btn -> {
            int finalColor = (r << 16) | (g << 8) | b;
            onSave.accept(finalColor);
            onClose();
        }).bounds(cx - 105, btnY, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.gui.cancel"), btn -> onClose())
            .bounds(cx + 5, btnY, 100, 20).build());
    }

    private void adjustR(int delta) { this.r = Math.max(0, Math.min(255, this.r + delta)); }
    private void adjustG(int delta) { this.g = Math.max(0, Math.min(255, this.g + delta)); }
    private void adjustB(int delta) { this.b = Math.max(0, Math.min(255, this.b + delta)); }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        // Dark translucent background
        graphics.fill(0, 0, width, height, 0xD0101216);

        int cx = width / 2;
        int topY = Math.max(30, height / 2 - 100);

        // Title
        graphics.centeredText(font, title, cx, topY - 10, 0xFFFFFFFF);

        // Current color swatch
        int currentColor = (0xFF << 24) | (r << 16) | (g << 8) | b;
        graphics.fill(cx - 50, topY + 8, cx + 50, topY + 36, currentColor);
        // Border around swatch
        graphics.fill(cx - 51, topY + 7, cx + 51, topY + 8, 0xFFFFFFFF);
        graphics.fill(cx - 51, topY + 36, cx + 51, topY + 37, 0xFFFFFFFF);
        graphics.fill(cx - 51, topY + 7, cx - 50, topY + 37, 0xFFFFFFFF);
        graphics.fill(cx + 50, topY + 7, cx + 51, topY + 37, 0xFFFFFFFF);

        // Hex string
        String hex = String.format("#%02X%02X%02X", r, g, b);
        int textColor = (r * 299 + g * 587 + b * 114) / 1000 > 128 ? 0xFF000000 : 0xFFFFFFFF;
        graphics.centeredText(font, hex, cx, topY + 18, textColor);

        // Render color chips inside preset buttons
        int chipCols = 8;
        int chipSize = 18;
        int chipStartX = cx - (chipCols * (chipSize + 4)) / 2;
        int chipStartY = topY + 45;

        for (int i = 0; i < PRESETS.length; i++) {
            int col = i % chipCols;
            int row = i / chipCols;
            int presetColor = PRESETS[i];
            int px = chipStartX + col * (chipSize + 4);
            int py = chipStartY + row * (chipSize + 4);
            graphics.fill(px + 2, py + 2, px + chipSize - 2, py + chipSize - 2, 0xFF000000 | presetColor);
        }

        // RGB channel values
        int ctrlY = topY + 95;
        graphics.centeredText(font, Component.translatable("musicisland.color.red", r), cx - 15, ctrlY + 6, 0xFFFF6B6B);
        graphics.centeredText(font, Component.translatable("musicisland.color.green", g), cx - 15, ctrlY + 30, 0xFF51CF66);
        graphics.centeredText(font, Component.translatable("musicisland.color.blue", b), cx - 15, ctrlY + 54, 0xFF339AF0);

        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.gui.setScreen(parent);
        }
    }
}
