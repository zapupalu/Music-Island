package dev.lupasud.musicisland.interop;

import dev.lupasud.musicisland.model.MediaTrack;

import java.util.concurrent.atomic.AtomicReference;

public final class MediaController {
    private static final MediaController INSTANCE = new MediaController();

    private final AtomicReference<MediaTrack> currentTrack = new AtomicReference<>(MediaTrack.EMPTY);
    private final WindowsMediaSession mediaSession;

    private MediaController() {
        this.mediaSession = new WindowsMediaSession(this);
    }

    public static MediaController getInstance() {
        return INSTANCE;
    }

    public void init() {
        mediaSession.start();
    }

    public void stop() {
        mediaSession.stop();
    }

    public MediaTrack getCurrentTrack() {
        return currentTrack.get();
    }

    public void updateTrack(MediaTrack track) {
        currentTrack.set(track != null ? track : MediaTrack.EMPTY);
    }

    public void togglePlayPause() {
        mediaSession.sendPlayPause();
    }

    public void previousTrack() {
        mediaSession.sendPrevious();
    }

    public void nextTrack() {
        mediaSession.sendNext();
    }
}
