package dev.lupasud.musicisland.gui;

import dev.lupasud.musicisland.MusicIslandClient;
import dev.lupasud.musicisland.config.MusicIslandConfig;
import dev.lupasud.musicisland.interop.MediaController;
import dev.lupasud.musicisland.lyrics.LyricsService;
import dev.lupasud.musicisland.model.MediaTrack;
import dev.lupasud.musicisland.render.LyricsRenderer;
import dev.lupasud.musicisland.render.MusicIslandHud;
import dev.lupasud.musicisland.render.OvrSpotRenderer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class MusicIslandSettingsScreen extends Screen {
    public enum IslandTab {
        GENERAL("musicisland.tab.general"),
        ELEMENTS("musicisland.tab.elements"),
        LYRICS("musicisland.tab.lyrics"),
        COLORS("musicisland.tab.colors"),
        POSITION("musicisland.tab.position"),
        CONTROLS("musicisland.tab.controls");

        private final String key;
        IslandTab(String key) { this.key = key; }
        public String getKey() { return key; }
        public Component getComponent() { return Component.translatable(key); }
    }

    public enum OvrTab {
        GENERAL("musicisland.tab.general"),
        ARTWORK("musicisland.tab.artwork"),
        TEXT("musicisland.tab.text"),
        LYRICS("musicisland.tab.lyrics"),
        COLORS("musicisland.tab.colors"),
        POSITION("musicisland.tab.position");

        private final String key;
        OvrTab(String key) { this.key = key; }
        public String getKey() { return key; }
        public Component getComponent() { return Component.translatable(key); }
    }

    private final Screen parent;
    private IslandTab activeIslandTab = IslandTab.GENERAL;
    private OvrTab activeOvrTab = OvrTab.GENERAL;
    private float previewTimer = 0.0f;
    private final LyricsRenderer previewLyrics = new LyricsRenderer();

    public MusicIslandSettingsScreen(Screen parent) {
        super(Component.translatable("musicisland.settings.title"));
        this.parent = parent;
    }

    public MusicIslandSettingsScreen(Screen parent, IslandTab initialTab) {
        this(parent);
        this.activeIslandTab = initialTab != null ? initialTab : IslandTab.GENERAL;
    }

    private static Component onOff(boolean value) {
        return Component.translatable(value ? "musicisland.gui.on" : "musicisland.gui.off");
    }

    @Override
    protected void init() {
        clearWidgets();
        MusicIslandConfig config = MusicIslandClient.config();
        int cx = this.width / 2;

        // 1. Top Mode Switcher Button
        Component modeText = Component.translatable("musicisland.gui.mode_prefix", config.mode.getComponent()).withStyle(ChatFormatting.GOLD);
        addRenderableWidget(Button.builder(modeText, b -> {
            config.mode = (config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND)
                ? MusicIslandConfig.HudMode.OVR_SPOT
                : MusicIslandConfig.HudMode.DYNAMIC_ISLAND;
            config.save();
            init();
        }).bounds(cx - 120, 6, 240, 20).build());

        // 2. Tab Navigation Bar
        int tabY = 28;
        if (config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND) {
            IslandTab[] tabs = IslandTab.values();
            int tabWidth = Math.min(80, (this.width - 20) / tabs.length);
            int totalTabsW = tabs.length * tabWidth;
            int tabStartX = cx - totalTabsW / 2;

            for (int i = 0; i < tabs.length; i++) {
                IslandTab tab = tabs[i];
                int tx = tabStartX + i * tabWidth;
                Component prefix = (tab == activeIslandTab) ? Component.literal("● ") : Component.empty();
                Component label = Component.empty().append(prefix).append(tab.getComponent());
                addRenderableWidget(Button.builder(label, b -> {
                    activeIslandTab = tab;
                    init();
                }).bounds(tx, tabY, tabWidth - 2, 20).build());
            }

            // Tab Content
            int contentY = 52;
            switch (activeIslandTab) {
                case GENERAL -> initIslandGeneralTab(cx, contentY, config);
                case ELEMENTS -> initIslandElementsTab(cx, contentY, config);
                case LYRICS -> initIslandLyricsTab(cx, contentY, config);
                case COLORS -> initIslandColorsTab(cx, contentY, config);
                case POSITION -> initIslandPositionTab(cx, contentY, config);
                case CONTROLS -> initIslandControlsTab(cx, contentY, config);
            }
        } else {
            OvrTab[] tabs = OvrTab.values();
            int tabWidth = Math.min(80, (this.width - 20) / tabs.length);
            int totalTabsW = tabs.length * tabWidth;
            int tabStartX = cx - totalTabsW / 2;

            for (int i = 0; i < tabs.length; i++) {
                OvrTab tab = tabs[i];
                int tx = tabStartX + i * tabWidth;
                Component prefix = (tab == activeOvrTab) ? Component.literal("● ") : Component.empty();
                Component label = Component.empty().append(prefix).append(tab.getComponent());
                addRenderableWidget(Button.builder(label, b -> {
                    activeOvrTab = tab;
                    init();
                }).bounds(tx, tabY, tabWidth - 2, 20).build());
            }

            // Tab Content
            int contentY = 52;
            switch (activeOvrTab) {
                case GENERAL -> initOvrGeneralTab(cx, contentY, config);
                case ARTWORK -> initOvrArtworkTab(cx, contentY, config);
                case TEXT -> initOvrTextTab(cx, contentY, config);
                case LYRICS -> initOvrLyricsTab(cx, contentY, config);
                case COLORS -> initOvrColorsTab(cx, contentY, config);
                case POSITION -> initOvrPositionTab(cx, contentY, config);
            }
        }

        // 3. Bottom Done Button
        int doneY = this.height - 24;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.gui.done"), b -> onClose())
            .bounds(cx - 50, doneY, 100, 20).build());
    }

    // =========================================================================
    // DYNAMIC ISLAND TABS
    // =========================================================================

    private void initIslandGeneralTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.mod_enabled", onOff(config.enabled)), b -> {
            config.enabled = !config.enabled;
            config.save();
            init();
        }).bounds(cx - 155, y, 150, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.auto_hide", onOff(config.autoHide)), b -> {
            config.autoHide = !config.autoHide;
            config.save();
            init();
        }).bounds(cx + 5, y, 150, 20).build());

        int r2 = y + 24;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.scale = Math.max(0.5f, Math.round((config.scale - 0.1f) * 10f) / 10f);
            config.save();
            init();
        }).bounds(cx - 155, r2, 30, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.scale", Math.round(config.scale * 100)), b -> {
            config.scale = 1.0f;
            config.save();
            init();
        }).bounds(cx - 120, r2, 210, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.scale = Math.min(2.0f, Math.round((config.scale + 0.1f) * 10f) / 10f);
            config.save();
            init();
        }).bounds(cx + 95, r2, 30, 20).build());

        int r3 = y + 48;
        addRenderableWidget(Button.builder(Component.literal("-10"), b -> {
            config.customWidth = Math.max(160, config.customWidth - 10);
            config.save();
            init();
        }).bounds(cx - 155, r3, 30, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.width", config.customWidth), b -> {
            config.customWidth = 205;
            config.save();
            init();
        }).bounds(cx - 120, r3, 210, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+10"), b -> {
            config.customWidth = Math.min(360, config.customWidth + 10);
            config.save();
            init();
        }).bounds(cx + 95, r3, 30, 20).build());

        int r4 = y + 72;
        addRenderableWidget(Button.builder(Component.literal("-2"), b -> {
            config.customHeight = Math.max(20, config.customHeight - 2);
            config.save();
            init();
        }).bounds(cx - 155, r4, 30, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.base_height", config.customHeight), b -> {
            config.customHeight = 26;
            config.save();
            init();
        }).bounds(cx - 120, r4, 210, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+2"), b -> {
            config.customHeight = Math.min(48, config.customHeight + 2);
            config.save();
            init();
        }).bounds(cx + 95, r4, 30, 20).build());

        int r5 = y + 96;
        addRenderableWidget(Button.builder(Component.literal("-5%"), b -> {
            config.opacity = Math.max(0.1f, Math.round((config.opacity - 0.05f) * 100f) / 100f);
            config.save();
            init();
        }).bounds(cx - 155, r5, 30, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.opacity", Math.round(config.opacity * 100)), b -> {
            config.opacity = 0.92f;
            config.save();
            init();
        }).bounds(cx - 120, r5, 210, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+5%"), b -> {
            config.opacity = Math.min(1.0f, Math.round((config.opacity + 0.05f) * 100f) / 100f);
            config.save();
            init();
        }).bounds(cx + 95, r5, 30, 20).build());
    }

    private void initIslandElementsTab(int cx, int y, MusicIslandConfig config) {
        int w = 150;
        int leftX = cx - 155;
        int rightX = cx + 5;

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.dot", onOff(config.showDot)), b -> {
            config.showDot = !config.showDot; config.save(); init();
        }).bounds(leftX, y, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.time", onOff(config.showTime)), b -> {
            config.showTime = !config.showTime; config.save(); init();
        }).bounds(leftX, y + 24, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.artwork", onOff(config.showArtwork)), b -> {
            config.showArtwork = !config.showArtwork; config.save(); init();
        }).bounds(leftX, y + 48, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.title", onOff(config.showTitle)), b -> {
            config.showTitle = !config.showTitle; config.save(); init();
        }).bounds(leftX, y + 72, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.artist", onOff(config.showArtist)), b -> {
            config.showArtist = !config.showArtist; config.save(); init();
        }).bounds(leftX, y + 96, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.album", onOff(config.showAlbum)), b -> {
            config.showAlbum = !config.showAlbum; config.save(); init();
        }).bounds(rightX, y, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.lyrics", onOff(config.showLyrics)), b -> {
            config.showLyrics = !config.showLyrics; config.save(); init();
        }).bounds(rightX, y + 24, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.play_pause", onOff(config.showPlayPause)), b -> {
            config.showPlayPause = !config.showPlayPause; config.save(); init();
        }).bounds(rightX, y + 48, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.element.visualizer", onOff(config.showVisualizer)), b -> {
            config.showVisualizer = !config.showVisualizer; config.save(); init();
        }).bounds(rightX, y + 72, w, 20).build());
    }

    private void initIslandLyricsTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.module", onOff(config.lyricsEnabled)), b -> {
            config.lyricsEnabled = !config.lyricsEnabled;
            config.save();
            LyricsService.getInstance().tick(MediaController.getInstance().getCurrentTrack(), config.enabled && config.lyricsEnabled);
            init();
        }).bounds(cx - 155, y, 150, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.show", onOff(config.showLyrics)), b -> {
            config.showLyrics = !config.showLyrics;
            config.save();
            init();
        }).bounds(cx + 5, y, 150, 20).build());

        int r2 = y + 24;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.position", config.lyricsPosition.getComponent()), b -> {
            int nextIdx = (config.lyricsPosition.ordinal() + 1) % MusicIslandConfig.LyricsPosition.values().length;
            config.lyricsPosition = MusicIslandConfig.LyricsPosition.values()[nextIdx];
            config.save();
            init();
        }).bounds(cx - 155, r2, 150, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.max_lines", config.lyricsMaxLines), b -> {
            config.lyricsMaxLines = config.lyricsMaxLines >= 3 ? 1 : config.lyricsMaxLines + 1;
            config.save();
            init();
        }).bounds(cx + 5, r2, 150, 20).build());

        int r3 = y + 48;
        addRenderableWidget(Button.builder(Component.literal("-2"), b -> {
            config.lyricsTextSpeed = Math.max(10f, config.lyricsTextSpeed - 2f); config.save(); init();
        }).bounds(cx - 155, r3, 30, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.text_speed", Math.round(config.lyricsTextSpeed)), b -> {
            config.lyricsTextSpeed = 26f; config.save(); init();
        }).bounds(cx - 120, r3, 210, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+2"), b -> {
            config.lyricsTextSpeed = Math.min(80f, config.lyricsTextSpeed + 2f); config.save(); init();
        }).bounds(cx + 95, r3, 30, 20).build());

        int r4 = y + 72;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.pause_start", String.format(java.util.Locale.ROOT, "%.1f", config.lyricsPauseStart)), b -> {
            config.lyricsPauseStart = config.lyricsPauseStart >= 4.0f ? 0.5f : config.lyricsPauseStart + 0.5f;
            config.save(); init();
        }).bounds(cx - 155, r4, 150, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.pause_end", String.format(java.util.Locale.ROOT, "%.1f", config.lyricsPauseEnd)), b -> {
            config.lyricsPauseEnd = config.lyricsPauseEnd >= 4.0f ? 0.5f : config.lyricsPauseEnd + 0.5f;
            config.save(); init();
        }).bounds(cx + 5, r4, 150, 20).build());

        int r5 = y + 96;
        addRenderableWidget(Button.builder(config.lyricsScrollDirection.getComponent(), b -> {
            int nextIdx = (config.lyricsScrollDirection.ordinal() + 1) % MusicIslandConfig.LyricsScrollDirection.values().length;
            config.lyricsScrollDirection = MusicIslandConfig.LyricsScrollDirection.values()[nextIdx];
            config.save(); init();
        }).bounds(cx - 155, r5, 150, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.reset_delay", Math.round(config.lyricsResetDelay)), b -> {
            float[] presets = {1f, 2f, 3f, 5f, 10f};
            float next = 5f;
            for (int i = 0; i < presets.length; i++) {
                if (Math.abs(config.lyricsResetDelay - presets[i]) < 0.2f) {
                    next = presets[(i + 1) % presets.length];
                    break;
                }
            }
            config.lyricsResetDelay = next;
            config.save(); init();
        }).bounds(cx + 5, r5, 150, 20).build());

        int r6 = y + 120;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.btn_minus_100ms"), b -> {
            config.lyricsOffsetMs = Math.max(-10000, config.lyricsOffsetMs - 100); config.save(); init();
        }).bounds(cx - 155, r6, 65, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.offset_sec", String.format(java.util.Locale.ROOT, "%+.1f", config.lyricsOffsetMs / 1000.0)), b -> {
            config.lyricsOffsetMs = 0; config.save(); init();
        }).bounds(cx - 86, r6, 172, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.btn_plus_100ms"), b -> {
            config.lyricsOffsetMs = Math.min(10000, config.lyricsOffsetMs + 100); config.save(); init();
        }).bounds(cx + 90, r6, 65, 20).build());
    }

    private void initIslandColorsTab(int cx, int y, MusicIslandConfig config) {
        int w = 150;
        int leftX = cx - 155;
        int rightX = cx + 5;

        addColorButton(leftX, y, w, "musicisland.color.dot", config.colorDot, c -> config.colorDot = c);
        addColorButton(leftX, y + 24, w, "musicisland.color.time", config.colorTime, c -> config.colorTime = c);
        addColorButton(leftX, y + 48, w, "musicisland.color.title", config.colorTitle, c -> config.colorTitle = c);
        addColorButton(leftX, y + 72, w, "musicisland.color.artist", config.colorArtist, c -> config.colorArtist = c);
        addColorButton(leftX, y + 96, w, "musicisland.color.album", config.colorAlbum, c -> config.colorAlbum = c);

        addColorButton(rightX, y, w, "musicisland.color.lyrics", config.colorLyrics, c -> config.colorLyrics = c);
        addColorButton(rightX, y + 24, w, "musicisland.color.play_pause", config.colorPlayPause, c -> config.colorPlayPause = c);
        addColorButton(rightX, y + 48, w, "musicisland.color.visualizer", config.colorVisualizer, c -> config.colorVisualizer = c);
        addColorButton(rightX, y + 72, w, "musicisland.color.border", config.colorBorder, c -> config.colorBorder = c);
        addColorButton(rightX, y + 96, w, "musicisland.color.background", config.colorBackground, c -> config.colorBackground = c);

        addRenderableWidget(Button.builder(Component.translatable("musicisland.color.reset_island"), b -> {
            config.resetColors();
            config.save();
            init();
        }).bounds(cx - 120, y + 122, 240, 20).build());
    }

    private void initIslandPositionTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.top_center"), b -> {
            config.preset = MusicIslandConfig.Preset.TOP_CENTER; config.save(); init();
        }).bounds(cx - 155, y, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.top_left"), b -> {
            config.preset = MusicIslandConfig.Preset.TOP_LEFT; config.save(); init();
        }).bounds(cx - 50, y, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.top_right"), b -> {
            config.preset = MusicIslandConfig.Preset.TOP_RIGHT; config.save(); init();
        }).bounds(cx + 55, y, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.center"), b -> {
            config.preset = MusicIslandConfig.Preset.CENTER; config.save(); init();
        }).bounds(cx - 105, y + 24, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.bottom_center"), b -> {
            config.preset = MusicIslandConfig.Preset.BOTTOM_CENTER; config.save(); init();
        }).bounds(cx + 5, y + 24, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.position.drag_editor_btn"), b -> {
            if (this.minecraft != null) {
                this.minecraft.gui.setScreen(new MusicIslandPositionScreen(this));
            }
        }).bounds(cx - 155, y + 52, 310, 20).build());
    }

    private void initIslandControlsTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.translatable("musicisland.controls.rebind_keys"), b -> {
            if (this.minecraft != null) {
                this.minecraft.gui.setScreen(new MusicIslandControlsScreen(this));
            }
        }).bounds(cx - 155, y + 12, 310, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.calibrate_adv"), b -> {
            if (this.minecraft != null) {
                this.minecraft.gui.setScreen(new LyricsSettingsScreen(this));
            }
        }).bounds(cx - 155, y + 38, 310, 20).build());
    }

    // =========================================================================
    // OVRSPOT TABS
    // =========================================================================

    private void initOvrGeneralTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.mod_enabled", onOff(config.enabled)), b -> {
            config.enabled = !config.enabled;
            config.save();
            init();
        }).bounds(cx - 155, y, 150, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.auto_hide", onOff(config.autoHide)), b -> {
            config.autoHide = !config.autoHide;
            config.save();
            init();
        }).bounds(cx + 5, y, 150, 20).build());

        int r2 = y + 24;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrScale = Math.max(0.5f, Math.round((config.ovrScale - 0.1f) * 10f) / 10f);
            config.save();
            init();
        }).bounds(cx - 155, r2, 30, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.ovr_scale", Math.round(config.ovrScale * 100)), b -> {
            config.ovrScale = 1.0f;
            config.save();
            init();
        }).bounds(cx - 120, r2, 210, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrScale = Math.min(2.0f, Math.round((config.ovrScale + 0.1f) * 10f) / 10f);
            config.save();
            init();
        }).bounds(cx + 95, r2, 30, 20).build());

        int r3 = y + 48;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.shadow", onOff(config.ovrShadow)), b -> {
            config.ovrShadow = !config.ovrShadow;
            config.save();
            init();
        }).bounds(cx - 155, r3, 150, 20).build());

        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrShadowSize = Math.max(0, config.ovrShadowSize - 2);
            config.save();
            init();
        }).bounds(cx + 5, r3, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.shadow_size", config.ovrShadowSize), b -> {
            config.ovrShadowSize = 6;
            config.save();
            init();
        }).bounds(cx + 34, r3, 93, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrShadowSize = Math.min(20, config.ovrShadowSize + 2);
            config.save();
            init();
        }).bounds(cx + 130, r3, 25, 20).build());

        int r4 = y + 72;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrShadowOpacity = Math.max(0.0f, Math.round((config.ovrShadowOpacity - 0.10f) * 100f) / 100f);
            config.save();
            init();
        }).bounds(cx - 155, r4, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.shadow_opacity", Math.round(config.ovrShadowOpacity * 100)), b -> {
            config.ovrShadowOpacity = 0.60f;
            config.save();
            init();
        }).bounds(cx - 126, r4, 95, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrShadowOpacity = Math.min(1.0f, Math.round((config.ovrShadowOpacity + 0.10f) * 100f) / 100f);
            config.save();
            init();
        }).bounds(cx - 28, r4, 23, 20).build());

        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrBackgroundOpacity = Math.max(0.0f, Math.round((config.ovrBackgroundOpacity - 0.05f) * 100f) / 100f);
            config.save();
            init();
        }).bounds(cx + 5, r4, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.setting.bg_opacity", Math.round(config.ovrBackgroundOpacity * 100)), b -> {
            config.ovrBackgroundOpacity = 0.85f;
            config.save();
            init();
        }).bounds(cx + 34, r4, 93, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrBackgroundOpacity = Math.min(1.0f, Math.round((config.ovrBackgroundOpacity + 0.05f) * 100f) / 100f);
            config.save();
            init();
        }).bounds(cx + 130, r4, 25, 20).build());
    }

    private void initOvrArtworkTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.translatable("musicisland.artwork.show", onOff(config.showArtwork)), b -> {
            config.showArtwork = !config.showArtwork;
            config.save();
            init();
        }).bounds(cx - 155, y, 310, 20).build());

        int r2 = y + 24;
        addRenderableWidget(Button.builder(Component.literal("-16"), b -> {
            config.ovrArtworkSize = Math.max(64, config.ovrArtworkSize - 16);
            config.save();
            init();
        }).bounds(cx - 155, r2, 32, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.artwork.size", config.ovrArtworkSize), b -> {
            config.ovrArtworkSize = 160;
            config.save();
            init();
        }).bounds(cx - 120, r2, 206, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+16"), b -> {
            config.ovrArtworkSize = Math.min(512, config.ovrArtworkSize + 16);
            config.save();
            init();
        }).bounds(cx + 89, r2, 32, 20).build());

        int r3 = y + 48;
        int[] artSizes = {96, 128, 160, 200, 256};
        int btnW = 58;
        for (int i = 0; i < artSizes.length; i++) {
            int size = artSizes[i];
            int bx = cx - 155 + i * (btnW + 5);
            addRenderableWidget(Button.builder(Component.literal(size + "px"), b -> {
                config.ovrArtworkSize = size;
                config.save();
                init();
            }).bounds(bx, r3, btnW, 20).build());
        }

        int r4 = y + 72;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrArtworkOpacity = Math.max(0.1f, Math.round((config.ovrArtworkOpacity - 0.05f) * 100f) / 100f);
            config.save();
            init();
        }).bounds(cx - 155, r4, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.artwork.opacity", Math.round(config.ovrArtworkOpacity * 100)), b -> {
            config.ovrArtworkOpacity = 1.0f;
            config.save();
            init();
        }).bounds(cx - 126, r4, 95, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrArtworkOpacity = Math.min(1.0f, Math.round((config.ovrArtworkOpacity + 0.05f) * 100f) / 100f);
            config.save();
            init();
        }).bounds(cx - 28, r4, 23, 20).build());

        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrCornerRadius = Math.max(0, config.ovrCornerRadius - 2);
            config.save();
            init();
        }).bounds(cx + 5, r4, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.artwork.corner_radius", config.ovrCornerRadius), b -> {
            config.ovrCornerRadius = 12;
            config.save();
            init();
        }).bounds(cx + 34, r4, 93, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrCornerRadius = Math.min(32, config.ovrCornerRadius + 2);
            config.save();
            init();
        }).bounds(cx + 130, r4, 25, 20).build());
    }

    private void initOvrTextTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrTitleSize = Math.max(0.6f, Math.round((config.ovrTitleSize - 0.05f) * 100f) / 100f);
            config.save(); init();
        }).bounds(cx - 155, y, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.text.title_size", Math.round(config.ovrTitleSize * 100)), b -> {
            config.ovrTitleSize = 1.15f; config.save(); init();
        }).bounds(cx - 126, y, 95, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrTitleSize = Math.min(2.5f, Math.round((config.ovrTitleSize + 0.05f) * 100f) / 100f);
            config.save(); init();
        }).bounds(cx - 28, y, 23, 20).build());

        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrArtistSize = Math.max(0.5f, Math.round((config.ovrArtistSize - 0.05f) * 100f) / 100f);
            config.save(); init();
        }).bounds(cx + 5, y, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.text.artist_size", Math.round(config.ovrArtistSize * 100)), b -> {
            config.ovrArtistSize = 0.90f; config.save(); init();
        }).bounds(cx + 34, y, 93, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrArtistSize = Math.min(2.0f, Math.round((config.ovrArtistSize + 0.05f) * 100f) / 100f);
            config.save(); init();
        }).bounds(cx + 130, y, 25, 20).build());

        int r2 = y + 24;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrLyricsSize = Math.max(0.5f, Math.round((config.ovrLyricsSize - 0.05f) * 100f) / 100f);
            config.save(); init();
        }).bounds(cx - 155, r2, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.text.lyrics_size", Math.round(config.ovrLyricsSize * 100)), b -> {
            config.ovrLyricsSize = 0.85f; config.save(); init();
        }).bounds(cx - 126, r2, 95, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrLyricsSize = Math.min(2.0f, Math.round((config.ovrLyricsSize + 0.05f) * 100f) / 100f);
            config.save(); init();
        }).bounds(cx - 28, r2, 23, 20).build());

        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrTextSpeed = Math.max(10f, config.ovrTextSpeed - 2f); config.save(); init();
        }).bounds(cx + 5, r2, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.text.speed", Math.round(config.ovrTextSpeed)), b -> {
            config.ovrTextSpeed = 24f; config.save(); init();
        }).bounds(cx + 34, r2, 93, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrTextSpeed = Math.min(80f, config.ovrTextSpeed + 2f); config.save(); init();
        }).bounds(cx + 130, r2, 25, 20).build());

        int r3 = y + 48;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrResetDelay = Math.max(0.5f, Math.round((config.ovrResetDelay - 0.5f) * 10f) / 10f);
            config.save(); init();
        }).bounds(cx - 155, r3, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.reset_delay_float", config.ovrResetDelay), b -> {
            config.ovrResetDelay = 3.0f; config.save(); init();
        }).bounds(cx - 126, r3, 95, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrResetDelay = Math.min(10.0f, Math.round((config.ovrResetDelay + 0.5f) * 10f) / 10f);
            config.save(); init();
        }).bounds(cx - 28, r3, 23, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.scroll_mode", config.ovrScrollDirection.getComponent()), b -> {
            config.ovrScrollDirection = (config.ovrScrollDirection == MusicIslandConfig.LyricsScrollDirection.PING_PONG)
                ? MusicIslandConfig.LyricsScrollDirection.LEFT_TO_RIGHT
                : MusicIslandConfig.LyricsScrollDirection.PING_PONG;
            config.save(); init();
        }).bounds(cx + 5, r3, 150, 20).build());
    }

    private void initOvrLyricsTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.ovr_show", onOff(config.ovrShowLyrics)), b -> {
            config.ovrShowLyrics = !config.ovrShowLyrics;
            config.save();
            LyricsService.getInstance().tick(MediaController.getInstance().getCurrentTrack(), config.enabled && config.ovrShowLyrics);
            init();
        }).bounds(cx - 155, y, 150, 20).build());

        addRenderableWidget(Button.builder(Component.literal("-50"), b -> {
            config.ovrLyricsOffsetMs = Math.max(-10000, config.ovrLyricsOffsetMs - 50); config.save(); init();
        }).bounds(cx + 5, y, 32, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.offset_ms", config.ovrLyricsOffsetMs), b -> {
            config.ovrLyricsOffsetMs = 0; config.save(); init();
        }).bounds(cx + 40, y, 82, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+50"), b -> {
            config.ovrLyricsOffsetMs = Math.min(10000, config.ovrLyricsOffsetMs + 50); config.save(); init();
        }).bounds(cx + 125, y, 30, 20).build());

        int r2 = y + 24;
        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrPauseStart = Math.max(0.2f, Math.round((config.ovrPauseStart - 0.5f) * 10f) / 10f);
            config.save(); init();
        }).bounds(cx - 155, r2, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.pause_start", String.format(java.util.Locale.ROOT, "%.1f", config.ovrPauseStart)), b -> {
            config.ovrPauseStart = 2.0f; config.save(); init();
        }).bounds(cx - 126, r2, 95, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrPauseStart = Math.min(8.0f, Math.round((config.ovrPauseStart + 0.5f) * 10f) / 10f);
            config.save(); init();
        }).bounds(cx - 28, r2, 23, 20).build());

        addRenderableWidget(Button.builder(Component.literal("-"), b -> {
            config.ovrPauseEnd = Math.max(0.2f, Math.round((config.ovrPauseEnd - 0.5f) * 10f) / 10f);
            config.save(); init();
        }).bounds(cx + 5, r2, 26, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.pause_end", String.format(java.util.Locale.ROOT, "%.1f", config.ovrPauseEnd)), b -> {
            config.ovrPauseEnd = 2.0f; config.save(); init();
        }).bounds(cx + 34, r2, 93, 20).build());

        addRenderableWidget(Button.builder(Component.literal("+"), b -> {
            config.ovrPauseEnd = Math.min(8.0f, Math.round((config.ovrPauseEnd + 0.5f) * 10f) / 10f);
            config.save(); init();
        }).bounds(cx + 130, r2, 25, 20).build());

        int r3 = y + 50;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.calibrate"), b -> {
            if (this.minecraft != null) {
                this.minecraft.gui.setScreen(new LyricsSettingsScreen(this));
            }
        }).bounds(cx - 155, r3, 310, 20).build());
    }

    private void initOvrColorsTab(int cx, int y, MusicIslandConfig config) {
        int w = 150;
        int leftX = cx - 155;
        int rightX = cx + 5;

        addColorButton(leftX, y, w, "musicisland.color.background", config.ovrColorBackground, c -> config.ovrColorBackground = c);
        addColorButton(rightX, y, w, "musicisland.color.title", config.ovrColorTitle, c -> config.ovrColorTitle = c);

        addColorButton(leftX, y + 24, w, "musicisland.color.artist", config.ovrColorArtist, c -> config.ovrColorArtist = c);
        addColorButton(rightX, y + 24, w, "musicisland.color.lyrics", config.ovrColorLyrics, c -> config.ovrColorLyrics = c);

        addColorButton(leftX, y + 48, w, "musicisland.color.border", config.ovrColorBorder, c -> config.ovrColorBorder = c);
        addColorButton(rightX, y + 48, w, "musicisland.color.shadow", config.ovrColorShadow, c -> config.ovrColorShadow = c);

        addRenderableWidget(Button.builder(Component.translatable("musicisland.color.reset_ovr"), b -> {
            config.resetOvrColors();
            config.save();
            init();
        }).bounds(cx - 120, y + 74, 240, 20).build());
    }

    private void initOvrPositionTab(int cx, int y, MusicIslandConfig config) {
        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.top_left"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.TOP_LEFT; config.save(); init();
        }).bounds(cx - 155, y, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.top_center"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.TOP_CENTER; config.save(); init();
        }).bounds(cx - 50, y, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.top_right"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.TOP_RIGHT; config.save(); init();
        }).bounds(cx + 55, y, 100, 20).build());

        int r2 = y + 24;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.center_left"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.CENTER_LEFT; config.save(); init();
        }).bounds(cx - 155, r2, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.center"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.CENTER; config.save(); init();
        }).bounds(cx - 50, r2, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.center_right"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.CENTER_RIGHT; config.save(); init();
        }).bounds(cx + 55, r2, 100, 20).build());

        int r3 = y + 48;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.bottom_left"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.BOTTOM_LEFT; config.save(); init();
        }).bounds(cx - 155, r3, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.bottom_center"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.BOTTOM_CENTER; config.save(); init();
        }).bounds(cx - 50, r3, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.preset.bottom_right"), b -> {
            config.ovrPreset = MusicIslandConfig.Preset.BOTTOM_RIGHT; config.save(); init();
        }).bounds(cx + 55, r3, 100, 20).build());

        int r4 = y + 74;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.position.drag_editor_btn"), b -> {
            if (this.minecraft != null) {
                this.minecraft.gui.setScreen(new MusicIslandPositionScreen(this));
            }
        }).bounds(cx - 155, r4, 310, 20).build());
    }

    private void addColorButton(int x, int y, int w, String labelKey, int currentColor, java.util.function.Consumer<Integer> setter) {
        String hex = String.format("#%06X", currentColor & 0xFFFFFF);
        Component btnText = Component.translatable(labelKey).append(": " + hex);
        addRenderableWidget(Button.builder(btnText, b -> {
            if (this.minecraft != null) {
                this.minecraft.gui.setScreen(new ColorPickerScreen(this, Component.translatable(labelKey), currentColor, c -> {
                    setter.accept(c);
                    MusicIslandClient.config().save();
                }));
            }
        }).bounds(x, y, w, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        previewTimer += partialTick * 0.05f;

        graphics.fill(0, 0, width, height, 0xD0101216);

        int cx = width / 2;
        MusicIslandConfig config = MusicIslandClient.config();

        long now = System.nanoTime();
        long previewPos = (long) (previewTimer * 1000.0f) % 25_000L;
        previewLyrics.update("preview|150000", new dev.lupasud.musicisland.lyrics.LyricsDocument.Line(0, 25_000, "I can feel the darkness coming to take me away..."), previewPos, now, font);

        if (config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND) {
            if (activeIslandTab == IslandTab.LYRICS) {
                graphics.centeredText(font, LyricsService.getInstance().statusComponent(), cx, 192, 0xFF87C6FF);
            }

            int previewY = this.height - 66;
            graphics.centeredText(font, Component.translatable("musicisland.hud.preview_island"), cx, previewY - 14, 0xFFBAC6D4);

            int previewW = config.customWidth;
            int previewH = config.customHeight;
            if (config.lyricsEnabled && config.showLyrics) {
                if (config.lyricsMaxLines == 2) previewH = Math.max(previewH, 34);
                else if (config.lyricsMaxLines >= 3) previewH = Math.max(previewH, 44);
            }

            int px = cx - previewW / 2;
            int py = previewY;

            MusicIslandHud.renderIsland(
                graphics, font, px, py, previewW, previewH,
                MediaTrack.PREVIEW, true, config, 1.0f,
                previewTimer * 4.0f, previewTimer, partialTick, previewLyrics
            );
        } else {
            if (activeOvrTab == OvrTab.LYRICS) {
                graphics.centeredText(font, LyricsService.getInstance().statusComponent(), cx, 192, 0xFF87C6FF);
            }

            int previewY = this.height - 68;
            graphics.centeredText(font, Component.translatable("musicisland.hud.preview_ovr"), cx, previewY - 13, 0xFFBAC6D4);

            int cardW = OvrSpotRenderer.calculateCardWidth(config);
            int cardH = OvrSpotRenderer.calculateCardHeight(config, font, config.ovrShowLyrics);
            float previewScale = Math.min(1.0f, 54.0f / (float) cardH);
            int effW = Math.round(cardW * previewScale);
            int px = cx - effW / 2;
            int py = previewY;

            graphics.pose().pushMatrix();
            graphics.pose().scaleAround(previewScale, previewScale, (float) px, (float) py);
            OvrSpotRenderer.render(
                graphics, font, px, py,
                MediaTrack.PREVIEW, true, config, 1.0f,
                previewTimer, partialTick, previewLyrics
            );
            graphics.pose().popMatrix();
        }

        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.gui.setScreen(parent);
        }
    }
}
