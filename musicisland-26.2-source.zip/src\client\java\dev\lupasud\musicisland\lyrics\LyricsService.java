package dev.lupasud.musicisland.lyrics;

import com.google.gson.*;
import dev.lupasud.musicisland.model.MediaTrack;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.chat.Component;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.*;

/** Background LRCLIB lookup and local file loader. */
public final class LyricsService {
    private static final LyricsService INSTANCE = new LyricsService();
    public static LyricsService getInstance() { return INSTANCE; }

    public record Key(String title, String artist, long duration) {}
    private record Cached(LyricsDocument document, long expires, String sourceKey) {}
    private record Published(Key key, LyricsDocument document, String sourceKey) {}

    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "MusicIsland-lyrics");
        t.setDaemon(true);
        return t;
    });

    private final Map<Key, Cached> memory = new LinkedHashMap<>(64, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Key, Cached> e) { return size() > 64; }
    };

    private volatile Published published;
    private volatile Component status = Component.translatable("musicisland.lyrics.status.disabled");
    private Key active;
    private long generation, retryAt;
    private boolean closed;
    private Future<?> pending;

    private LyricsService() {}

    public Component statusComponent() { return status; }
    public String status() { return status.getString(); }

    private static Key key(MediaTrack track) {
        if (track == null || !track.hasSession() || track.title() == null || track.title().isBlank()) {
            return null;
        }
        return new Key(track.title().strip(), track.artist() != null ? track.artist().strip() : "", track.durationMs());
    }

    public LyricsDocument documentFor(MediaTrack track) {
        Published value = published;
        return value != null && value.key.equals(key(track)) ? value.document : null;
    }

    public synchronized void tick(MediaTrack track, boolean enabled) {
        if (closed) return;
        Key next = enabled ? key(track) : null;
        if (!Objects.equals(next, active)) {
            generation++;
            active = next;
            published = null;
            retryAt = 0;
            if (pending != null) pending.cancel(true);
            pending = null;
        }
        if (next == null) {
            status = enabled ? Component.translatable("musicisland.lyrics.status.no_track") : Component.translatable("musicisland.lyrics.status.disabled");
            return;
        }
        if (published != null || pending != null || System.currentTimeMillis() < retryAt) {
            return;
        }

        // Preview track special case
        if ("Under Your Spell".equalsIgnoreCase(next.title()) && "Snow Strippers".equalsIgnoreCase(next.artist())) {
            String sampleLrc = """
                [00:01.00]Under your spell
                [00:04.50]I can feel the darkness coming to take me away...
                [00:10.00]Snow Strippers in the night
                [00:15.00]Nothing else matters now
                [00:20.00]Under your spell again
                [00:26.00]I can feel it coming over me
                [00:32.00]Under your spell...
                """;
            LyricsDocument doc = LyricsDocument.parse(sampleLrc, 150_000);
            published = new Published(next, doc, "musicisland.lyrics.source.preview");
            status = Component.translatable("musicisland.lyrics.status.preview");
            return;
        }

        long request = generation;
        status = Component.translatable("musicisland.lyrics.status.searching");
        pending = worker.submit(() -> load(next, request));
    }

    private void load(Key key, long request) {
        LyricsDocument doc = null;
        String sourceKey = "musicisland.lyrics.source.lrclib";
        boolean failed = false;

        try {
            Cached cached = memory.get(key);
            if (cached != null && cached.expires > System.currentTimeMillis()) {
                doc = cached.document;
                sourceKey = cached.sourceKey;
            } else {
                // 1. Try local disk cache or user-supplied .lrc
                String lrc = readDisk(key);
                if (lrc != null) {
                    sourceKey = "musicisland.lyrics.source.local";
                } else {
                    // 2. Try online LRCLIB
                    lrc = fetch(key);
                    if (lrc != null) {
                        sourceKey = "musicisland.lyrics.source.lrclib";
                        writeDisk(key, lrc);
                    }
                }

                if (lrc != null) {
                    doc = LyricsDocument.parse(lrc, key.duration);
                    if (doc.lines().isEmpty()) doc = null;
                }

                memory.put(key, new Cached(doc, System.currentTimeMillis() + (doc == null ? 600_000 : 86_400_000), sourceKey));
            }
        } catch (Exception e) {
            failed = true;
        }

        synchronized (this) {
            if (closed || request != generation || !key.equals(active)) return;
            pending = null;
            if (doc != null) {
                published = new Published(key, doc, sourceKey);
                status = Component.translatable("musicisland.lyrics.status.loaded", Component.translatable(sourceKey));
            } else {
                retryAt = System.currentTimeMillis() + (failed ? 60_000 : 600_000);
                status = failed 
                    ? Component.translatable("musicisland.lyrics.status.unavailable") 
                    : Component.translatable("musicisland.lyrics.status.not_found");
            }
        }
    }

    private static String encode(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static String fetch(Key key) throws IOException {
        String params = "track_name=" + encode(key.title);
        if (!key.artist.isBlank()) {
            params += "&artist_name=" + encode(key.artist);
        }
        if (key.duration > 0) {
            params += "&duration=" + (key.duration / 1000.0);
        }

        JsonElement exact = request("get?" + params);
        String lyric = matching(exact, key);
        if (lyric != null) return lyric;
        if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException();

        // Fallback search
        JsonElement search = request("search?" + params);
        if (search != null && search.isJsonArray()) {
            for (JsonElement candidate : search.getAsJsonArray()) {
                lyric = matching(candidate, key);
                if (lyric != null) return lyric;
            }
        }
        return null;
    }

    public static String normalize(String value) {
        return Normalizer.normalize(value, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT).strip().replaceAll("\\s+", " ");
    }

    private static String matching(JsonElement value, Key key) {
        if (value == null || !value.isJsonObject()) return null;
        try {
            JsonObject item = value.getAsJsonObject();
            if (!key.title.isBlank() && item.has("trackName")) {
                if (!normalize(item.get("trackName").getAsString()).contains(normalize(key.title)) &&
                    !normalize(key.title).contains(normalize(item.get("trackName").getAsString()))) {
                    return null;
                }
            }
            if (!key.artist.isBlank() && item.has("artistName")) {
                if (!normalize(item.get("artistName").getAsString()).contains(normalize(key.artist)) &&
                    !normalize(key.artist).contains(normalize(item.get("artistName").getAsString()))) {
                    return null;
                }
            }

            // Prefer syncedLyrics, then plainLyrics
            if (item.has("syncedLyrics")) {
                JsonElement synced = item.get("syncedLyrics");
                if (synced != null && !synced.isJsonNull() && !synced.getAsString().isBlank()) {
                    return synced.getAsString();
                }
            }
            if (item.has("plainLyrics")) {
                JsonElement plain = item.get("plainLyrics");
                if (plain != null && !plain.isJsonNull() && !plain.getAsString().isBlank()) {
                    return plain.getAsString();
                }
            }
            return null;
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static JsonElement request(String suffix) throws IOException {
        HttpURLConnection c = (HttpURLConnection) URI.create("https://lrclib.net/api/" + suffix).toURL().openConnection();
        c.setConnectTimeout(4000);
        c.setReadTimeout(4000);
        c.setInstanceFollowRedirects(false);
        c.setRequestProperty("User-Agent", "MusicIsland/26.2 (Minecraft Lyrics HUD)");
        c.setRequestProperty("Accept", "application/json");
        try {
            int code = c.getResponseCode();
            if (code == 404) return null;
            if (code != 200) throw new IOException("LRCLIB HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream body = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(8);
                for (int n; (n = in.read(buffer)) != -1;) {
                    if (Thread.currentThread().isInterrupted() || System.nanoTime() > deadline) {
                        throw new InterruptedIOException();
                    }
                    if (body.size() + n > 1_000_000) throw new IOException("Response exceeds limit");
                    body.write(buffer, 0, n);
                }
                return JsonParser.parseString(body.toString(StandardCharsets.UTF_8));
            }
        } finally {
            c.disconnect();
        }
    }

    private static Path disk(Key key) throws Exception {
        String name = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest((key.title + "\u0000" + key.artist + "\u0000" + key.duration).getBytes(StandardCharsets.UTF_8)));
        return FabricLoader.getInstance().getConfigDir().resolve("musicisland-lyrics").resolve(name + ".lrc");
    }

    private static String readDisk(Key key) {
        try {
            Path lyricsDir = FabricLoader.getInstance().getConfigDir().resolve("musicisland-lyrics");
            if (Files.isDirectory(lyricsDir)) {
                // Check named file: "Artist - Title.lrc" or "Title.lrc"
                String cleanTitle = key.title.replaceAll("[\\\\/:*?\"<>|]", "_");
                String cleanArtist = key.artist.replaceAll("[\\\\/:*?\"<>|]", "_");
                Path named1 = lyricsDir.resolve(cleanArtist + " - " + cleanTitle + ".lrc");
                if (Files.isRegularFile(named1)) return Files.readString(named1);
                Path named2 = lyricsDir.resolve(cleanTitle + ".lrc");
                if (Files.isRegularFile(named2)) return Files.readString(named2);
            }
            Path path = disk(key);
            if (Files.isRegularFile(path) && Files.size(path) <= 1_000_000 && System.currentTimeMillis() - Files.getLastModifiedTime(path).toMillis() < 14 * 86_400_000L) {
                return Files.readString(path);
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static void writeDisk(Key key, String lyrics) {
        try {
            Path path = disk(key);
            Files.createDirectories(path.getParent());
            Path temp = Files.createTempFile(path.getParent(), "lyrics-", ".tmp");
            try {
                Files.writeString(temp, lyrics);
                Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
            } finally {
                Files.deleteIfExists(temp);
            }
        } catch (Exception ignored) {}
    }

    public synchronized void close() {
        closed = true;
        generation++;
        published = null;
        if (pending != null) pending.cancel(true);
        worker.shutdownNow();
    }
}
