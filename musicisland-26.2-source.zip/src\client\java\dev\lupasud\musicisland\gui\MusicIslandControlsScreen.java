package dev.lupasud.musicisland.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.lupasud.musicisland.MusicIslandClient;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class MusicIslandControlsScreen extends Screen {
    private final Screen parent;
    private KeyMapping selectedMapping = null;
    private Button prevButton;
    private Button playPauseButton;
    private Button nextButton;
    private String conflictWarning = null;

    public MusicIslandControlsScreen(Screen parent) {
        super(Component.translatable("musicisland.controls.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        clearWidgets();
        conflictWarning = null;

        int panelW = 270;
        int panelH = 218;
        int panelX = (this.width - panelW) / 2;
        int panelY = (this.height - panelH) / 2;

        int y = panelY + 38;

        prevButton = Button.builder(getKeyComponent(MusicIslandClient.prevTrackKey), b -> selectKey(MusicIslandClient.prevTrackKey))
                .bounds(panelX + 140, y, 115, 20)
                .build();
        addRenderableWidget(prevButton);

        y += 28;
        playPauseButton = Button.builder(getKeyComponent(MusicIslandClient.playPauseKey), b -> selectKey(MusicIslandClient.playPauseKey))
                .bounds(panelX + 140, y, 115, 20)
                .build();
        addRenderableWidget(playPauseButton);

        y += 28;
        nextButton = Button.builder(getKeyComponent(MusicIslandClient.nextTrackKey), b -> selectKey(MusicIslandClient.nextTrackKey))
                .bounds(panelX + 140, y, 115, 20)
                .build();
        addRenderableWidget(nextButton);

        y += 34;
        addRenderableWidget(Button.builder(Component.translatable("musicisland.controls.position_settings"), b -> {
            if (this.minecraft != null) {
                this.minecraft.gui.setScreen(new MusicIslandPositionScreen(this));
            }
        }).bounds(panelX + 15, y, 115, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.gui.done"), b -> onClose())
                .bounds(panelX + 140, y, 115, 20)
                .build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.controls.lyrics_sync"), b -> {
            if (this.minecraft != null) {
                this.minecraft.gui.setScreen(new LyricsSettingsScreen(this));
            }
        }).bounds(panelX + 15, y + 26, 240, 20).build());
    }

    private void selectKey(KeyMapping mapping) {
        this.selectedMapping = mapping;
        updateButtonLabels();
    }

    private Component getKeyComponent(KeyMapping mapping) {
        if (mapping == selectedMapping) {
            return Component.translatable("musicisland.controls.press_key").withStyle(ChatFormatting.YELLOW);
        }
        if (mapping.isUnbound()) {
            return Component.translatable("musicisland.controls.unbound").withStyle(ChatFormatting.GRAY);
        }
        return mapping.getTranslatedKeyMessage().copy().withStyle(ChatFormatting.WHITE);
    }

    private void updateButtonLabels() {
        if (prevButton != null) prevButton.setMessage(getKeyComponent(MusicIslandClient.prevTrackKey));
        if (playPauseButton != null) playPauseButton.setMessage(getKeyComponent(MusicIslandClient.playPauseKey));
        if (nextButton != null) nextButton.setMessage(getKeyComponent(MusicIslandClient.nextTrackKey));
    }

    private void assignKey(InputConstants.Key key) {
        if (selectedMapping != null && this.minecraft != null) {
            selectedMapping.setKey(key);
            KeyMapping.resetMapping();
            this.minecraft.options.save();

            // Check conflicts
            conflictWarning = null;
            if (key != InputConstants.UNKNOWN) {
                for (KeyMapping km : this.minecraft.options.keyMappings) {
                    if (km != selectedMapping && km.same(selectedMapping)) {
                        conflictWarning = Component.translatable("musicisland.controls.conflict", Component.translatable(km.getName()).getString()).getString();
                        break;
                    }
                }
            }
        }
        selectedMapping = null;
        updateButtonLabels();
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (selectedMapping != null) {
            int key = event.key();
            if (key == 256) { // Escape -> Unbound
                assignKey(InputConstants.UNKNOWN);
                return true;
            } else if (key == 261 || key == 259) { // Delete or Backspace -> Unbound
                assignKey(InputConstants.UNKNOWN);
                return true;
            } else {
                assignKey(InputConstants.getKey(event));
                return true;
            }
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (selectedMapping != null) {
            assignKey(InputConstants.Type.MOUSE.getOrCreate(event.button()));
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        // Dark background tint
        extractor.fill(0, 0, this.width, this.height, 0x77000000);

        int panelW = 270;
        int panelH = 218;
        int panelX = (this.width - panelW) / 2;
        int panelY = (this.height - panelH) / 2;

        // Draw modern dialog window
        extractor.fill(panelX + 2, panelY, panelX + panelW - 2, panelY + panelH, 0xF018181B);
        extractor.fill(panelX, panelY + 2, panelX + panelW, panelY + panelH - 2, 0xF018181B);
        extractor.horizontalLine(panelX + 2, panelX + panelW - 3, panelY, 0x44FFFFFF);
        extractor.horizontalLine(panelX + 2, panelX + panelW - 3, panelY + panelH - 1, 0x44FFFFFF);
        extractor.verticalLine(panelX, panelY + 2, panelY + panelH - 3, 0x44FFFFFF);
        extractor.verticalLine(panelX + panelW - 1, panelY + 2, panelY + panelH - 3, 0x44FFFFFF);

        // Title
        extractor.centeredText(this.font, Component.translatable("musicisland.controls.title").copy().withStyle(ChatFormatting.BOLD), this.width / 2, panelY + 14, 0xFFFFFFFF);

        // Action labels
        int y = panelY + 44;
        extractor.text(this.font, Component.translatable("key.musicisland.prev_track"), panelX + 18, y, 0xFFE0E0E0);
        y += 28;
        extractor.text(this.font, Component.translatable("key.musicisland.play_pause"), panelX + 18, y, 0xFFE0E0E0);
        y += 28;
        extractor.text(this.font, Component.translatable("key.musicisland.next_track"), panelX + 18, y, 0xFFE0E0E0);

        if (conflictWarning != null) {
            extractor.centeredText(this.font, Component.literal(conflictWarning).withStyle(ChatFormatting.GOLD), this.width / 2, panelY + panelH - 20, 0xFFFFCC00);
        }

        super.extractRenderState(extractor, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.gui.setScreen(parent);
        }
    }
}
