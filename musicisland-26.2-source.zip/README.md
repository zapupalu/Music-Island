# Music Island 🏝️🎵

A modern Windows 11-style Dynamic Island / Music Island client-side mod for **Minecraft Fabric 26.2**, created by **lupasud**.

Displays current music playback directly from Windows using **Windows Global System Media Transport Controls (GSMTC)**.

---

## ✨ Features

- **No Third-Party APIs**: No Spotify Web API, YouTube Music API, VK API, or internet connections required.
- **Universal Media Support**: Works with **any** Windows application providing a System Media Session:
  - Spotify Desktop
  - YouTube / YouTube Music in Chrome, Edge, Firefox, Brave, etc.
  - VK Музыка
  - Discord
  - Windows Media Player / Groove Music / Foobar2000 / AIMP / VLC
- **Live Metadata**:
  - Song Title & Artist
  - Album Artwork (read directly from the Windows media session and rendered with GPU texture caching and zero memory leaks)
  - Playback State (Playing, Paused, Stopped)
  - Animated live audio visualizer bars when music is playing
- **Fully Customizable Screen Position**:
  - Interactive **Mouse Drag & Drop** mode: drag the Dynamic Island anywhere on the screen!
  - 5 Built-in Presets: `Top-Center`, `Top-Left`, `Top-Right`, `Center`, `Bottom-Center`.
  - Position is persistently saved in `config/musicisland.json`.
- **In-Game Media Keybinds & Custom Controls Menu**:
  - Modern popup screen: **Music Island Controls**
  - Bind custom keys or mouse buttons (e.g. `Mouse 4`, `N`, `P`, `B`) for:
    - **Previous Track**
    - **Play / Pause**
    - **Next Track**
  - Every action supports **Unbound** (empty) state by pressing `Esc`, `Delete`, or `Backspace`.
  - All controls commands are dispatched natively through Windows GSMTC.
- **Toggle Hotkey**:
  - Easily toggle the Dynamic Island visibility on/off anytime (default `M`, customizable in Minecraft Controls).
- **Synchronized Lyrics (LRC) & Smooth Flow Animation**:
  - Live synchronized lyrics fetched via background LRCLIB lookup with disk & memory caching.
  - Character-level smooth reveal animation with word-weight timing and continuous easing.
  - Smooth dynamic capsule expansion that prevents jumps or jitter during fast text transitions.
  - Dedicated **Lyrics & Sync Settings** screen (`Лирика и синхронизация`) accessible directly from Controls menu: offset adjustment (±100ms), max width, and toggle.
- **Timeline & Playback Clock Synchronization**:
  - Dedicated background WinRT helper (`musicisland-timeline.exe`) streams live position, duration, and playback state via stdio.
  - Monotonic clock interpolation between system ticks ensures fluid UI and progress tracking without polling delays.
- **Non-Blocking Architecture**:
  - Dedicated background WinRT helper (`musicisland-timeline.exe`) communicates asynchronously with Minecraft over stdio.
  - Minecraft's render thread and client tick loop are never blocked.
  - Automatic fallback on non-Windows systems with clean log notification: `Music Island requires Windows media session support.`

---

## 🏗️ Architecture

```
Windows Application (Spotify, YouTube, Browser, etc.)
       ↓
Windows GSMTC (WinRT System Media Sessions)
       ↓
musicisland-helper.exe (Native WinRT Background Helper)
       ↓ (JSON IPC / stdio, non-blocking)
WindowsMediaSession (Java Interop Layer)
       ↓
MediaController & MediaTrack
       ↓
MediaTextureManager (NativeImage / DynamicTexture)
       ↓
MusicIslandHud (Minecraft 26.2 HudElement / GuiGraphicsExtractor)
```

### Folder Structure
```
musicisland/
├── src/
│   ├── main/
│   │   ├── csharp/
│   │   │   └── MusicIslandHelper.cs      # Native C# WinRT GSMTC bridge
│   │   └── resources/
│   │       ├── assets/musicisland/
│   │       │   ├── bin/
│   │       │   │   └── musicisland-helper.exe  # Precompiled bundled executable
│   │       │   ├── icon.png
│   │       │   └── lang/
│   │       │       ├── en_us.json
│   │       │       └── ru_ru.json
│   │       └── fabric.mod.json
│   └── client/
│       └── java/dev/lupasud/musicisland/
│           ├── MusicIslandClient.java    # ClientModInitializer & KeyMappings
│           ├── config/
│           │   ├── MusicIslandConfig.java # Persistent JSON config
│           │   └── PositionManager.java   # Screen coordinate math & presets
│           ├── gui/
│           │   ├── MusicIslandControlsScreen.java # Key capture modal
│           │   └── MusicIslandPositionScreen.java # Mouse drag & drop positioning
│           ├── interop/
│           │   ├── MediaController.java   # Command dispatch & track state
│           │   └── WindowsMediaSession.java # Process management & JSON parsing
│           ├── model/
│           │   ├── MediaTrack.java        # Immutable track record
│           │   └── PlaybackStatus.java    # Playback status enum
│           └── render/
│               ├── MediaTextureManager.java # DynamicTexture & NativeImage cache
│               └── MusicIslandHud.java    # Fabric 26.2 HudElement renderer
├── build.gradle
├── gradle.properties
├── settings.gradle
└── gradlew.bat
```

---

## 🎮 Controls & Keybindings

All keybindings are listed under the **Music Island** category in `Options` → `Controls` → `Key Binds`:

| Key Binding | Default | Description |
| :--- | :--- | :--- |
| **Toggle Music Island** | `M` | Toggle HUD visibility on or off |
| **Open Music Island Controls** | *Unbound* | Opens the modern Music Island Controls screen |
| **Previous Track** | *Unbound* | Skip to previous track via Windows GSMTC |
| **Play / Pause** | *Unbound* | Toggle play/pause via Windows GSMTC |
| **Next Track** | *Unbound* | Skip to next track via Windows GSMTC |

### How to use the Controls Menu:
1. Assign a key to **Open Music Island Controls** in Minecraft settings (or open it from position settings).
2. Press that key while in-game.
3. Click on any action button (e.g. `Play / Pause`).
4. Press any keyboard key or mouse button to assign it.
5. To leave an action **Unbound**, click the button and press `Escape`, `Delete`, or `Backspace`.
6. Click **Position Settings** to drag the Dynamic Island or choose a preset.
7. Click **Done** to save.

---

## 🛠️ Building from Source

### Prerequisites:
- Java 25 JDK (e.g. Azul Zulu 25 or Eclipse Adoptium 25)
- Windows 10/11 (for Windows Media Session support)

### Step 1: Build the mod JAR
Run from the `musicisland` root directory:
```powershell
.\gradlew build
```
The compiled mod JAR will be located at:
```
build/libs/musicisland-1.0.0+26.2.jar
```

### (Optional) Recompiling the Native Helper:
The native helper is precompiled and bundled in `src/main/resources/assets/musicisland/bin/musicisland-helper.exe`.
If you ever edit `MusicIslandHelper.cs`, you can recompile it with Windows' built-in C# compiler:
```powershell
& "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /noconfig /optimize+ /target:exe /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\mscorlib.dll" /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.dll" /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll" /r:"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Runtime.dll" /r:"C:\Windows\System32\WinMetadata\Windows.Foundation.winmd" /r:"C:\Windows\System32\WinMetadata\Windows.Media.winmd" /r:"C:\Windows\System32\WinMetadata\Windows.Storage.winmd" /out:"src/main/resources/assets/musicisland/bin/musicisland-helper.exe" "src/main/csharp/MusicIslandHelper.cs"
```

---

## 🚀 Installation & Launch

1. Make sure you have **Minecraft 26.2** installed with **Fabric Loader** (version `>=0.19.3`) and **Fabric API** (`0.160.0+26.2` or compatible).
2. Copy `musicisland-1.0.0+26.2.jar` into your Minecraft mods folder:
   ```
   %appdata%\.minecraft\mods\
   ```
3. Launch Minecraft with the Fabric profile.
4. Start playing music in any app (Spotify, browser, player) and enjoy your **Music Island**!

---

## 👤 Author

- **lupasud**
