package dev.lupasud.musicisland.interop;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lupasud.musicisland.model.MediaTrack;
import dev.lupasud.musicisland.model.PlaybackStatus;
import dev.lupasud.musicisland.render.MediaTextureManager;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public final class WindowsMediaSession {
    private static final Logger LOGGER = LoggerFactory.getLogger("MusicIsland");
    private final MediaController controller;

    private Process helperProcess;
    private BufferedWriter writer;
    private volatile boolean running = false;
    private Thread runnerThread;
    private boolean hookInstalled;
    private final boolean isWindows;

    public WindowsMediaSession(MediaController controller) {
        this.controller = controller;
        this.isWindows = System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    public synchronized void start() {
        if (running) return;
        if (!isWindows) {
            LOGGER.info("Music Island requires Windows media session support.");
            return;
        }

        running = true;
        runnerThread = new Thread(this::runProcessLoop, "MusicIsland-ProcessManager");
        runnerThread.setDaemon(true);
        runnerThread.start();

        if (!hookInstalled) {
            Runtime.getRuntime().addShutdownHook(new Thread(this::stop, "MusicIsland-ShutdownHook"));
            hookInstalled = true;
        }
    }

    private void runProcessLoop() {
        while (running) {
            Path helperExe = prepareHelperExecutable();
            if (helperExe == null || !Files.exists(helperExe)) {
                LOGGER.error("Failed to prepare native GSMTC helper executable.");
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    break;
                }
                continue;
            }

            try {
                ProcessBuilder pb = new ProcessBuilder(helperExe.toAbsolutePath().toString());
                pb.redirectErrorStream(false);
                Process process;
                synchronized (this) {
                    if (!running) break;
                    process = pb.start();
                    helperProcess = process;
                    writer = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
                }
                Thread stderr = new Thread(() -> {
                    try (InputStream errors = process.getErrorStream()) { errors.transferTo(java.io.OutputStream.nullOutputStream()); }
                    catch (Exception ignored) { }
                }, "MusicIsland-HelperErrors");
                stderr.setDaemon(true);
                stderr.start();

                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while (running && (line = reader.readLine()) != null) {
                        handleJsonLine(line.trim());
                    }
                }

                process.waitFor();
            } catch (Exception e) {
                if (running) {
                    LOGGER.warn("GSMTC helper process encountered an issue: {}", e.getMessage());
                }
            } finally {
                closeProcess();
                controller.updateTrack(MediaTrack.EMPTY);
            }

            if (running) {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }
    }

    private void handleJsonLine(String line) {
        if (line.isEmpty() || !line.startsWith("{")) return;

        try {
            JsonObject json = JsonParser.parseString(line).getAsJsonObject();
            boolean hasSession = json.has("hasSession") && json.get("hasSession").getAsBoolean();

            if (!hasSession) {
                MediaTextureManager.getInstance().clearArtwork();
                controller.updateTrack(MediaTrack.EMPTY);
                return;
            }

            String title = json.has("title") ? json.get("title").getAsString() : "";
            String artist = json.has("artist") ? json.get("artist").getAsString() : "";
            String album = json.has("album") ? json.get("album").getAsString() : "";
            PlaybackStatus status = json.has("status") ? PlaybackStatus.fromString(json.get("status").getAsString()) : PlaybackStatus.STOPPED;
            boolean canPlay = json.has("canPlay") && json.get("canPlay").getAsBoolean();
            boolean canPause = json.has("canPause") && json.get("canPause").getAsBoolean();
            boolean canPrev = json.has("canPrev") && json.get("canPrev").getAsBoolean();
            boolean canNext = json.has("canNext") && json.get("canNext").getAsBoolean();
            String thumbHash = json.has("thumbHash") ? json.get("thumbHash").getAsString() : "";
            String thumbBase64 = json.has("thumbBase64") ? json.get("thumbBase64").getAsString() : null;

            if (thumbBase64 != null && !thumbBase64.isEmpty()) {
                MediaTextureManager.getInstance().updateArtwork(thumbBase64, thumbHash);
            } else if (thumbHash.isEmpty()) {
                MediaTextureManager.getInstance().clearArtwork();
            }

            MediaTrack track = new MediaTrack(
                true, title, artist, album, status, canPlay, canPause, canPrev, canNext, thumbHash, thumbBase64,
                json.has("timelineKnown") && json.get("timelineKnown").getAsBoolean(),
                json.has("positionMs") ? Math.max(0, json.get("positionMs").getAsLong()) : 0,
                json.has("durationMs") ? Math.max(0, json.get("durationMs").getAsLong()) : 0,
                System.nanoTime()
            );
            controller.updateTrack(track);
        } catch (Exception e) {
            LOGGER.debug("Error parsing GSMTC json line: {}", e.getMessage());
        }
    }

    public synchronized void sendPlayPause() {
        sendCommand("CMD PLAY_PAUSE");
    }

    public synchronized void sendPrevious() {
        sendCommand("CMD PREV");
    }

    public synchronized void sendNext() {
        sendCommand("CMD NEXT");
    }

    private synchronized void sendCommand(String cmd) {
        if (!isWindows || writer == null) return;
        try {
            writer.write(cmd);
            writer.newLine();
            writer.flush();
        } catch (Exception e) {
            LOGGER.debug("Failed to send command to GSMTC helper: {}", e.getMessage());
        }
    }

    public synchronized void stop() {
        running = false;
        if (runnerThread != null) runnerThread.interrupt();
        sendCommand("CMD QUIT");
        closeProcess();
    }

    private synchronized void closeProcess() {
        if (writer != null) {
            try {
                writer.close();
            } catch (Exception ignored) {}
            writer = null;
        }

        if (helperProcess != null) {
            try {
                helperProcess.destroy();
                if (helperProcess.isAlive()) {
                    helperProcess.destroyForcibly();
                }
            } catch (Exception ignored) {}
            helperProcess = null;
        }
    }

    private Path prepareHelperExecutable() {
        try {
            Path targetDir = FabricLoader.getInstance().getGameDir().resolve(".musicisland");
            Files.createDirectories(targetDir);
            Path targetExe = targetDir.resolve("musicisland-timeline.exe");

            try (InputStream in = WindowsMediaSession.class.getResourceAsStream("/assets/musicisland/bin/musicisland-timeline.exe")) {
                if (in != null) {
                    Files.copy(in, targetExe, StandardCopyOption.REPLACE_EXISTING);
                    return targetExe;
                }
            }

        } catch (Exception e) {
            LOGGER.error("Failed to extract musicisland-timeline.exe", e);
        }
        return null;
    }
}
