package dev.lupasud.musicisland.config;

public final class PositionManager {
    private PositionManager() {}

    /** Continuous anchor for animated HUD widths; integer layout remains available for editors. */
    public static float animatedX(int screenWidth, float islandWidth, MusicIslandConfig config) {
        float scale = config.scale > 0.1f ? config.scale : 1.0f;
        float effectiveWidth = islandWidth * scale;
        if (config.preset == MusicIslandConfig.Preset.CUSTOM && config.customX >= 0)
            return Math.max(0, Math.min(screenWidth - effectiveWidth, config.customX));
        return switch (config.preset) {
            case TOP_LEFT, CENTER_LEFT, BOTTOM_LEFT -> 12;
            case TOP_RIGHT, CENTER_RIGHT, BOTTOM_RIGHT -> Math.max(0, screenWidth - effectiveWidth - 12);
            default -> Math.max(0, (screenWidth - effectiveWidth) / 2f);
        };
    }

    public static int getX(int screenWidth, int islandWidth, MusicIslandConfig config) {
        float scale = config.scale > 0.1f ? config.scale : 1.0f;
        int effectiveWidth = Math.round(islandWidth * scale);

        if (config.preset == MusicIslandConfig.Preset.CUSTOM && config.customX >= 0) {
            return Math.max(0, Math.min(screenWidth - effectiveWidth, config.customX));
        }

        return switch (config.preset) {
            case TOP_LEFT, CENTER_LEFT, BOTTOM_LEFT -> 12;
            case TOP_RIGHT, CENTER_RIGHT, BOTTOM_RIGHT -> Math.max(0, screenWidth - effectiveWidth - 12);
            case CENTER, BOTTOM_CENTER, TOP_CENTER -> Math.max(0, (screenWidth - effectiveWidth) / 2);
            case CUSTOM -> Math.max(0, (screenWidth - effectiveWidth) / 2);
        };
    }

    public static int getY(int screenHeight, int islandHeight, MusicIslandConfig config) {
        float scale = config.scale > 0.1f ? config.scale : 1.0f;
        int effectiveHeight = Math.round(islandHeight * scale);

        if (config.preset == MusicIslandConfig.Preset.CUSTOM && config.customY >= 0) {
            return Math.max(0, Math.min(screenHeight - effectiveHeight, config.customY));
        }

        return switch (config.preset) {
            case TOP_LEFT, TOP_RIGHT, TOP_CENTER -> 12;
            case CENTER, CENTER_LEFT, CENTER_RIGHT -> Math.max(0, (screenHeight - effectiveHeight) / 2);
            case BOTTOM_LEFT, BOTTOM_RIGHT, BOTTOM_CENTER -> Math.max(0, screenHeight - effectiveHeight - 12);
            case CUSTOM -> 12;
        };
    }

    // ==========================================
    // OVRSpot Positioning Helpers
    // ==========================================
    public static int getOvrX(int screenWidth, int overlayWidth, MusicIslandConfig config) {
        float scale = config.ovrScale > 0.1f ? config.ovrScale : 1.0f;
        int effectiveWidth = Math.round(overlayWidth * scale);

        if (config.ovrPreset == MusicIslandConfig.Preset.CUSTOM && config.ovrCustomX >= 0) {
            return Math.max(0, Math.min(screenWidth - effectiveWidth, config.ovrCustomX));
        }

        return switch (config.ovrPreset) {
            case TOP_LEFT, CENTER_LEFT, BOTTOM_LEFT -> 16;
            case TOP_RIGHT, CENTER_RIGHT, BOTTOM_RIGHT -> Math.max(0, screenWidth - effectiveWidth - 16);
            case TOP_CENTER, CENTER, BOTTOM_CENTER, CUSTOM -> Math.max(0, (screenWidth - effectiveWidth) / 2);
        };
    }

    public static int getOvrY(int screenHeight, int overlayHeight, MusicIslandConfig config) {
        float scale = config.ovrScale > 0.1f ? config.ovrScale : 1.0f;
        int effectiveHeight = Math.round(overlayHeight * scale);

        if (config.ovrPreset == MusicIslandConfig.Preset.CUSTOM && config.ovrCustomY >= 0) {
            return Math.max(0, Math.min(screenHeight - effectiveHeight, config.ovrCustomY));
        }

        return switch (config.ovrPreset) {
            case TOP_LEFT, TOP_CENTER, TOP_RIGHT -> 16;
            case CENTER_LEFT, CENTER, CENTER_RIGHT -> Math.max(0, (screenHeight - effectiveHeight) / 2);
            case BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT -> Math.max(0, screenHeight - effectiveHeight - 16);
            case CUSTOM -> 16;
        };
    }
}
