package dev.lupasud.musicisland.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class MusicIslandConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("MusicIsland");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_FILE = FabricLoader.getInstance().getConfigDir().resolve("musicisland.json");

    public enum HudMode {
        DYNAMIC_ISLAND("musicisland.mode.dynamic_island"),
        OVR_SPOT("musicisland.mode.ovr_spot");

        private final String key;
        HudMode(String key) { this.key = key; }
        public String getKey() { return key; }
        public Component getComponent() { return Component.translatable(key); }
        public String getLabel() { return Component.translatable(key).getString(); }
    }

    public enum Preset {
        TOP_LEFT("musicisland.preset.top_left"),
        TOP_CENTER("musicisland.preset.top_center"),
        TOP_RIGHT("musicisland.preset.top_right"),
        CENTER_LEFT("musicisland.preset.center_left"),
        CENTER("musicisland.preset.center"),
        CENTER_RIGHT("musicisland.preset.center_right"),
        BOTTOM_LEFT("musicisland.preset.bottom_left"),
        BOTTOM_CENTER("musicisland.preset.bottom_center"),
        BOTTOM_RIGHT("musicisland.preset.bottom_right"),
        CUSTOM("musicisland.preset.custom");

        private final String key;
        Preset(String key) { this.key = key; }
        public String getKey() { return key; }
        public Component getComponent() { return Component.translatable(key); }
        public String getLabel() { return Component.translatable(key).getString(); }
    }

    public enum LyricsPosition {
        BELOW_ARTIST("musicisland.lyrics.pos.below_artist"),
        SEPARATE_LINE("musicisland.lyrics.pos.separate_line"),
        INLINE("musicisland.lyrics.pos.inline");

        private final String key;
        LyricsPosition(String key) { this.key = key; }
        public String getKey() { return key; }
        public Component getComponent() { return Component.translatable(key); }
        public String getLabel() { return Component.translatable(key).getString(); }
    }

    public enum LyricsScrollDirection {
        PING_PONG("musicisland.lyrics.dir.ping_pong"),
        LEFT_TO_RIGHT("musicisland.lyrics.dir.left_to_right");

        private final String key;
        LyricsScrollDirection(String key) { this.key = key; }
        public String getKey() { return key; }
        public Component getComponent() { return Component.translatable(key); }
        public String getLabel() { return Component.translatable(key).getString(); }
    }

    // Mode Switcher
    public HudMode mode = HudMode.DYNAMIC_ISLAND;

    // ==========================================
    // 1. DYNAMIC ISLAND SETTINGS
    // ==========================================
    public boolean enabled = true;
    public boolean autoHide = false;
    public float scale = 1.0f;
    public int customWidth = 205;
    public int customHeight = 26;
    public float opacity = 0.92f;
    public Preset preset = Preset.TOP_CENTER;
    public int customX = -1;
    public int customY = -1;

    // Dynamic Island Elements Visibility
    public boolean showDot = true;
    public boolean showTime = true;
    public boolean showArtwork = true;
    public boolean showTitle = true;
    public boolean showArtist = true;
    public boolean showAlbum = false;
    public boolean showLyrics = true;
    public boolean showPlayPause = true;
    public boolean showVisualizer = true;
    public boolean showControls = true;

    // Dynamic Island Lyrics Settings
    public boolean lyricsEnabled = true;
    public LyricsPosition lyricsPosition = LyricsPosition.BELOW_ARTIST;
    public int lyricsMaxLines = 2; // 1, 2, or 3 lines
    public float lyricsTextSpeed = 26.0f; // px/sec
    public float lyricsPauseStart = 2.0f; // sec
    public float lyricsPauseEnd = 2.0f; // sec
    public LyricsScrollDirection lyricsScrollDirection = LyricsScrollDirection.PING_PONG;
    public float lyricsResetDelay = 5.0f; // sec
    public float lyricsFadeIn = 0.35f; // sec
    public float lyricsFadeOut = 0.35f; // sec
    public int lyricsOffsetMs = 0; // ms
    public int lyricsMaxWidth = 320; // fallback limit

    // Dynamic Island Colors
    public int colorDot = 0x37C37A;
    public int colorTime = 0xFFFFFF;
    public int colorTitle = 0xFFFFFF;
    public int colorArtist = 0xD1D5DB;
    public int colorAlbum = 0x9CA3AF;
    public int colorLyrics = 0xE5E7EB;
    public int colorPlayPause = 0xFFFFFF;
    public int colorVisualizer = 0x37C37A;
    public int colorBorder = 0xE0E0E6;
    public int colorBackground = 0x111215;

    public void resetColors() {
        this.colorDot = 0x37C37A;
        this.colorTime = 0xFFFFFF;
        this.colorTitle = 0xFFFFFF;
        this.colorArtist = 0xD1D5DB;
        this.colorAlbum = 0x9CA3AF;
        this.colorLyrics = 0xE5E7EB;
        this.colorPlayPause = 0xFFFFFF;
        this.colorVisualizer = 0x37C37A;
        this.colorBorder = 0xE0E0E6;
        this.colorBackground = 0x111215;
    }

    // ==========================================
    // 2. OVRSPOT SETTINGS (COMPLETELY INDEPENDENT)
    // ==========================================
    public int ovrArtworkSize = 160; // px (64 to 512)
    public Preset ovrPreset = Preset.BOTTOM_RIGHT;
    public int ovrCustomX = -1;
    public int ovrCustomY = -1;
    public float ovrScale = 1.0f;

    // Font / text sizes
    public float ovrTitleSize = 1.15f; // multiplier
    public float ovrArtistSize = 0.90f;
    public float ovrLyricsSize = 0.85f;

    // Appearance
    public float ovrBackgroundOpacity = 0.85f;
    public float ovrArtworkOpacity = 1.0f;
    public int ovrCornerRadius = 12; // 0, 4, 8, 12, 16, 24 px
    public boolean ovrShadow = true;
    public float ovrShadowOpacity = 0.60f;
    public int ovrShadowSize = 6;

    // Colors
    public int ovrColorBackground = 0x121212;
    public int ovrColorTitle = 0xFFFFFF;
    public int ovrColorArtist = 0xB3B3B3;
    public int ovrColorLyrics = 0x1DB954;
    public int ovrColorBorder = 0x282828;
    public int ovrColorShadow = 0x000000;

    // Marquee / Animation
    public float ovrTextSpeed = 24.0f;
    public float ovrPauseStart = 2.0f;
    public float ovrPauseEnd = 2.0f;
    public LyricsScrollDirection ovrScrollDirection = LyricsScrollDirection.PING_PONG;
    public float ovrResetDelay = 3.0f;

    // Lyrics
    public boolean ovrShowLyrics = true;
    public int ovrLyricsOffsetMs = 0;

    public void resetOvrColors() {
        this.ovrColorBackground = 0x121212;
        this.ovrColorTitle = 0xFFFFFF;
        this.ovrColorArtist = 0xB3B3B3;
        this.ovrColorLyrics = 0x1DB954;
        this.ovrColorBorder = 0x282828;
        this.ovrColorShadow = 0x000000;
    }

    public static MusicIslandConfig load() {
        if (Files.exists(CONFIG_FILE)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_FILE)) {
                MusicIslandConfig config = GSON.fromJson(reader, MusicIslandConfig.class);
                if (config != null) {
                    config.sanitize();
                    return config;
                }
            } catch (Exception e) {
                LOGGER.error("Failed to load musicisland.json, using defaults", e);
            }
        }
        MusicIslandConfig config = new MusicIslandConfig();
        config.save();
        return config;
    }

    public void save() {
        sanitize();
        try {
            Files.createDirectories(CONFIG_FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_FILE)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            LOGGER.error("Failed to save musicisland.json", e);
        }
    }

    public void sanitize() {
        if (mode == null) mode = HudMode.DYNAMIC_ISLAND;

        // Dynamic Island
        if (customWidth < 150) customWidth = 205;
        if (customHeight < 20) customHeight = 26;
        if (scale < 0.5f || scale > 2.0f) scale = 1.0f;
        if (opacity < 0.1f || opacity > 1.0f) opacity = 0.92f;
        if (preset == null) preset = Preset.TOP_CENTER;

        showControls = showPlayPause;

        if (lyricsPosition == null) lyricsPosition = LyricsPosition.BELOW_ARTIST;
        if (lyricsScrollDirection == null) lyricsScrollDirection = LyricsScrollDirection.PING_PONG;
        if (lyricsMaxLines < 1 || lyricsMaxLines > 3) lyricsMaxLines = 2;
        if (lyricsTextSpeed < 5.0f || lyricsTextSpeed > 100.0f) lyricsTextSpeed = 26.0f;
        if (lyricsPauseStart < 0.2f || lyricsPauseStart > 10.0f) lyricsPauseStart = 2.0f;
        if (lyricsPauseEnd < 0.2f || lyricsPauseEnd > 10.0f) lyricsPauseEnd = 2.0f;
        if (lyricsResetDelay < 0.5f || lyricsResetDelay > 30.0f) lyricsResetDelay = 5.0f;
        if (lyricsFadeIn < 0.05f || lyricsFadeIn > 3.0f) lyricsFadeIn = 0.35f;
        if (lyricsFadeOut < 0.05f || lyricsFadeOut > 3.0f) lyricsFadeOut = 0.35f;
        lyricsOffsetMs = Math.max(-10000, Math.min(10000, lyricsOffsetMs));
        lyricsMaxWidth = Math.max(180, Math.min(480, lyricsMaxWidth));

        if (colorDot == 0) colorDot = 0x37C37A;
        if (colorTime == 0) colorTime = 0xFFFFFF;
        if (colorTitle == 0) colorTitle = 0xFFFFFF;
        if (colorArtist == 0) colorArtist = 0xD1D5DB;
        if (colorAlbum == 0) colorAlbum = 0x9CA3AF;
        if (colorLyrics == 0) colorLyrics = 0xE5E7EB;
        if (colorPlayPause == 0) colorPlayPause = 0xFFFFFF;
        if (colorVisualizer == 0) colorVisualizer = 0x37C37A;
        if (colorBorder == 0) colorBorder = 0xE0E0E6;
        if (colorBackground == 0) colorBackground = 0x111215;

        // OVRSpot
        if (ovrArtworkSize < 64) ovrArtworkSize = 64;
        if (ovrArtworkSize > 512) ovrArtworkSize = 512;
        if (ovrPreset == null) ovrPreset = Preset.BOTTOM_RIGHT;
        if (ovrScale < 0.5f || ovrScale > 2.0f) ovrScale = 1.0f;
        if (ovrTitleSize < 0.6f || ovrTitleSize > 2.5f) ovrTitleSize = 1.15f;
        if (ovrArtistSize < 0.5f || ovrArtistSize > 2.0f) ovrArtistSize = 0.90f;
        if (ovrLyricsSize < 0.5f || ovrLyricsSize > 2.0f) ovrLyricsSize = 0.85f;
        if (ovrBackgroundOpacity < 0.0f || ovrBackgroundOpacity > 1.0f) ovrBackgroundOpacity = 0.85f;
        if (ovrArtworkOpacity < 0.0f || ovrArtworkOpacity > 1.0f) ovrArtworkOpacity = 1.0f;
        if (ovrCornerRadius < 0 || ovrCornerRadius > 32) ovrCornerRadius = 12;
        if (ovrShadowOpacity < 0.0f || ovrShadowOpacity > 1.0f) ovrShadowOpacity = 0.60f;
        if (ovrShadowSize < 0 || ovrShadowSize > 20) ovrShadowSize = 6;
        if (ovrColorBackground == 0) ovrColorBackground = 0x121212;
        if (ovrColorTitle == 0) ovrColorTitle = 0xFFFFFF;
        if (ovrColorArtist == 0) ovrColorArtist = 0xB3B3B3;
        if (ovrColorLyrics == 0) ovrColorLyrics = 0x1DB954;
        if (ovrColorBorder == 0) ovrColorBorder = 0x282828;
        if (ovrTextSpeed < 5.0f || ovrTextSpeed > 100.0f) ovrTextSpeed = 24.0f;
        if (ovrPauseStart < 0.2f || ovrPauseStart > 10.0f) ovrPauseStart = 2.0f;
        if (ovrPauseEnd < 0.2f || ovrPauseEnd > 10.0f) ovrPauseEnd = 2.0f;
        if (ovrResetDelay < 0.5f || ovrResetDelay > 30.0f) ovrResetDelay = 3.0f;
        if (ovrScrollDirection == null) ovrScrollDirection = LyricsScrollDirection.PING_PONG;
        ovrLyricsOffsetMs = Math.max(-10000, Math.min(10000, ovrLyricsOffsetMs));
    }
}
