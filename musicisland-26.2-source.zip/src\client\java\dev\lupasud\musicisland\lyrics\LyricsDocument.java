package dev.lupasud.musicisland.lyrics;

import java.util.*;
import java.util.regex.*;

/** Immutable line timing. Supports synced LRC and plain text fallback. */
public final class LyricsDocument {
    public record Line(long startMs, long endMs, String text) {}
    private static final Pattern TIME = Pattern.compile("\\[(\\d{1,4}):([0-5]\\d)(?:[.:](\\d{1,3}))?]");
    private static final Pattern OFFSET = Pattern.compile("\\[offset:([+-]?\\d+)]", Pattern.CASE_INSENSITIVE);
    private final List<Line> lines;
    private LyricsDocument(List<Line> lines) { this.lines = List.copyOf(lines); }
    public List<Line> lines() { return lines; }

    public static LyricsDocument parse(String lrc, long durationMs) {
        if (lrc == null || lrc.length() > 1_000_000) return new LyricsDocument(List.of());
        long offset = 0;
        Matcher om = OFFSET.matcher(lrc);
        while (om.find()) {
            try { offset = Math.max(-86_400_000, Math.min(86_400_000, Long.parseLong(om.group(1)))); }
            catch (NumberFormatException ignored) {}
        }
        TreeMap<Long, String> entries = new TreeMap<>();
        for (String raw : lrc.split("\\R")) {
            Matcher m = TIME.matcher(raw);
            List<Long> times = new ArrayList<>();
            int end = 0;
            while (m.find()) {
                String fraction = m.group(3);
                long ms = Long.parseLong(m.group(1)) * 60_000 + Long.parseLong(m.group(2)) * 1000;
                if (fraction != null) ms += Integer.parseInt((fraction + "00").substring(0, 3));
                times.add(Math.max(0, ms + offset));
                end = m.end();
            }
            String text = raw.substring(end).strip();
            for (long time : times) {
                if (durationMs <= 0 || time < durationMs) entries.putIfAbsent(time, text);
            }
        }
        List<Line> result = new ArrayList<>();
        var all = new ArrayList<>(entries.entrySet());
        for (int i = 0; i < all.size(); i++) {
            var entry = all.get(i);
            long end = i + 1 < all.size() ? all.get(i + 1).getKey() : (durationMs > entry.getKey() ? durationMs : entry.getKey() + 8_000);
            result.add(new Line(entry.getKey(), end, entry.getValue()));
        }

        // Plain text fallback if no synced timestamps were found
        if (result.isEmpty()) {
            String[] rawLines = lrc.split("\\R");
            List<String> valid = new ArrayList<>();
            for (String rl : rawLines) {
                String s = rl.strip();
                if (!s.isBlank() && !s.startsWith("[")) {
                    valid.add(s);
                }
            }
            if (!valid.isEmpty()) {
                long lineDuration = durationMs > 0 ? Math.max(3000, durationMs / valid.size()) : 4000;
                long time = 0;
                for (String s : valid) {
                    result.add(new Line(time, time + lineDuration, s));
                    time += lineDuration;
                }
            }
        }

        return new LyricsDocument(result);
    }

    public Line lineAt(long ms) {
        if (lines.isEmpty()) return null;
        int lo = 0, hi = lines.size() - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).startMs() <= ms) lo = mid + 1;
            else hi = mid - 1;
        }
        if (hi < 0) return null;
        Line line = lines.get(hi);
        return ms < line.endMs() && !line.text().isBlank() ? line : null;
    }
}
