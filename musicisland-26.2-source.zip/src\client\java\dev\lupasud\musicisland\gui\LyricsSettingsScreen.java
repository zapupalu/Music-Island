package dev.lupasud.musicisland.gui;

import dev.lupasud.musicisland.MusicIslandClient;
import dev.lupasud.musicisland.lyrics.LyricsService;
import dev.lupasud.musicisland.interop.MediaController;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Lyrics controls are independent from key rebinding and position editing. */
public final class LyricsSettingsScreen extends Screen {
    private final Screen parent;
    private Button enabled, offset, widthButton;

    public LyricsSettingsScreen(Screen parent) {
        super(Component.translatable("musicisland.lyrics.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = Math.min(280, width - 20);
        int x = (width - w) / 2;
        int y = Math.max(24, height / 2 - 80);

        enabled = addRenderableWidget(Button.builder(Component.literal(""), b -> {
            var c = MusicIslandClient.config();
            c.lyricsEnabled = !c.lyricsEnabled;
            c.save();
            LyricsService.getInstance().tick(MediaController.getInstance().getCurrentTrack(), c.enabled && c.lyricsEnabled);
            labels();
        }).bounds(x, y, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.btn_minus_100ms"), b -> adjust(-100)).bounds(x, y + 28, 65, 20).build());

        offset = addRenderableWidget(Button.builder(Component.literal(""), b -> {
            MusicIslandClient.config().lyricsOffsetMs = 0;
            MusicIslandClient.saveConfig();
            labels();
        }).bounds(x + 69, y + 28, w - 138, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.lyrics.btn_plus_100ms"), b -> adjust(100)).bounds(x + w - 65, y + 28, 65, 20).build());

        widthButton = addRenderableWidget(Button.builder(Component.literal(""), b -> {
            var c = MusicIslandClient.config();
            c.lyricsMaxWidth = c.lyricsMaxWidth >= 400 ? 200 : c.lyricsMaxWidth + 40;
            c.save();
            labels();
        }).bounds(x, y + 56, w, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.gui.done"), b -> onClose()).bounds(x, y + 148, w, 20).build());
        labels();
    }

    private void adjust(int ms) {
        var c = MusicIslandClient.config();
        c.lyricsOffsetMs = Math.max(-10000, Math.min(10000, c.lyricsOffsetMs + ms));
        c.save();
        labels();
    }

    private void labels() {
        var c = MusicIslandClient.config();
        enabled.setMessage(Component.translatable("musicisland.element.lyrics", Component.translatable(c.lyricsEnabled ? "musicisland.gui.on" : "musicisland.gui.off")));
        offset.setMessage(Component.translatable("musicisland.lyrics.offset_sec", String.format(java.util.Locale.ROOT, "%+.1f", c.lyricsOffsetMs / 1000d)));
        widthButton.setMessage(Component.translatable("musicisland.lyrics.max_width", c.lyricsMaxWidth));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0xc010141a);
        int y = Math.max(24, height / 2 - 80);
        g.centeredText(font, title, width / 2, y - 18, 0xffffffff);
        g.centeredText(font, Component.translatable("musicisland.lyrics.hint_offset"), width / 2, y + 84, 0xffbac6d4);
        g.centeredText(font, Component.translatable("musicisland.lyrics.hint_source"), width / 2, y + 98, 0xffbac6d4);
        g.centeredText(font, Component.translatable("musicisland.lyrics.hint_approx"), width / 2, y + 112, 0xffbac6d4);
        g.centeredText(font, LyricsService.getInstance().statusComponent(), width / 2, y + 130, 0xff87c6ff);
        super.extractRenderState(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.gui.setScreen(parent);
        }
    }
}
