using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Web.Script.Serialization;
using Windows.Media.Control;
using Windows.Storage.Streams;

// Original Music Island bridge. Standard input is the sole command channel.
internal static class MediaBridge {
    static volatile bool running = true;
    static GlobalSystemMediaTransportControlsSessionManager manager;
    static T Await<T>(Windows.Foundation.IAsyncOperation<T> operation) {
        var timer = System.Diagnostics.Stopwatch.StartNew();
        while (operation.Status == Windows.Foundation.AsyncStatus.Started) {
            if (timer.ElapsedMilliseconds > 4000) { operation.Cancel(); throw new TimeoutException(); }
            Thread.Sleep(10);
        }
        return operation.GetResults();
    }
    static void Main() {
        Console.SetOut(new StreamWriter(Console.OpenStandardOutput(), new UTF8Encoding(false)) { AutoFlush = true });
        Console.SetIn(new StreamReader(Console.OpenStandardInput(), Encoding.UTF8));
        var input = new Thread(() => {
            string line;
            while ((line = Console.ReadLine()) != null) {
                if (line == "CMD QUIT") break;
                try {
                    var session = manager == null ? null : manager.GetCurrentSession();
                    if (session == null) continue;
                    if (line == "CMD PLAY_PAUSE") Await(session.TryTogglePlayPauseAsync());
                    else if (line == "CMD PREV") Await(session.TrySkipPreviousAsync());
                    else if (line == "CMD NEXT") Await(session.TrySkipNextAsync());
                } catch { }
            }
            running = false;
        });
        input.IsBackground = true;
        input.Start();
        var json = new JavaScriptSerializer();
        string previousHash = "";
        while (running) {
            try {
                if (manager == null) manager = Await(GlobalSystemMediaTransportControlsSessionManager.RequestAsync());
                var session = manager.GetCurrentSession();
                if (session == null) { Console.WriteLine("{\"hasSession\":false}"); previousHash = ""; }
                else {
                    var props = Await(session.TryGetMediaPropertiesAsync());
                    var info = session.GetPlaybackInfo();
                    var timeline = session.GetTimelineProperties();
                    bool playing = info.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing;
                    double duration = (timeline.EndTime - timeline.StartTime).TotalMilliseconds;
                    double position = (timeline.Position - timeline.StartTime).TotalMilliseconds;
                    if (playing && timeline.LastUpdatedTime.Year > 2000)
                        position += Math.Max(0, (DateTimeOffset.UtcNow - timeline.LastUpdatedTime).TotalMilliseconds) * (info.PlaybackRate ?? 1.0);
                    bool known = duration > 0;
                    position = Math.Max(0, Math.Min(known ? duration : 0, position));
                    string hash = "", artwork = "";
                    if (props.Thumbnail != null) {
                        using (var stream = Await(props.Thumbnail.OpenReadAsync())) {
                            if (stream.Size > 0 && stream.Size <= 4 * 1024 * 1024) {
                                using (var reader = new DataReader(stream)) {
                                    uint length = (uint)stream.Size;
                                    Await(reader.LoadAsync(length));
                                    byte[] bytes = new byte[length]; reader.ReadBytes(bytes);
                                    using (var sha = SHA256.Create()) hash = Convert.ToBase64String(sha.ComputeHash(bytes));
                                    if (hash != previousHash) artwork = Convert.ToBase64String(bytes);
                                }
                            }
                        }
                    }
                    previousHash = hash;
                    var controls = info.Controls;
                    Console.WriteLine(json.Serialize(new {
                        hasSession = true, title = props.Title ?? "", artist = props.Artist ?? "", album = props.AlbumTitle ?? "",
                        status = info.PlaybackStatus.ToString(), canPlay = controls.IsPlayEnabled,
                        canPause = controls.IsPauseEnabled, canPrev = controls.IsPreviousEnabled, canNext = controls.IsNextEnabled,
                        thumbHash = hash, thumbBase64 = artwork, timelineKnown = known,
                        positionMs = (long)position, durationMs = (long)Math.Max(0, duration)
                    }));
                }
            } catch { Console.WriteLine("{\"hasSession\":false}"); previousHash = ""; }
            Thread.Sleep(500);
        }
    }
}
