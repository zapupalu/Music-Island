package dev.lupasud.musicisland;

import dev.lupasud.musicisland.lyrics.LyricsAnimator;

public final class LyricsAnimationTests {
    public static void main(String[] args) {
        double[] timings = LyricsAnimator.characterStarts("Я люблю музыку 🎵", 3000);
        require(timings.length == "Я люблю музыку 🎵".codePointCount(0, "Я люблю музыку 🎵".length()), "Unicode code points");
        for (int i = 1; i < timings.length; i++) require(timings[i] >= timings[i - 1], "monotonic timing");
        require(LyricsAnimator.reveal(0, 0) == 0, "initial invisible");
        require(LyricsAnimator.reveal(120, 0) == 1, "settled after 120ms");
        require(LyricsAnimator.reveal(-1000, 0) == 0, "preline invisible");
        require(LyricsAnimator.characterStarts("", 1000).length == 0, "empty line");
        float sixty = 0, thirty = 0;
        for (int i = 0; i < 60; i++) sixty += (1 - sixty) * LyricsAnimator.smoothing(1.0 / 60, .22);
        for (int i = 0; i < 30; i++) thirty += (1 - thirty) * LyricsAnimator.smoothing(1.0 / 30, .22);
        require(Math.abs(sixty - thirty) < .00001, "frame independent smoothing");
        System.out.println("LYRICS_ANIMATION_TESTS passed");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
