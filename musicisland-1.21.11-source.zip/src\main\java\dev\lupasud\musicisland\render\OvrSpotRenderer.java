package dev.lupasud.musicisland.render;

import dev.lupasud.musicisland.config.MusicIslandConfig;
import dev.lupasud.musicisland.model.MediaTrack;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

public final class OvrSpotRenderer {
    private OvrSpotRenderer() {}

    public static int getPadding() {
        return 10;
    }

    public static int calculateCardWidth(MusicIslandConfig config) {
        return config.ovrArtworkSize + getPadding() * 2;
    }

    public static int calculateCardHeight(MusicIslandConfig config, Font font, boolean lyricsActive) {
        int padding = getPadding();
        int artSize = config.ovrArtworkSize;
        int titleH = Math.max(8, Math.round(9 * config.ovrTitleSize));
        int artistH = Math.max(6, Math.round(9 * config.ovrArtistSize));
        int lyricH = Math.max(6, Math.round(9 * config.ovrLyricsSize));

        int h = padding + artSize + 8 + titleH + 3 + artistH;
        if (config.ovrShowLyrics && lyricsActive) {
            h += 4 + lyricH;
        }
        h += padding;
        return h;
    }

    public static void render(
        GuiGraphics graphics,
        Font font,
        int x,
        int y,
        MediaTrack track,
        boolean hasTrack,
        MusicIslandConfig config,
        float alphaMult,
        float marqTimer,
        float deltaTicks,
        LyricsRenderer lyrics
    ) {
        float effectiveOpacity = Math.max(0.0f, Math.min(1.0f, alphaMult));
        if (effectiveOpacity <= 0.02f) return;

        int padding = getPadding();
        int artSize = config.ovrArtworkSize;
        boolean lyricsActive = config.ovrShowLyrics && lyrics != null && lyrics.active();

        int cardW = calculateCardWidth(config);
        int cardH = calculateCardHeight(config, font, lyricsActive);
        int radius = Math.min(config.ovrCornerRadius, Math.min(cardW, cardH) / 2);

        int alphaByte = (int) (effectiveOpacity * 255.0f);
        int bgAlpha = (int) (effectiveOpacity * config.ovrBackgroundOpacity * 255.0f);
        int bgColor = (bgAlpha << 24) | (config.ovrColorBackground & 0xFFFFFF);
        int borderColor = ((int) (effectiveOpacity * 0.35f * 255.0f) << 24) | (config.ovrColorBorder & 0xFFFFFF);

        // 1. Shadow (ambient drop shadow behind card)
        if (config.ovrShadow && config.ovrShadowOpacity > 0.01f && config.ovrShadowSize > 0) {
            int shadowRgb = config.ovrColorShadow & 0xFFFFFF;
            float maxShadowAlpha = effectiveOpacity * config.ovrShadowOpacity;
            int shadowSteps = Math.min(8, Math.max(2, config.ovrShadowSize));

            for (int s = shadowSteps; s >= 1; s--) {
                float stepFraction = (float) s / shadowSteps;
                int stepAlpha = (int) (maxShadowAlpha * (1.0f - stepFraction * 0.7f) * (60.0f / shadowSteps));
                if (stepAlpha < 2) continue;
                int sCol = (stepAlpha << 24) | shadowRgb;
                int expand = Math.round((float) s / shadowSteps * config.ovrShadowSize);
                drawRoundedRect(graphics, x - expand, y - expand / 2, cardW + expand * 2, cardH + expand * 2, radius + expand, sCol, 0);
            }
        }

        // 2. Card Background & Border
        drawRoundedRect(graphics, x, y, cardW, cardH, radius, bgColor, borderColor);

        // 3. Artwork (Square, top of card)
        int artX = x + padding;
        int artY = y + padding;
        float artOpacity = Math.max(0.0f, Math.min(1.0f, effectiveOpacity * config.ovrArtworkOpacity));
        int artAlphaByte = (int) (artOpacity * 255.0f);

        if (hasTrack && config.showArtwork) {
            MediaTextureManager texManager = MediaTextureManager.getInstance();
            if (texManager.hasCustomArtwork()) {
                if (texManager.hasPreviousArtwork() && deltaTicks > 0.0f) {
                    texManager.advanceTransition(deltaTicks);
                    if (texManager.hasPreviousArtwork()) {
                        graphics.blit(texManager.getPreviousTextureId(), artX, artY, artX + artSize, artY + artSize, 0.0f, 1.0f, 0.0f, 1.0f);
                    }
                }
                graphics.blit(texManager.getCurrentTextureId(), artX, artY, artX + artSize, artY + artSize, 0.0f, 1.0f, 0.0f, 1.0f);

                // Round corners of artwork to match card aesthetic
                int artRadius = Math.min(Math.max(2, radius - 2), 12);
                drawArtworkRoundedMask(graphics, artX, artY, artSize, artRadius, bgColor);
                drawSubtleFrame(graphics, artX, artY, artSize, ((int) (artAlphaByte * 0.20f) << 24) | 0xFFFFFF);
            } else {
                // Fallback artwork: Dark card with centered musical note
                drawRoundedRect(graphics, artX, artY, artSize, artSize, Math.max(2, radius - 2), (artAlphaByte << 24) | 0x222328, (artAlphaByte << 24) | 0x383940);
                graphics.pose().pushMatrix();
                float noteScale = Math.max(1.0f, artSize / 40.0f);
                graphics.pose().translate(artX + artSize / 2f, artY + artSize / 2f - 4 * noteScale);
                graphics.pose().scale(noteScale, noteScale);
                graphics.drawCenteredString(font, "♪", 0, 0, (artAlphaByte << 24) | 0x00E5FF);
                graphics.pose().popMatrix();
            }
        } else {
            // Idle placeholder
            drawRoundedRect(graphics, artX, artY, artSize, artSize, Math.max(2, radius - 2), (artAlphaByte << 24) | 0x1A1B1E, (artAlphaByte << 24) | 0x2A2B30);
            graphics.drawCenteredString(font, "♪", artX + artSize / 2, artY + artSize / 2 - 4, (artAlphaByte << 24) | 0x6E6E73);
        }

        // 4. Content Text (Title, Artist, Lyrics)
        int textContainerX = x + padding;
        int textContainerW = artSize;

        String idleMsg = Component.translatable("musicisland.hud.no_music").getString();
        String title = (hasTrack && config.showTitle) ? track.getDisplayTitle() : (hasTrack ? "" : idleMsg);
        String artist = (hasTrack && config.showArtist) ? track.getDisplayArtist() : "";

        int currentY = artY + artSize + 8;

        // --- Song Title ---
        if (!title.isEmpty()) {
            float tScale = config.ovrTitleSize > 0.1f ? config.ovrTitleSize : 1.15f;
            int tHeight = Math.max(8, Math.round(9 * tScale));
            int tColor = (alphaByte << 24) | (config.ovrColorTitle & 0xFFFFFF);

            renderScaledMarquee(graphics, font, title, textContainerX, currentY, textContainerW, tScale, marqTimer, tColor, config);
            currentY += tHeight + 3;
        }

        // --- Artist ---
        if (!artist.isEmpty()) {
            float aScale = config.ovrArtistSize > 0.1f ? config.ovrArtistSize : 0.90f;
            int aHeight = Math.max(6, Math.round(9 * aScale));
            int aColor = (alphaByte << 24) | (config.ovrColorArtist & 0xFFFFFF);

            renderScaledMarquee(graphics, font, artist, textContainerX, currentY, textContainerW, aScale, marqTimer, aColor, config);
            currentY += aHeight + 4;
        }

        // --- Lyrics (Optional) ---
        if (lyricsActive) {
            float lScale = config.ovrLyricsSize > 0.1f ? config.ovrLyricsSize : 0.85f;
            int lHeight = Math.max(6, Math.round(9 * lScale));
            int lColor = (alphaByte << 24) | (config.ovrColorLyrics & 0xFFFFFF);

            lyrics.setScrollViewport(textContainerW / lScale);

            graphics.pose().pushMatrix();
            graphics.pose().translate(textContainerX, currentY);
            graphics.pose().scale(lScale, lScale);

            // Decoupled baseline rendering inside scaled coordinate space
            lyrics.draw(graphics, font, 0, 0, Math.round(textContainerW / lScale), -2, lHeight + 4, alphaByte, lColor);

            graphics.pose().popMatrix();
        }
    }

    private static void renderScaledMarquee(
        GuiGraphics graphics,
        Font font,
        String text,
        int containerX,
        int y,
        int containerW,
        float scale,
        float timer,
        int color,
        MusicIslandConfig config
    ) {
        int rawW = font.width(text);
        float visualW = rawW * scale;

        graphics.enableScissor(containerX, y - 2, containerX + containerW, y + Math.round(9 * scale) + 2);

        graphics.pose().pushMatrix();
        graphics.pose().translate(containerX, y);
        graphics.pose().scale(scale, scale);

        if (visualW <= containerW) {
            // Static text
            graphics.drawString(font, text, 0, 0, color, false);
        } else {
            // Marquee scroll
            float offset = MusicIslandHud.calculateMarqueeOffset(
                rawW,
                Math.round(containerW / scale),
                timer,
                config.ovrTextSpeed,
                config.ovrPauseStart,
                config.ovrPauseEnd,
                config.ovrResetDelay,
                config.ovrScrollDirection
            );
            graphics.drawString(font, text, -Math.round(offset), 0, color, false);
        }

        graphics.pose().popMatrix();
        graphics.disableScissor();
    }

    private static void drawRoundedRect(GuiGraphics graphics, int x, int y, int w, int h, int radius, int fill, int border) {
        if (radius <= 0) {
            graphics.fill(x, y, x + w, y + h, fill);
            if (border != 0) {
                graphics.fill(x, y, x + w, y + 1, border);
                graphics.fill(x, y + h - 1, x + w, y + h, border);
                graphics.fill(x, y + 1, x + 1, y + h - 1, border);
                graphics.fill(x + w - 1, y + 1, x + w, y + h - 1, border);
            }
            return;
        }

        float r = (float) radius;
        float r2 = r * r;

        for (int i = 0; i < h; i++) {
            float dy;
            if (i < radius) {
                dy = r - (i + 0.5f);
            } else if (i >= h - radius) {
                dy = (i + 0.5f) - (h - r);
            } else {
                dy = 0.0f;
            }

            int dx = 0;
            if (dy > 0.0f) {
                float distSq = r2 - dy * dy;
                dx = (distSq > 0.0f) ? (int) Math.round(r - Math.sqrt(distSq)) : (int) r;
            }

            int left = x + dx;
            int right = x + w - dx;

            if (left < right) {
                graphics.fill(left, y + i, right, y + i + 1, fill);
                if (border != 0) {
                    if (i == 0 || i == h - 1 || dx > 0) {
                        graphics.fill(left, y + i, left + 1, y + i + 1, border);
                        graphics.fill(right - 1, y + i, right, y + i + 1, border);
                    }
                    if (i == 0 || i == h - 1) {
                        graphics.fill(left, y + i, right, y + i + 1, border);
                    }
                }
            }
        }
    }

    private static void drawArtworkRoundedMask(GuiGraphics graphics, int x, int y, int size, int r, int maskColor) {
        if (r <= 0) return;
        float r2 = r * r;
        for (int i = 0; i < r; i++) {
            float dy = r - (i + 0.5f);
            int dx = (int) Math.round(r - Math.sqrt(Math.max(0, r2 - dy * dy)));
            if (dx > 0) {
                graphics.fill(x, y + i, x + dx, y + i + 1, maskColor);
                graphics.fill(x + size - dx, y + i, x + size, y + i + 1, maskColor);
                graphics.fill(x, y + size - 1 - i, x + dx, y + size - i, maskColor);
                graphics.fill(x + size - dx, y + size - 1 - i, x + size, y + size - i, maskColor);
            }
        }
    }

    private static void drawSubtleFrame(GuiGraphics graphics, int x, int y, int size, int frameColor) {
        graphics.fill(x + 1, y, x + size - 1, y + 1, frameColor);
        graphics.fill(x + 1, y + size - 1, x + size - 1, y + size, frameColor);
        graphics.fill(x, y + 1, x + 1, y + size - 1, frameColor);
        graphics.fill(x + size - 1, y + 1, x + size, y + size - 1, frameColor);
    }
}
