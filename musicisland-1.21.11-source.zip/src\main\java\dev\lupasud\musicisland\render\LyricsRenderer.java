package dev.lupasud.musicisland.render;

import dev.lupasud.musicisland.lyrics.LyricsAnimator;
import dev.lupasud.musicisland.lyrics.LyricsDocument;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Keeps only two measured lines; rendering never does IO or scans the whole song. */
public final class LyricsRenderer {
    private Layout current, previous;
    private String trackKey = "";
    private long lastPosition = Long.MIN_VALUE, lastNanos, transitionNanos;
    private double elapsed, previousElapsed;
    private float transition = 1;
    private float scrollViewport = 1;
    private float lastScroll;

    public float scrollOffset() { return lastScroll; }
    public void setScrollViewport(float width) { scrollViewport = Math.max(1, width); }

    public void clear() { current = null; previous = null; lastPosition = Long.MIN_VALUE; }

    public void update(String key, LyricsDocument.Line line, long position, long now, Font font) {
        boolean discontinuity = !key.equals(trackKey) || (lastPosition != Long.MIN_VALUE
            && (position < lastPosition - 180 || Math.abs(position - lastPosition) > (now - lastNanos) / 1_000_000 + 2000));
        if (discontinuity) { current = null; previous = null; }
        trackKey = key;
        lastPosition = position;
        lastNanos = now;
        if (line == null || line.text().isBlank()) { current = null; previous = null; return; }
        if (current == null || !current.line.equals(line)) {
            previous = current;
            previousElapsed = elapsed;
            current = new Layout(line, font);
            transitionNanos = now;
        }
        elapsed = position - line.startMs();
        transition = previous == null ? 1 : Math.min(1, (now - transitionNanos) / 200_000_000f);
        if (transition >= 1) previous = null;
    }

    public boolean active() { return current != null; }
    public String text() { return current == null ? "" : current.line.text(); }

    public int visibleGlyphCount() {
        if (current == null) return 0;
        int count = 0;
        for (double start : current.starts) if (LyricsAnimator.reveal(elapsed, start) > 0) count++;
        return count;
    }

    public float revealedWidth() { return current == null ? 0 : current.revealedWidth(elapsed); }

    public void draw(GuiGraphics graphics, Font font, int left, int top, int right, int bottom, int alpha) {
        draw(graphics, font, left, (top + bottom) / 2 - 4, right, top, bottom, alpha, 0xFFFFFF);
    }

    public void draw(GuiGraphics graphics, Font font, int left, int top, int right, int bottom, int alpha, int colorRgb) {
        draw(graphics, font, left, (top + bottom) / 2 - 4, right, top, bottom, alpha, colorRgb);
    }

    public void draw(GuiGraphics graphics, Font font, int left, int baselineY, int right, int scissorTop, int scissorBottom, int alpha, int colorRgb) {
        if (current == null || right <= left) return;
        graphics.enableScissor(left, scissorTop, right, scissorBottom);
        float eased = transition * transition * (3 - 2 * transition);
        int baseline = baselineY;
        lastScroll = Math.max(0, current.revealedWidth(elapsed) - scrollViewport);
        float slide = 4.0f;
        if (previous != null) drawLine(graphics, font, previous, previousElapsed, left, baseline - eased * slide, right - left, scrollViewport, alpha * (1 - eased), colorRgb);
        drawLine(graphics, font, current, elapsed, left, baseline + (previous == null ? 0 : (1 - eased) * slide), right - left, scrollViewport, alpha * eased, colorRgb);
        graphics.disableScissor();
    }

    private static void drawLine(GuiGraphics graphics, Font font, Layout layout, double elapsed, int left, float baseline, int width, float scrollViewport, float alpha, int colorRgb) {
        float scroll = Math.max(0, layout.revealedWidth(elapsed) - scrollViewport);
        int rgb = colorRgb & 0xFFFFFF;
        for (int i = 0; i < layout.glyphs.length; i++) {
            float reveal = LyricsAnimator.reveal(elapsed, layout.starts[i]);
            int opacity = (int) (alpha * reveal);
            if (opacity < 4) continue;
            float x = left + layout.x[i] - scroll;
            if (x + layout.widths[i] < left || x >= left + width) continue;
            graphics.pose().pushMatrix();
            graphics.pose().translate(x, baseline - (1 - reveal) * 3);
            graphics.drawString(font, layout.glyphs[i], 0, 0, (opacity << 24) | rgb, false);
            graphics.pose().popMatrix();
        }
    }

    private static final class Layout {
        final LyricsDocument.Line line;
        final String[] glyphs;
        final int[] x, widths;
        final double[] starts;

        Layout(LyricsDocument.Line line, Font font) {
            this.line = line;
            glyphs = line.text().codePoints().mapToObj(cp -> new String(Character.toChars(cp))).toArray(String[]::new);

            long rawDuration = Math.max(1, line.endMs() - line.startMs());
            long span = Math.min(rawDuration, 8000L);
            starts = LyricsAnimator.characterStarts(line.text(), span);

            x = new int[glyphs.length];
            widths = new int[glyphs.length];
            int cursor = 0;
            for (int i = 0; i < glyphs.length; i++) {
                x[i] = cursor;
                widths[i] = font.width(glyphs[i]);
                cursor += widths[i];
            }
        }

        float revealedWidth(double elapsed) {
            float width = 0;
            for (int i = 0; i < glyphs.length; i++) {
                float progress = LyricsAnimator.reveal(elapsed, starts[i]);
                if (progress <= 0) break;
                width = x[i] + widths[i] * progress;
            }
            return width;
        }
    }
}
