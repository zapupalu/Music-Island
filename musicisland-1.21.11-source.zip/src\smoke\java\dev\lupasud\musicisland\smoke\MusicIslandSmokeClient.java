package dev.lupasud.musicisland.smoke;

import dev.lupasud.musicisland.*;
import dev.lupasud.musicisland.config.*;
import dev.lupasud.musicisland.gui.*;
import dev.lupasud.musicisland.interop.*;
import dev.lupasud.musicisland.model.*;
import dev.lupasud.musicisland.render.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.*;
import net.minecraft.client.input.*;
import net.minecraft.world.Difficulty;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.level.*;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import java.util.*;
import java.util.function.BooleanSupplier;

/** Isolated local game; no commands are sent to the user's music player. */
public final class MusicIslandSmokeClient implements ClientModInitializer {
    private final ArrayDeque<BooleanSupplier> steps=new ArrayDeque<>();
    private long began,at,waitUntil;
    private boolean created,seeded;
    private int stage;
    private double dragX,dragY;
    public void onInitializeClient(){
        if(!Boolean.getBoolean("musicisland.smoke"))return;
        began=System.currentTimeMillis();ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }
    private static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);System.out.println("MUSIC_ISLAND_PASS "+label);}
    private void add(Runnable task){steps.add(()->{task.run();return true;});}
    private void waitFor(long ms){add(()->waitUntil=System.currentTimeMillis()+ms);steps.add(()->System.currentTimeMillis()>=waitUntil);}
    private static void shot(Minecraft mc,String file){Screenshot.grab(mc.gameDirectory,file,mc.getMainRenderTarget(),1,ignored->{});}
    private static String artwork(int rgb){
        try{var image=new java.awt.image.BufferedImage(24,24,java.awt.image.BufferedImage.TYPE_INT_ARGB);
            for(int y=0;y<24;y++)for(int x=0;x<24;x++)image.setRGB(x,y,0xff000000|rgb);
            var bytes=new java.io.ByteArrayOutputStream();javax.imageio.ImageIO.write(image,"png",bytes);return Base64.getEncoder().encodeToString(bytes.toByteArray());
        }catch(Exception e){throw new RuntimeException(e);}
    }
    private void setup(Minecraft mc){
        var config=MusicIslandClient.config();var controller=MediaController.getInstance();var textures=MediaTextureManager.getInstance();
        mc.setScreen(null);mc.player.setPos(.5,-56,-8);mc.player.getAbilities().flying=true;
        waitFor(1200);
        add(()->{
            check(controller.getCurrentTrack().hasSession(),"real Windows media session received in Minecraft");
            check(controller.getCurrentTrack().status()!=PlaybackStatus.NONE,"real playback status received");
            controller.stop(); // Stop polling only; no media control commands, except helper QUIT.
            textures.clearArtwork();
        });
        waitFor(300);
        add(()->{
            config.enabled=true;config.autoHide=false;config.scale=1;config.customWidth=205;config.customHeight=26;config.preset=MusicIslandConfig.Preset.TOP_CENTER;
            controller.updateTrack(new MediaTrack(true,"Проверка длинного названия Music Island","Тестовый исполнитель","",PlaybackStatus.PLAYING,true,true,true,true,"test-a",null));
            textures.updateArtwork(artwork(0x387aff),"test-a");
        });
        waitFor(600);
        add(()->{check(textures.hasCustomArtwork(),"artwork uploaded");shot(mc,"music-island-playing.png");textures.updateArtwork(artwork(0x28b775),"test-b");});
        waitFor(600);
        add(()->{check(textures.hasCustomArtwork(),"replacement artwork survives transition");mc.setScreen(new MusicIslandControlsScreen(null));});
        waitFor(400);
        add(()->{shot(mc,"music-island-controls.png");mc.setScreen(new MusicIslandPositionScreen(mc.screen));});
        waitFor(400);
        add(()->{
            shot(mc,"music-island-position.png");
            int w=mc.getWindow().getGuiScaledWidth(),h=mc.getWindow().getGuiScaledHeight();
            dragX=PositionManager.getX(w,config.customWidth,config)+20;dragY=PositionManager.getY(h,config.customHeight,config)+10;
            mc.screen.mouseClicked(new MouseButtonEvent(dragX,dragY,new MouseButtonInfo(0,0)),false);
        });
        add(()->mc.screen.mouseDragged(new MouseButtonEvent(dragX+40,dragY+50,new MouseButtonInfo(0,0)),40,50));
        add(()->mc.screen.mouseReleased(new MouseButtonEvent(dragX+40,dragY+50,new MouseButtonInfo(0,0))));
        add(()->{
            check(config.preset==MusicIslandConfig.Preset.CUSTOM&&config.customY>=50,"position drag works");
            var loaded=MusicIslandConfig.load();check(loaded.customX==config.customX&&loaded.customY==config.customY,"position saved");
            mc.setScreen(null);controller.updateTrack(new MediaTrack(true,"Пауза","Тест","",PlaybackStatus.PAUSED,true,true,true,true,"test-b",null));
        });
        waitFor(400);
        add(()->{shot(mc,"music-island-paused.png");controller.updateTrack(MediaTrack.EMPTY);config.autoHide=true;});
        waitFor(600);
        add(()->{shot(mc,"music-island-hidden.png");config.enabled=false;config.save();check(!MusicIslandConfig.load().enabled,"HUD setting saved");System.out.println("MUSIC_ISLAND_SMOKE_COMPLETE");mc.stop();});
    }
    private void tick(Minecraft mc){
        if(System.currentTimeMillis()-began>150000)throw new AssertionError("Smoke timeout stage="+stage);
        if(!mc.isGameLoadFinished()||mc.getOverlay()!=null)return;
        mc.options.pauseOnLostFocus=false;mc.setWindowActive(true);long now=System.currentTimeMillis();
        if(!created){created=true;mc.options.onboardingAccessibilityFinished();mc.createWorldOpenFlows().createFreshLevel("MusicIsland-QA-"+now,new LevelSettings("Music Island QA",GameType.CREATIVE,false,Difficulty.PEACEFUL,true,new GameRules(FeatureFlags.DEFAULT_FLAGS),WorldDataConfiguration.DEFAULT),new WorldOptions(42,false,false),WorldPresets::createFlatWorldDimensions,null);at=now;return;}
        if(mc.player==null||mc.level==null)return;checkLocal(mc);
        if(!seeded){if(now-at<3000)return;seeded=true;setup(mc);at=now;return;}
        if(now-at<200||steps.isEmpty())return;
        if(steps.peek().getAsBoolean()){steps.remove();stage++;at=now;}
    }
    private static void checkLocal(Minecraft mc){if(!mc.hasSingleplayerServer())throw new AssertionError("Local QA only");}
}
