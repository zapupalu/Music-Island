package dev.lupasud.musicisland.smoke;

import dev.lupasud.musicisland.*;
import dev.lupasud.musicisland.config.*;
import dev.lupasud.musicisland.gui.*;
import dev.lupasud.musicisland.interop.*;
import dev.lupasud.musicisland.lyrics.*;
import dev.lupasud.musicisland.model.*;
import dev.lupasud.musicisland.render.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.*;
import net.minecraft.world.Difficulty;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.level.*;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.function.BooleanSupplier;

public final class LyricsSmokeClient implements ClientModInitializer {
    private final ArrayDeque<BooleanSupplier> steps=new ArrayDeque<>();
    private long began,at,until;private boolean created,seeded;private int stage,glyphs;
    private boolean checkFast;private float lastScroll;private int fastFrames;
    private static final String TITLE="Music Island Lyrics QA",ARTIST="Local fixture";
    public void onInitializeClient(){if(!Boolean.getBoolean("musicisland.lyricsSmoke"))return;MusicIslandClient.config().lyricsEnabled=false;began=System.currentTimeMillis();ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry.addLast(net.minecraft.resources.Identifier.fromNamespaceAndPath("musicisland","fast-lyrics-qa"),(g,dt)->{
            if(checkFast&&MusicIslandHud.current().activeLyrics()){
                float scroll=MusicIslandHud.current().lyricScrollOffset();
                if(scroll+0.01f<lastScroll)throw new AssertionError("Fast lyrics scroll moved backwards");
                lastScroll=scroll;fastFrames++;
            }
        });
    }
    private static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);System.out.println("LYRICS_SMOKE_PASS "+name);}
    private void add(Runnable r){steps.add(()->{r.run();return true;});}
    private void delay(int ms){add(()->until=System.currentTimeMillis()+ms);steps.add(()->System.currentTimeMillis()>=until);}
    private static MediaTrack track(String title,long position,boolean playing){return new MediaTrack(true,title,ARTIST,"",playing?PlaybackStatus.PLAYING:PlaybackStatus.PAUSED,true,true,true,true,"",null,true,position,16000,System.nanoTime());}
    private static void cache(String title,String lrc){try{
        String key=title+'\0'+ARTIST+'\0'+16000;
        String name=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(key.getBytes(StandardCharsets.UTF_8)));
        Path dir=FabricLoader.getInstance().getConfigDir().resolve("musicisland-lyrics");Files.createDirectories(dir);Files.writeString(dir.resolve(name+".lrc"),lrc);
    }catch(Exception e){throw new IllegalStateException(e);}}
    private static void shot(Minecraft mc,String name){Screenshot.grab(mc.gameDirectory,name,mc.getMainRenderTarget(),1,ignored->{});}
    private void setup(Minecraft mc){var c=MusicIslandClient.config();var media=MediaController.getInstance();var service=LyricsService.getInstance();
        media.stop();delay(500);
        add(()->{
            cache(TITLE,"[00:00.00]Плавно появляется первая строка\n[00:04.00]Музыка и буквы движутся вместе\n[00:08.00]\n[00:10.00]Очень длинная строка для проверки прокрутки и границ капсулы\n[00:15.00]Конец");
            cache("Other QA","[00:00.00]Другая песня\n[00:04.00]Новый текст");
            cache("Fast QA","[00:00.00]Проверка очень быстрого появления множества букв без возвратных рывков текста\n[00:01.20]Следующая строка");
            c.enabled=true;c.lyricsEnabled=true;c.lyricsOffsetMs=0;c.lyricsMaxWidth=300;c.autoHide=false;c.scale=1;c.preset=MusicIslandConfig.Preset.TOP_CENTER;
            mc.player.setPos(.5,-56,-8);mc.player.getAbilities().flying=true;mc.setScreen(null);media.updateTrack(track(TITLE,300,false));
        });
        steps.add(()->service.documentFor(media.getCurrentTrack())!=null);delay(300);
        add(()->{check(MusicIslandHud.current().activeLyrics(),"cached lyrics active");glyphs=MusicIslandHud.current().visibleGlyphCount();shot(mc,"lyrics-start.png");media.updateTrack(track(TITLE,300,true));});
        delay(1000);
        add(()->{check(MusicIslandHud.current().visibleGlyphCount()>glyphs,"letters reveal progressively");shot(mc,"lyrics-typing.png");media.updateTrack(track(TITLE,1800,false));});
        delay(300);add(()->glyphs=MusicIslandHud.current().visibleGlyphCount());delay(600);
        add(()->{check(MusicIslandHud.current().visibleGlyphCount()==glyphs,"pause freezes glyph timeline");media.updateTrack(track(TITLE,3900,true));});
        delay(450);
        add(()->{check(MusicIslandHud.current().displayedLyricText().startsWith("Музыка"),"next timed line");shot(mc,"lyrics-next-line.png");media.updateTrack(track(TITLE,500,false));});
        delay(300);
        add(()->{check(MusicIslandHud.current().displayedLyricText().startsWith("Плавно"),"seek backwards resets line");c.lyricsOffsetMs=1000;media.updateTrack(track(TITLE,4500,false));});
        delay(300);
        add(()->{check(MusicIslandHud.current().displayedLyricText().startsWith("Плавно"),"positive offset delays lyrics");c.lyricsOffsetMs=0;media.updateTrack(track(TITLE,8500,false));});
        delay(300);
        add(()->{check(!MusicIslandHud.current().activeLyrics(),"instrumental gap returns metadata");media.updateTrack(track(TITLE,14000,false));});
        delay(400);add(()->{shot(mc,"lyrics-long-line.png");c.lyricsEnabled=false;});delay(300);
        add(()->{check(!MusicIslandHud.current().activeLyrics()&&service.documentFor(media.getCurrentTrack())==null,"disable drops published lyrics");c.lyricsEnabled=true;media.updateTrack(track(TITLE,500,false));service.tick(media.getCurrentTrack(),true);media.updateTrack(track("Other QA",1500,false));service.tick(media.getCurrentTrack(),true);});
        steps.add(()->service.documentFor(media.getCurrentTrack())!=null);delay(300);
        add(()->{check(MusicIslandHud.current().displayedLyricText().startsWith("Другая"),"new track never receives old result");check(service.documentFor(track(TITLE,0,false))==null,"old track unpublished");mc.setScreen(new LyricsSettingsScreen(null));});
        delay(300);add(()->{shot(mc,"lyrics-settings.png");mc.setScreen(null);media.updateTrack(new MediaTrack(true,TITLE,ARTIST,"",PlaybackStatus.PLAYING,true,true,true,true,"",null));});delay(300);
        add(()->{check(!MusicIslandHud.current().activeLyrics(),"unknown position falls back");c.save();var loaded=MusicIslandConfig.load();check(loaded.lyricsEnabled&&loaded.lyricsMaxWidth==300,"lyrics preferences persist");
            media.updateTrack(new MediaTrack(true,"Yellow","Coldplay","",PlaybackStatus.PAUSED,true,true,true,true,"",null,true,0,267000,System.nanoTime()));
        });
        steps.add(()->service.documentFor(media.getCurrentTrack())!=null);
        add(()->{check(service.documentFor(media.getCurrentTrack()).lines().size()>10,"real LRCLIB response parsed by mod");media.updateTrack(track("Fast QA",0,false));});
        steps.add(()->service.documentFor(media.getCurrentTrack())!=null);delay(250);
        add(()->{lastScroll=0;fastFrames=0;checkFast=true;media.updateTrack(track("Fast QA",0,true));});
        delay(450);
        add(()->{checkFast=false;check(fastFrames>3&&lastScroll>0,"rapid reveal scroll monotonic over rendered frames");shot(mc,"lyrics-fast.png");System.out.println("LYRICS_SMOKE_COMPLETE");mc.stop();});
    }
    private void tick(Minecraft mc){
        long now=System.currentTimeMillis();if(now-began>150000)throw new AssertionError("Lyrics smoke timeout stage "+stage);
        if(!mc.isGameLoadFinished()||mc.getOverlay()!=null)return;mc.options.pauseOnLostFocus=false;mc.setWindowActive(true);
        if(!created){created=true;mc.options.onboardingAccessibilityFinished();mc.createWorldOpenFlows().createFreshLevel("Lyrics-QA-"+now,new LevelSettings("Lyrics QA",GameType.CREATIVE,false,Difficulty.PEACEFUL,true,new GameRules(FeatureFlags.DEFAULT_FLAGS),WorldDataConfiguration.DEFAULT),new WorldOptions(42,false,false),WorldPresets::createFlatWorldDimensions,null);at=now;return;}
        if(mc.player==null||mc.level==null)return;if(!mc.hasSingleplayerServer())throw new AssertionError("Local only");
        if(!seeded){if(now-at<3000)return;seeded=true;setup(mc);at=now;return;}
        if(now-at<150||steps.isEmpty())return;if(steps.peek().getAsBoolean()){steps.remove();stage++;at=now;}
    }
}
