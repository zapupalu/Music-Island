package dev.lupasud.musicisland;

import com.mojang.blaze3d.platform.InputConstants;
import dev.lupasud.musicisland.config.MusicIslandConfig;
import dev.lupasud.musicisland.gui.MusicIslandControlsScreen;
import dev.lupasud.musicisland.interop.MediaController;
import dev.lupasud.musicisland.render.MusicIslandHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class MusicIslandClient implements ClientModInitializer {
    public static final String MOD_ID = "musicisland";

    public static KeyMapping openControlsKey;
    public static KeyMapping toggleHudKey;
    public static KeyMapping prevTrackKey;
    public static KeyMapping playPauseKey;
    public static KeyMapping nextTrackKey;

    private static MusicIslandConfig config;

    @Override
    public void onInitializeClient() {
        config = MusicIslandConfig.load();

        // Key category
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "category"));

        // Key bindings
        openControlsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.musicisland.open_controls",
                InputConstants.Type.KEYSYM,
                InputConstants.UNKNOWN.getValue(),
                category
        ));

        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.musicisland.toggle_hud",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_M,
                category
        ));

        prevTrackKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.musicisland.prev_track",
                InputConstants.Type.KEYSYM,
                InputConstants.UNKNOWN.getValue(),
                category
        ));

        playPauseKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.musicisland.play_pause",
                InputConstants.Type.KEYSYM,
                InputConstants.UNKNOWN.getValue(),
                category
        ));

        nextTrackKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.musicisland.next_track",
                InputConstants.Type.KEYSYM,
                InputConstants.UNKNOWN.getValue(),
                category
        ));

        // Register HUD Element
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(MOD_ID, "hud"), new MusicIslandHud());

        // Initialize Windows Media Session Controller
        MediaController.getInstance().init();
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            MediaController.getInstance().stop();
            dev.lupasud.musicisland.lyrics.LyricsService.getInstance().close();
            dev.lupasud.musicisland.render.MediaTextureManager.getInstance().clearArtwork();
        });

        // Register client tick handler for hotkeys
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            dev.lupasud.musicisland.lyrics.LyricsService.getInstance().tick(MediaController.getInstance().getCurrentTrack(),config.enabled&&config.lyricsEnabled);
            while (openControlsKey.consumeClick()) {
                if (!openControlsKey.isUnbound()) {
                    client.setScreen(new dev.lupasud.musicisland.gui.MusicIslandSettingsScreen(client.screen));
                }
            }

            while (toggleHudKey.consumeClick()) {
                if (!toggleHudKey.isUnbound()) {
                    config.enabled = !config.enabled;
                    config.save();
                }
            }

            while (prevTrackKey.consumeClick()) {
                if (!prevTrackKey.isUnbound()) {
                    MediaController.getInstance().previousTrack();
                }
            }

            while (playPauseKey.consumeClick()) {
                if (!playPauseKey.isUnbound()) {
                    MediaController.getInstance().togglePlayPause();
                }
            }

            while (nextTrackKey.consumeClick()) {
                if (!nextTrackKey.isUnbound()) {
                    MediaController.getInstance().nextTrack();
                }
            }
        });
    }

    public static MusicIslandConfig config() {
        if (config == null) {
            config = MusicIslandConfig.load();
        }
        return config;
    }

    public static void saveConfig() {
        config().save();
    }
}
