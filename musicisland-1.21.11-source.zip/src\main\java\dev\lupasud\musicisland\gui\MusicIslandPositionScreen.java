package dev.lupasud.musicisland.gui;

import dev.lupasud.musicisland.MusicIslandClient;
import dev.lupasud.musicisland.config.MusicIslandConfig;
import dev.lupasud.musicisland.config.PositionManager;
import dev.lupasud.musicisland.interop.MediaController;
import dev.lupasud.musicisland.model.MediaTrack;
import dev.lupasud.musicisland.render.MusicIslandHud;
import dev.lupasud.musicisland.render.OvrSpotRenderer;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class MusicIslandPositionScreen extends Screen {
    private final Screen parent;
    private boolean dragging = false;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;
    private Button scaleButton;
    private Button widthButton;
    private Button heightButton;
    private float previewMarqueeTimer = 0.0f;

    public MusicIslandPositionScreen(Screen parent) {
        super(Component.translatable("musicisland.position.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        clearWidgets();
        MusicIslandConfig config = MusicIslandClient.config();

        int buttonY = this.height - 35;
        int center = this.width / 2;
        int controlsY = buttonY - 56;

        if (config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND) {
            // Row 1: Scale, Width, Height controls (Island)
            addRenderableWidget(Button.builder(Component.literal("-"), b -> changeScale(-0.1f))
                    .bounds(center - 192, controlsY, 20, 20)
                    .build());

            scaleButton = Button.builder(getScaleComponent(config.scale), b -> {
                config.scale = 1.0f;
                config.save();
                updateLabels();
            }).bounds(center - 170, controlsY, 74, 20).build();
            addRenderableWidget(scaleButton);

            addRenderableWidget(Button.builder(Component.literal("+"), b -> changeScale(0.1f))
                    .bounds(center - 94, controlsY, 20, 20)
                    .build());

            addRenderableWidget(Button.builder(Component.literal("-"), b -> changeWidth(-10))
                    .bounds(center - 62, controlsY, 20, 20)
                    .build());

            widthButton = Button.builder(getWidthComponent(config.customWidth), b -> {
                config.customWidth = 205;
                config.save();
                updateLabels();
            }).bounds(center - 40, controlsY, 78, 20).build();
            addRenderableWidget(widthButton);

            addRenderableWidget(Button.builder(Component.literal("+"), b -> changeWidth(10))
                    .bounds(center + 40, controlsY, 20, 20)
                    .build());

            addRenderableWidget(Button.builder(Component.literal("-"), b -> changeHeight(-2))
                    .bounds(center + 72, controlsY, 20, 20)
                    .build());

            heightButton = Button.builder(getHeightComponent(config.customHeight), b -> {
                config.customHeight = 26;
                config.save();
                updateLabels();
            }).bounds(center + 94, controlsY, 74, 20).build();
            addRenderableWidget(heightButton);

            addRenderableWidget(Button.builder(Component.literal("+"), b -> changeHeight(2))
                    .bounds(center + 170, controlsY, 20, 20)
                    .build());

            // Row 2: Island Presets
            int presetY = buttonY - 28;
            addRenderableWidget(Button.builder(MusicIslandConfig.Preset.TOP_CENTER.getComponent(), b -> {
                config.preset = MusicIslandConfig.Preset.TOP_CENTER;
                config.save();
            }).bounds(center - 195, presetY, 75, 20).build());

            addRenderableWidget(Button.builder(MusicIslandConfig.Preset.TOP_LEFT.getComponent(), b -> {
                config.preset = MusicIslandConfig.Preset.TOP_LEFT;
                config.save();
            }).bounds(center - 115, presetY, 75, 20).build());

            addRenderableWidget(Button.builder(MusicIslandConfig.Preset.TOP_RIGHT.getComponent(), b -> {
                config.preset = MusicIslandConfig.Preset.TOP_RIGHT;
                config.save();
            }).bounds(center - 35, presetY, 75, 20).build());

            addRenderableWidget(Button.builder(MusicIslandConfig.Preset.CENTER.getComponent(), b -> {
                config.preset = MusicIslandConfig.Preset.CENTER;
                config.save();
            }).bounds(center + 45, presetY, 75, 20).build());

            addRenderableWidget(Button.builder(MusicIslandConfig.Preset.BOTTOM_CENTER.getComponent(), b -> {
                config.preset = MusicIslandConfig.Preset.BOTTOM_CENTER;
                config.save();
            }).bounds(center + 125, presetY, 80, 20).build());
        } else {
            // Row 1: Scale, Artwork Size, Reset (OVRSpot)
            addRenderableWidget(Button.builder(Component.literal("-"), b -> changeOvrScale(-0.1f))
                    .bounds(center - 180, controlsY, 20, 20)
                    .build());

            scaleButton = Button.builder(getScaleComponent(config.ovrScale), b -> {
                config.ovrScale = 1.0f;
                config.save();
                updateLabels();
            }).bounds(center - 158, controlsY, 74, 20).build();
            addRenderableWidget(scaleButton);

            addRenderableWidget(Button.builder(Component.literal("+"), b -> changeOvrScale(0.1f))
                    .bounds(center - 82, controlsY, 20, 20)
                    .build());

            addRenderableWidget(Button.builder(Component.literal("-"), b -> changeOvrArtSize(-16))
                    .bounds(center - 40, controlsY, 20, 20)
                    .build());

            widthButton = Button.builder(Component.translatable("musicisland.position.art_size", config.ovrArtworkSize), b -> {
                config.ovrArtworkSize = 160;
                config.save();
                updateLabels();
            }).bounds(center - 18, controlsY, 86, 20).build();
            addRenderableWidget(widthButton);

            addRenderableWidget(Button.builder(Component.literal("+"), b -> changeOvrArtSize(16))
                    .bounds(center + 70, controlsY, 20, 20)
                    .build());

            addRenderableWidget(Button.builder(Component.translatable("musicisland.gui.reset"), b -> {
                config.ovrPreset = MusicIslandConfig.Preset.BOTTOM_RIGHT;
                config.ovrCustomX = -1;
                config.ovrCustomY = -1;
                config.save();
            }).bounds(center + 102, controlsY, 78, 20).build());

            // Row 2: 9 Presets for OVRSpot
            int presetY = buttonY - 28;
            MusicIslandConfig.Preset[] ovrPresets = {
                MusicIslandConfig.Preset.TOP_LEFT,
                MusicIslandConfig.Preset.TOP_CENTER,
                MusicIslandConfig.Preset.TOP_RIGHT,
                MusicIslandConfig.Preset.CENTER_LEFT,
                MusicIslandConfig.Preset.CENTER,
                MusicIslandConfig.Preset.CENTER_RIGHT,
                MusicIslandConfig.Preset.BOTTOM_LEFT,
                MusicIslandConfig.Preset.BOTTOM_CENTER,
                MusicIslandConfig.Preset.BOTTOM_RIGHT
            };
            String[] ovrPresetShort = {"TL", "TC", "TR", "CL", "C", "CR", "BL", "BC", "BR"};
            int btnW = 38;
            int gap = 4;
            int totalW = 9 * btnW + 8 * gap;
            int startX = center - totalW / 2;
            for (int i = 0; i < 9; i++) {
                final MusicIslandConfig.Preset p = ovrPresets[i];
                addRenderableWidget(Button.builder(Component.literal(ovrPresetShort[i]), b -> {
                    config.ovrPreset = p;
                    config.ovrCustomX = -1;
                    config.ovrCustomY = -1;
                    config.save();
                }).bounds(startX + i * (btnW + gap), presetY, btnW, 20).build());
            }
        }

        // Row 3: Settings & Done buttons
        addRenderableWidget(Button.builder(Component.translatable("musicisland.gui.settings"), b -> {
            if (this.minecraft != null) {
                this.minecraft.setScreen(new MusicIslandSettingsScreen(this));
            }
        }).bounds(center - 110, buttonY, 100, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("musicisland.gui.done"), b -> onClose())
                .bounds(center + 10, buttonY, 100, 20)
                .build());

        // Vanilla's automatic GUI scale can leave fewer than 410 logical pixels.
        if (this.width < 430) {
            float fit = Math.max(0.1f, (this.width - 16) / 410f);
            for (var child : children()) if (child instanceof net.minecraft.client.gui.components.AbstractWidget widget) {
                widget.setX(center + Math.round((widget.getX() - center) * fit));
                widget.setWidth(Math.max(12, Math.round(widget.getWidth() * fit)));
            }
        }
    }

    private void changeScale(float delta) {
        MusicIslandConfig config = MusicIslandClient.config();
        float newScale = Math.round((config.scale + delta) * 10.0f) / 10.0f;
        config.scale = Math.max(0.5f, Math.min(2.0f, newScale));
        config.save();
        updateLabels();
    }

    private void changeOvrScale(float delta) {
        MusicIslandConfig config = MusicIslandClient.config();
        float newScale = Math.round((config.ovrScale + delta) * 10.0f) / 10.0f;
        config.ovrScale = Math.max(0.5f, Math.min(2.0f, newScale));
        config.save();
        updateLabels();
    }

    private void changeWidth(int delta) {
        MusicIslandConfig config = MusicIslandClient.config();
        config.customWidth = Math.max(160, Math.min(320, config.customWidth + delta));
        config.save();
        updateLabels();
    }

    private void changeOvrArtSize(int delta) {
        MusicIslandConfig config = MusicIslandClient.config();
        config.ovrArtworkSize = Math.max(64, Math.min(512, config.ovrArtworkSize + delta));
        config.save();
        updateLabels();
    }

    private void changeHeight(int delta) {
        MusicIslandConfig config = MusicIslandClient.config();
        config.customHeight = Math.max(20, Math.min(36, config.customHeight + delta));
        config.save();
        updateLabels();
    }

    private Component getScaleComponent(float scale) {
        int percent = Math.round(scale * 100.0f);
        return this.width < 430 ? Component.literal(percent + "%") : Component.translatable("musicisland.position.size", percent);
    }

    private Component getWidthComponent(int width) {
        return this.width < 430 ? Component.literal(width + "px") : Component.translatable("musicisland.position.width", width);
    }

    private Component getHeightComponent(int height) {
        return this.width < 430 ? Component.literal(height + "px") : Component.translatable("musicisland.position.height", height);
    }

    private void updateLabels() {
        MusicIslandConfig config = MusicIslandClient.config();
        if (scaleButton != null) {
            scaleButton.setMessage(getScaleComponent(config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND ? config.scale : config.ovrScale));
        }
        if (widthButton != null) {
            if (config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND) {
                widthButton.setMessage(getWidthComponent(config.customWidth));
            } else {
                widthButton.setMessage(Component.translatable("musicisland.position.art_size", config.ovrArtworkSize));
            }
        }
        if (heightButton != null && config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND) {
            heightButton.setMessage(getHeightComponent(config.customHeight));
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        MusicIslandConfig config = MusicIslandClient.config();
        if (config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND) {
            int previewW = config.customWidth >= 160 ? config.customWidth : 205;
            int previewH = config.customHeight >= 20 ? config.customHeight : 26;
            float scale = config.scale > 0.1f ? config.scale : 1.0f;
            int effectiveW = Math.round(previewW * scale);
            int effectiveH = Math.round(previewH * scale);

            int posX = PositionManager.getX(this.width, previewW, config);
            int posY = PositionManager.getY(this.height, previewH, config);

            if (event.button() == 0 && event.x() >= posX && event.x() <= posX + effectiveW && event.y() >= posY && event.y() <= posY + effectiveH) {
                dragging = true;
                dragOffsetX = (int) event.x() - posX;
                dragOffsetY = (int) event.y() - posY;
                return true;
            }
        } else {
            int cardW = OvrSpotRenderer.calculateCardWidth(config);
            int cardH = OvrSpotRenderer.calculateCardHeight(config, this.font, config.ovrShowLyrics);
            float scale = config.ovrScale > 0.1f ? config.ovrScale : 1.0f;
            int effectiveW = Math.round(cardW * scale);
            int effectiveH = Math.round(cardH * scale);

            int posX = PositionManager.getOvrX(this.width, cardW, config);
            int posY = PositionManager.getOvrY(this.height, cardH, config);

            if (event.button() == 0 && event.x() >= posX && event.x() <= posX + effectiveW && event.y() >= posY && event.y() <= posY + effectiveH) {
                dragging = true;
                dragOffsetX = (int) event.x() - posX;
                dragOffsetY = (int) event.y() - posY;
                return true;
            }
        }

        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging) {
            MusicIslandConfig config = MusicIslandClient.config();
            if (config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND) {
                int previewW = config.customWidth >= 160 ? config.customWidth : 205;
                int previewH = config.customHeight >= 20 ? config.customHeight : 26;
                float scale = config.scale > 0.1f ? config.scale : 1.0f;
                int effectiveW = Math.round(previewW * scale);
                int effectiveH = Math.round(previewH * scale);

                config.preset = MusicIslandConfig.Preset.CUSTOM;
                config.customX = Math.max(0, Math.min(this.width - effectiveW, (int) event.x() - dragOffsetX));
                config.customY = Math.max(0, Math.min(this.height - effectiveH, (int) event.y() - dragOffsetY));
            } else {
                int cardW = OvrSpotRenderer.calculateCardWidth(config);
                int cardH = OvrSpotRenderer.calculateCardHeight(config, this.font, config.ovrShowLyrics);
                float scale = config.ovrScale > 0.1f ? config.ovrScale : 1.0f;
                int effectiveW = Math.round(cardW * scale);
                int effectiveH = Math.round(cardH * scale);

                config.ovrPreset = MusicIslandConfig.Preset.CUSTOM;
                config.ovrCustomX = Math.max(0, Math.min(this.width - effectiveW, (int) event.x() - dragOffsetX));
                config.ovrCustomY = Math.max(0, Math.min(this.height - effectiveH, (int) event.y() - dragOffsetY));
            }
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging) {
            dragging = false;
            MusicIslandClient.saveConfig();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public void render(GuiGraphics extractor, int mouseX, int mouseY, float partialTick) {
        extractor.fill(0, 0, this.width, this.height, 0x44000000);

        previewMarqueeTimer += 0.04f;

        MusicIslandConfig config = MusicIslandClient.config();
        MediaTrack currentTrack = MediaController.getInstance().getCurrentTrack();
        boolean hasTrack = currentTrack.hasSession() && (!currentTrack.title().isEmpty() || !currentTrack.artist().isEmpty());
        MediaTrack displayTrack = hasTrack ? currentTrack : MediaTrack.PREVIEW;

        int highlightColor = dragging ? 0xFF00E5FF : 0x8800E5FF;

        if (config.mode == MusicIslandConfig.HudMode.DYNAMIC_ISLAND) {
            int previewW = config.customWidth >= 160 ? config.customWidth : 205;
            int previewH = config.customHeight >= 20 ? config.customHeight : 26;
            float scale = config.scale > 0.1f ? config.scale : 1.0f;
            int effectiveW = Math.round(previewW * scale);
            int effectiveH = Math.round(previewH * scale);

            int posX = PositionManager.getX(this.width, previewW, config);
            int posY = PositionManager.getY(this.height, previewH, config);

            extractor.hLine(posX - 2, posX + effectiveW + 1, posY - 2, highlightColor);
            extractor.hLine(posX - 2, posX + effectiveW + 1, posY + effectiveH + 1, highlightColor);
            extractor.vLine(posX - 2, posY - 2, posY + effectiveH + 1, highlightColor);
            extractor.vLine(posX + effectiveW + 1, posY - 2, posY + effectiveH + 1, highlightColor);

            boolean customScale = Math.abs(scale - 1.0f) > 0.01f;
            if (customScale) {
                extractor.pose().pushMatrix();
                extractor.pose().scaleAround(scale, scale, (float) posX, (float) posY);
            }

            MusicIslandHud.renderIsland(extractor, this.font, posX, posY, previewW, previewH, displayTrack, true, config, 1.0f, 0.0f, previewMarqueeTimer, 0.0f);

            if (customScale) {
                extractor.pose().popMatrix();
            }

            extractor.drawCenteredString(this.font, Component.translatable("musicisland.position.drag_island_hint").withStyle(ChatFormatting.YELLOW), this.width / 2, this.height - 95, 0xFFFFFF);
            extractor.drawCenteredString(this.font, Component.translatable("musicisland.position.info_island", config.preset.getComponent(), previewW, previewH, Math.round(scale * 100)).withStyle(ChatFormatting.GRAY), this.width / 2, this.height - 82, 0xAAAAAA);
        } else {
            int cardW = OvrSpotRenderer.calculateCardWidth(config);
            int cardH = OvrSpotRenderer.calculateCardHeight(config, this.font, config.ovrShowLyrics);
            float scale = config.ovrScale > 0.1f ? config.ovrScale : 1.0f;
            int effectiveW = Math.round(cardW * scale);
            int effectiveH = Math.round(cardH * scale);

            int posX = PositionManager.getOvrX(this.width, cardW, config);
            int posY = PositionManager.getOvrY(this.height, cardH, config);

            extractor.hLine(posX - 2, posX + effectiveW + 1, posY - 2, highlightColor);
            extractor.hLine(posX - 2, posX + effectiveW + 1, posY + effectiveH + 1, highlightColor);
            extractor.vLine(posX - 2, posY - 2, posY + effectiveH + 1, highlightColor);
            extractor.vLine(posX + effectiveW + 1, posY - 2, posY + effectiveH + 1, highlightColor);

            boolean customScale = Math.abs(scale - 1.0f) > 0.01f;
            if (customScale) {
                extractor.pose().pushMatrix();
                extractor.pose().scaleAround(scale, scale, (float) posX, (float) posY);
            }

            OvrSpotRenderer.render(extractor, this.font, posX, posY, displayTrack, true, config, 1.0f, previewMarqueeTimer, 0.0f, null);

            if (customScale) {
                extractor.pose().popMatrix();
            }

            extractor.drawCenteredString(this.font, Component.translatable("musicisland.position.drag_ovr_hint").withStyle(ChatFormatting.YELLOW), this.width / 2, this.height - 95, 0xFFFFFF);
            extractor.drawCenteredString(this.font, Component.translatable("musicisland.position.info_ovr", config.ovrPreset.getComponent(), config.ovrArtworkSize, Math.round(scale * 100)).withStyle(ChatFormatting.GRAY), this.width / 2, this.height - 82, 0xAAAAAA);
        }

        super.render(extractor, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        MusicIslandClient.saveConfig();
        if (this.minecraft != null) {
            this.minecraft.setScreen(parent);
        }
    }
}
