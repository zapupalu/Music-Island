package dev.lupasud.musicisland.lyrics;

import com.google.gson.*;
import dev.lupasud.musicisland.model.MediaTrack;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.chat.Component;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.*;

/** Background-only LRCLIB lookup; a generation prevents obsolete responses reaching the HUD. */
public final class LyricsService {
    private static final LyricsService INSTANCE = new LyricsService();
    public static LyricsService getInstance() { return INSTANCE; }
    private record Key(String title, String artist, long duration) {}
    private record Cached(LyricsDocument document, long expires) {}
    private record Published(Key key, LyricsDocument document) {}
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "MusicIsland-lyrics"); t.setDaemon(true); return t; });
    private final Map<Key, Cached> memory = new LinkedHashMap<>(64, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Key, Cached> e) { return size() > 64; }
    };
    private volatile Published published;
    private volatile Component status = Component.translatable("musicisland.lyrics.status.disabled");
    private Key active;
    private long generation, retryAt;
    private boolean closed;
    private Future<?> pending;
    private LyricsService() {}
    public Component statusComponent() { return status; }
    public String status() { return status.getString(); }
    private static Key key(MediaTrack track) {
        return track == null || !track.hasSession() || !track.timelineKnown() || track.title() == null || track.title().isBlank() || track.artist() == null || track.artist().isBlank()
            ? null : new Key(track.title().strip(), track.artist().strip(), track.durationMs());
    }
    public LyricsDocument documentFor(MediaTrack track) {
        Published value = published;
        return value != null && value.key.equals(key(track)) ? value.document : null;
    }
    public synchronized void tick(MediaTrack track, boolean enabled) {
        if (closed) return;
        Key next = enabled ? key(track) : null;
        if (!Objects.equals(next, active)) {
            generation++; active = next; published = null; retryAt = 0;
            if (pending != null) pending.cancel(true);
            pending = null;
        }
        if (next == null) { status = enabled ? Component.translatable("musicisland.lyrics.status.no_track") : Component.translatable("musicisland.lyrics.status.disabled"); return; }
        if (published != null || pending != null || System.currentTimeMillis() < retryAt) return;
        long request = generation;
        status = Component.translatable("musicisland.lyrics.status.searching");
        pending = worker.submit(() -> load(next, request));
    }
    private void load(Key key, long request) {
        LyricsDocument doc = null; boolean failed = false;
        try {
            Cached cached = memory.get(key);
            if (cached != null && cached.expires > System.currentTimeMillis()) doc = cached.document;
            else {
                String lrc = readDisk(key);
                if (lrc == null) { lrc = fetch(key); if (lrc != null) writeDisk(key, lrc); }
                if (lrc != null) { doc = LyricsDocument.parse(lrc, key.duration); if (doc.lines().isEmpty()) doc = null; }
                memory.put(key, new Cached(doc, System.currentTimeMillis() + (doc == null ? 600_000 : 86_400_000)));
            }
        } catch (Exception e) { failed = true; }
        synchronized (this) {
            if (closed || request != generation || !key.equals(active)) return;
            pending = null;
            if (doc != null) { published = new Published(key, doc); status = Component.translatable("musicisland.lyrics.status.loaded", Component.translatable("musicisland.lyrics.source.synced")); }
            else { retryAt = System.currentTimeMillis() + (failed ? 60_000 : 600_000); status = failed ? Component.translatable("musicisland.lyrics.status.unavailable") : Component.translatable("musicisland.lyrics.status.not_found"); }
        }
    }
    private static String encode(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private static String fetch(Key key) throws IOException {
        String params = "track_name=" + encode(key.title) + "&artist_name=" + encode(key.artist);
        if (key.duration > 0) params += "&duration=" + key.duration / 1000.0;
        JsonElement exact = request("get?" + params);
        String lyric = matching(exact, key);
        if (lyric != null) return lyric;
        if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException();
        JsonElement search = request("search?track_name=" + encode(key.title) + "&artist_name=" + encode(key.artist));
        if (search != null && search.isJsonArray()) for (JsonElement candidate : search.getAsJsonArray()) {
            lyric = matching(candidate, key); if (lyric != null) return lyric;
        }
        return null;
    }
    public static String normalize(String value) {
        return Normalizer.normalize(value, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT).strip().replaceAll("\\s+", " ");
    }
    private static String matching(JsonElement value, Key key) {
        if (value == null || !value.isJsonObject()) return null;
        try {
            JsonObject item = value.getAsJsonObject();
            if (!normalize(item.get("trackName").getAsString()).equals(normalize(key.title)) || !normalize(item.get("artistName").getAsString()).equals(normalize(key.artist))) return null;
            if (key.duration > 0 && Math.abs(item.get("duration").getAsDouble() * 1000 - key.duration) > 3000) return null;
            JsonElement synced = item.get("syncedLyrics");
            return synced == null || synced.isJsonNull() || synced.getAsString().isBlank() ? null : synced.getAsString();
        } catch (RuntimeException ignored) { return null; }
    }
    private static JsonElement request(String suffix) throws IOException {
        HttpURLConnection c = (HttpURLConnection) URI.create("https://lrclib.net/api/" + suffix).toURL().openConnection();
        c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setInstanceFollowRedirects(false);
        c.setRequestProperty("User-Agent", "MusicIsland/1.21.11 (Minecraft lyrics HUD)");
        c.setRequestProperty("Accept", "application/json");
        try {
            int code = c.getResponseCode(); if (code == 404) return null;
            if (code != 200) throw new IOException("LRCLIB HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream body = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10);
                for (int n; (n = in.read(buffer)) != -1;) {
                    if (Thread.currentThread().isInterrupted() || System.nanoTime() > deadline) throw new InterruptedIOException();
                    if (body.size() + n > 1_000_000) throw new IOException("Response exceeds limit");
                    body.write(buffer, 0, n);
                }
                return JsonParser.parseString(body.toString(StandardCharsets.UTF_8));
            }
        } finally { c.disconnect(); }
    }
    private static Path disk(Key key) throws Exception {
        String name = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest((key.title + "\u0000" + key.artist + "\u0000" + key.duration).getBytes(StandardCharsets.UTF_8)));
        return FabricLoader.getInstance().getConfigDir().resolve("musicisland-lyrics").resolve(name + ".lrc");
    }
    private static String readDisk(Key key) {
        try { Path path = disk(key); if (Files.isRegularFile(path) && Files.size(path) <= 1_000_000 && System.currentTimeMillis() - Files.getLastModifiedTime(path).toMillis() < 7 * 86_400_000L) return Files.readString(path); } catch (Exception ignored) {}
        return null;
    }
    private static void writeDisk(Key key, String lyrics) {
        try {
            Path path = disk(key); Files.createDirectories(path.getParent());
            try (var files = Files.list(path.getParent())) { if (!Files.exists(path) && files.limit(64).count() >= 64) return; }
            Path temp = Files.createTempFile(path.getParent(), "lyrics-", ".tmp");
            try { Files.writeString(temp, lyrics); Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING); } finally { Files.deleteIfExists(temp); }
        } catch (Exception ignored) {}
    }
    public synchronized void close() { closed = true; generation++; published = null; if (pending != null) pending.cancel(true); worker.shutdownNow(); }
}
