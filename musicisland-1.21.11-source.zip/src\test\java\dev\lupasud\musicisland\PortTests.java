package dev.lupasud.musicisland;

import dev.lupasud.musicisland.model.*;
import dev.lupasud.musicisland.render.MusicIslandHud;

public final class PortTests {
    private static int checks;
    private static void check(boolean ok,String name){checks++;if(!ok)throw new AssertionError(name);}
    public static void main(String[] args){
        var textures=dev.lupasud.musicisland.render.MediaTextureManager.getInstance();
        check(textures.getCurrentTextureId()!=null&&textures.getPreviousTextureId()!=null,"texture IDs initialized before singleton");
        check(!MediaTrack.EMPTY.hasSession()&&!MediaTrack.EMPTY.isPlaying(),"empty session");
        check(MediaTrack.PREVIEW.isPlaying(),"playing model");
        var blank=new MediaTrack(true,"  ",null,"",PlaybackStatus.PAUSED,true,false,false,false,"",null);
        check(blank.getDisplayTitle().equals("Unknown Title")&&blank.getDisplayArtist().equals("Unknown Artist"),"missing metadata fallbacks");
        check(!blank.isPlaying(),"paused state");
        var playing=new MediaTrack(true,"Test","Artist","",PlaybackStatus.PLAYING,true,true,true,true,"",null,true,1000,5000,1_000_000_000L);
        check(playing.positionAt(2_000_000_000L)==2000,"interpolated playback clock");
        check(playing.positionAt(20_000_000_000L)==5000,"clock clamps duration");
        var paused=new MediaTrack(true,"Test","Artist","",PlaybackStatus.PAUSED,true,true,true,true,"",null,true,2000,5000,1_000_000_000L);
        check(paused.positionAt(20_000_000_000L)==2000,"paused clock frozen");
        check(!blank.timelineKnown()&&blank.positionAt(System.nanoTime())==0,"legacy no timeline stays unknown");
        check(MusicIslandHud.calculateMarqueeOffset(20,100,50)==0,"short title remains fixed");
        check(MusicIslandHud.calculateMarqueeOffset(200,100,1)==0,"long title initial pause");
        for(int n=0;n<1000;n++){float value=MusicIslandHud.calculateMarqueeOffset(200,100,n*.1f);check(Float.isFinite(value)&&value>=0&&value<=106,"marquee bounds");}
        System.out.println("MUSIC_ISLAND_TESTS "+checks+" passed");
        LyricsTests.main(args);
        LyricsAnimationTests.main(args);
    }
}
